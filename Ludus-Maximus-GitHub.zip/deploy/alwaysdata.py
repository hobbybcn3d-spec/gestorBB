#!/usr/bin/env python3
"""PUB: primera instalación por SSH; conserva el sitio NAFLM y rechaza sobreescribir un Ludus existente."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import sqlite3
import stat
import sys
import tempfile
import zipfile


def prepare(home):
    upload = home / ".ludus-upload"  # PUB: los ZIP se suben fuera de la carpeta de la web actual.
    if upload.is_symlink():
        raise RuntimeError("La carpeta de subida no puede ser un enlace.")
    upload.mkdir(mode=0o700, exist_ok=True)
    upload.chmod(0o700)
    (upload / ".htaccess").write_text("Require all denied\n", encoding="ascii")  # USR: también negar HTTP si se cambia la raíz de otro sitio.
    print("Carpeta privada de subida preparada.")


def install(home, clean=False):
    upload = home / ".ludus-upload"
    target = home / "ludus-maximus"  # PUB: directorio propio; no se instala sobre www ni sobre NAFLM.
    if target.exists() or target.is_symlink():
        raise RuntimeError("Ya existe ludus-maximus. Se conserva intacto; esta herramienta solo hace la primera instalación.")
    archive = upload / "package.zip"
    with zipfile.ZipFile(archive) as package:
        members = package.infolist()
        names = [entry.filename for entry in members]
        if len(names) != len(set(names)):
            raise RuntimeError("El ZIP contiene nombres repetidos.")
        for entry in members:
            name = PurePosixPath(entry.filename)
            if name.is_absolute() or ".." in name.parts or "\\" in entry.filename or stat.S_ISLNK(entry.external_attr >> 16):
                raise RuntimeError("Ruta no válida en el ZIP.")  # USR: impedir extracción fuera de la carpeta nueva.
        metadata = json.loads(package.read("var/deployment-manifest.json"))
        expected = metadata["files"]
        if metadata.get("application") != "Ludus Maximus" or set(names) != set(expected) | {"var/deployment-manifest.json"}:
            raise RuntimeError("El inventario no corresponde al paquete.")
        for name, checksum in expected.items():
            if hashlib.sha256(package.read(name)).hexdigest() != checksum:
                raise RuntimeError("Archivo incompleto o alterado: " + name)  # PUB: no activar una subida dañada.
        stage = Path(tempfile.mkdtemp(prefix="ludus-stage-", dir=str(home)))  # PUB: preparar la carpeta antes de hacerla visible.
        for entry in members:
            destination = stage.joinpath(*PurePosixPath(entry.filename).parts)
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open("xb") as output:
                output.write(package.read(entry.filename))
            destination.chmod(0o600 if entry.filename.startswith("var/") else 0o644)  # USR: archivos de partida legibles solo por su propietario.
    private = stage / "var"
    private.chmod(0o700)
    for directory in (stage / "assets", stage / "images", stage / "ludus"):
        if not directory.is_dir():
            raise RuntimeError("Falta un directorio obligatorio.")
    if clean:
        if (private / "config.php").exists() or any(private.glob("*.sqlite")):
            raise RuntimeError("El paquete GitHub no debe incluir datos o configuraciones privadas.")  # PUB: GitHub contiene código para una instalación nueva.
    else:
        if not (private / "config.php").is_file() or not (private / "ludus.sqlite").is_file():
            raise RuntimeError("Usa el paquete con-partida.zip para este lanzador.")
        with sqlite3.connect((private / "ludus.sqlite").as_uri() + "?mode=ro", uri=True) as database:
            if database.execute("PRAGMA quick_check").fetchone()[0] != "ok" or database.execute("PRAGMA foreign_key_check").fetchone():
                raise RuntimeError("La partida no supera las comprobaciones de integridad.")
            count = database.execute("SELECT COUNT(*) FROM lm_users WHERE role='admin' AND status='active'").fetchone()[0]
            if count < 1:
                raise RuntimeError("No hay un administrador activo en la partida.")
        database.close()  # BD: liberar el archivo también en plataformas que bloquean mover una base abierta.
    stage.chmod(0o755)
    os.rename(stage, target)  # PUB: activar solo una carpeta completa; no toca la web actual.
    archive.unlink()  # PUB: retirar únicamente nuestro ZIP temporal después de instalarlo.
    print(("Codigo instalado en: " if clean else "Partida instalada en: ") + str(target))
    print("Ahora configura Web > Sites: PHP 8.4, raiz /ludus-maximus/ y direccion hobbybcn3d.alwaysdata.net/ludus/.")
    if clean:
        print("Despues abre https://hobbybcn3d.alwaysdata.net/ludus/install.php y crea tu administrador.")  # INS: genera tablas y cuentas nuevas, sin publicar credenciales anteriores.


def main():
    if os.name == "nt" or len(sys.argv) != 2 or sys.argv[1] not in ("prepare", "install", "install-clean"):
        raise RuntimeError("Esta herramienta se ejecuta por SSH en alwaysdata: prepare, install o install-clean.")
    home = Path.home().resolve()
    if home != Path("/home/hobbybcn3d"):
        raise RuntimeError("Usuario inesperado. Comprueba la cuenta SSH hobbybcn3d antes de publicar.")  # USR: no escribir en otra cuenta por error.
    if sys.argv[1] == "prepare":
        prepare(home)
    else:
        lock = home / ".ludus-upload" / "install.lock"
        descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)  # PUB: impedir dos primeras instalaciones simultáneas.
        try:
            install(home, clean=sys.argv[1] == "install-clean")
        finally:
            os.close(descriptor)
            lock.unlink()


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print("Publicacion detenida: " + str(error), file=sys.stderr)
        sys.exit(1)
