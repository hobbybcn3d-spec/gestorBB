@echo off
rem INS: lanzador nativo; funciona aunque Windows bloquee scripts PowerShell.
setlocal
rem INS: situarse en el proyecto, incluso si su ruta contiene espacios.
cd /d "%~dp0"
rem INS: primero el PHP portable de este equipo.
set "LUDUS_PHP=%~dp0.tools\php\php.exe"
if exist "%LUDUS_PHP%" goto listo
rem INS: alternativa para equipos con PHP instalado en PATH.
where php >nul 2>nul
if errorlevel 1 goto falta
set "LUDUS_PHP=php"
:listo
rem INS: cambia 8080 aqu? si necesitas otro puerto.
set "LUDUS_DIRECCION=127.0.0.1:8080"
echo Ludus Maximus: http://%LUDUS_DIRECCION%/
echo Mantiene esta ventana abierta. Para detener, pulsa Ctrl+C.
rem INS: la variable opcional solo evita abrir navegador durante pruebas.
if defined LUDUS_NO_BROWSER goto ejecutar
start "" "http://%LUDUS_DIRECCION%/"
:ejecutar
rem INS: activar las extensiones portables; no modificar PHP externo si no hay ini.
if not exist "%~dp0.tools\php\php.ini" goto externo
"%LUDUS_PHP%" -c "%~dp0.tools\php\php.ini" -S %LUDUS_DIRECCION% "%~dp0router.php"
goto terminar
:externo
"%LUDUS_PHP%" -S %LUDUS_DIRECCION% "%~dp0router.php"
goto terminar
:falta
echo Falta PHP 8.1 o superior. Consulta docs\Instalacion.md.
:terminar
rem INS: conservar visible cualquier mensaje de error de inicio.
pause
