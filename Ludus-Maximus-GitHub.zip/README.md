# Ludus Maximus — Instalar en alwaysdata sin FileZilla

Este paquete contiene el juego completo, el instalador y las imágenes necesarias de las seis razas, incluidos todos los Grandotes. El código mantiene sus comentarios. PHP y SQLite se ejecutan en alwaysdata; no hace falta instalar PHP en tu PC para subirlo.

**Instalación nueva:** el ZIP no incluye usuarios, contraseñas, configuración privada ni partidas locales. El asistente creará su base y un administrador con todos los privilegios. La partida anterior permanece en el equipo original y en sus copias privadas.

## Guardar en GitHub

1. Abre tu repositorio en GitHub.
2. Pulsa **Add file → Upload files**.
3. Arrastra **Ludus-Maximus-GitHub.zip** y confirma la subida.

Puedes guardarlo como un único archivo o extraerlo y subir el código mediante Git. GitHub no descomprime automáticamente los ZIP. **GitHub Pages no ejecuta PHP**: el juego se instala en alwaysdata.

## Subir desde Windows, sin FileZilla

1. Haz clic derecho en el ZIP → **Extraer todo**. No ejecutes el lanzador directamente desde la ventana del ZIP.
2. En la carpeta extraída, abre **Subir-GitHub-Alwaysdata.cmd** con doble clic.
3. Introduce tu contraseña **SSH de alwaysdata** cuando la consola la solicite. Puede pedirla tres veces y no muestra caracteres al escribir. No es la contraseña del administrador del juego.
4. Espera al mensaje de instalación de archivos terminada y configura el sitio según el apartado siguiente.

Solo utiliza **ssh**, **scp** y **tar**, incluidos en este equipo Windows. No usa FileZilla, Python local, PHP local ni `.tools`. Si Windows informa de que falta OpenSSH, puedes habilitar «Cliente OpenSSH» en sus características opcionales; como alternativa, usa la terminal SSH web de alwaysdata y descarga el ZIP desde tu repositorio.

En el panel, **Remote access → SSH/SFTP**, el usuario previsto es `hobbybcn3d`, con conexión por contraseña y shell **BASH**. Servidor `ssh-hobbybcn3d.alwaysdata.net`, puerto **22**. Si OpenSSH pregunta por la huella en la primera conexión, compárala con la que muestra ese apartado del panel.

El lanzador comprime solo los archivos inventariados, sube un ZIP por SCP y verifica sus huellas antes de instalar. Crea `/home/hobbybcn3d/ludus-maximus/`; mantiene la web NAFLM y rechaza sustituir una carpeta Ludus ya existente. Si se detiene indicando que el destino existe, conserva sus datos y consulta el caso antes de actualizar.

### Alternativa: descargar de GitHub desde alwaysdata

Si tu repositorio es **público**, puedes usar la terminal web **https://ssh-hobbybcn3d.alwaysdata.net** sin instalar un cliente de archivos. Entra con tu usuario SSH y ejecuta, uno por uno, estos comandos. Sustituye `TU_USUARIO` y `TU_REPOSITORIO` por los reales; si tu rama no se llama `main`, sustituye también ese nombre:

```sh
mkdir -p /home/hobbybcn3d/.ludus-upload
```

```sh
curl -fL 'https://raw.githubusercontent.com/TU_USUARIO/TU_REPOSITORIO/main/Ludus-Maximus-GitHub.zip' -o /home/hobbybcn3d/.ludus-upload/package.zip
```

```sh
python3 -c 'from pathlib import Path; import zipfile; exec(zipfile.ZipFile(Path.home()/".ludus-upload/package.zip").read("deploy/alwaysdata.py"))' install-clean
```

Continúa con la configuración del sitio que aparece a continuación. Si el repositorio es privado, utiliza el lanzador de Windows; así no necesitas incluir un token de GitHub en comandos o archivos.

## Configurar alwaysdata

En [admin.alwaysdata.com](https://admin.alwaysdata.com/), abre **Web → Sites → Add a site**:

| Campo | Valor |
| --- | --- |
| Nombre | Ludus Maximus |
| Dirección | `hobbybcn3d.alwaysdata.net/ludus/` |
| Tipo | PHP |
| Directorio raíz | `/ludus-maximus/` |
| Versión PHP de este sitio | **8.4** |
| Forzar HTTPS | Activado |
| Caché HTTP | Desactivada |
| Trim path / quitar prefijo, si aparece | Activado para `/ludus/`. |

Conserva la configuración del sitio NAFLM existente. No es necesario cambiar el PHP global de la cuenta.

PHP necesita PDO con **pdo_sqlite**, mbstring, GD y sesiones. Si aparece «could not find driver», habilita `extension=pdo_sqlite.so` en el PHP personalizado de este sitio. Si el módulo ya está cargado, no repitas la directiva. El código fija Europe/Madrid como reloj del juego.

## Crear la partida y el administrador

Abre **https://hobbybcn3d.alwaysdata.net/ludus/install.php**:

1. Elige **SQLite**.
2. Define el usuario y una contraseña propia para el administrador.
3. Instala y entra. Se crean las veinte tablas, el ludus, los tres gladiadores iniciales y el calendario.

No hay una contraseña pública predeterminada. Una vez instalado, el asistente se bloquea automáticamente. Los datos se crean en `var/`, que debe permitir escritura al usuario de PHP; sus reglas bloquean el acceso web.

## Automatizar el juego

En **Advanced → Scheduled tasks**, crea una tarea **Command** cada **un minuto**:

```sh
php /home/hobbybcn3d/ludus-maximus/ludus/cli.php tick
```

En sus variables de entorno, pon:

```text
PHP_VERSION=8.4
```

Revisa la salida de la primera ejecución. Esa configuración debe disponer también de `pdo_sqlite`. Si requiere el mismo `php.ini` del sitio, establece su `PHPRC` desde el panel; no cambies a ciegas la versión global de NAFLM. Las visitas también ejecutan tareas vencidas, pero la tarea programada permite avanzar aunque nadie visite la web.

## Qué se conserva y qué se excluye

Incluido: código PHP, esquema creador de base de datos, motor d20, CSS/JS, logo, retratos de las seis razas, licencia, proyecto y documentación de consulta, protecciones de carpetas y el lanzador de subida.

Excluido: `.tools`, bases de datos, contraseñas, `settings.php` de NAFLM, informes de espionaje, pruebas, capturas y copias históricas. No se han borrado esos archivos del proyecto original; simplemente no forman parte del ZIP pequeño.

Para guardar una copia de la partida online, conserva su base SQLite, `var/config.php` y sus emblemas mediante transferencia privada. No los añadas al repositorio público.

## Referencias

- [Crear un sitio en alwaysdata](https://help.alwaysdata.com/en/docs/web-hosting/sites/add-a-site/).
- [Configurar PHP](https://help.alwaysdata.com/en/docs/web-hosting/languages/php/configuration/).
- [Acceso SSH](https://help.alwaysdata.com/en/docs/web-hosting/remote-access/ssh/).
- [Tareas programadas](https://help.alwaysdata.com/en/docs/web-hosting/tasks/).
- [Versiones PHP distintas en SSH](https://help.alwaysdata.com/en/docs/web-hosting/languages/php/troubleshooting/).
- [GitHub Pages y PHP](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site).
