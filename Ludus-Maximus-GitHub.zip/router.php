<?php
// DOC: enrutador para el servidor local PHP; Apache/IIS utilizan index.php directamente.
$path=rawurldecode(parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH)?:'/'); // USR: inspeccionar ruta decodificada antes de servir archivos.
if(str_contains($path,'..')||preg_match('~^/(var|ludus|docs|tests|\.tools)(/|$)~i',$path)){http_response_code(404);exit('Not found');} // USR: jamás servir datos privados o código interno.
$full=realpath(__DIR__.$path); // DOC: resolver el archivo estático real.
if($full&&str_starts_with($full,__DIR__.DIRECTORY_SEPARATOR)&&preg_match('~^/(assets|images)/~',$path)&&preg_match('/\.(css|js|png|gif|jpg|jpeg|svg|webp|ico)$/i',$full)){return false;} // UI: solo recursos gráficos y estáticos explícitos.
if($path==='/install.php'){require __DIR__.'/install.php';}else{require __DIR__.'/index.php';} // DOC: una entrada controlada para todas las páginas.
