﻿param([ValidateRange(1024,65535)][int]$Puerto=8080,[switch]$SinNavegador) # INS: puerto configurable; 8080 por defecto.
$ErrorActionPreference='Stop' # INS: detenerse con un mensaje si falta un requisito.
Set-Location -LiteralPath $PSScriptRoot # INS: rutas estables aunque se abra desde otro directorio.
$ludusPhp=Join-Path $PSScriptRoot '.tools/php/php.exe' # INS: usar el PHP portable preparado en este equipo.
if(-not (Test-Path -LiteralPath $ludusPhp)){$ludusCommand=Get-Command php -ErrorAction SilentlyContinue;if($ludusCommand){$ludusPhp=$ludusCommand.Source}else{throw 'Falta PHP 8.1 o superior. Consulta docs/Instalacion.md.'}} # INS: también acepta PHP ya instalado.
$ludusArguments=@() # INS: configuración portable solo cuando existe.
$ludusIni=Join-Path $PSScriptRoot '.tools/php/php.ini' # INS: extensiones SQLite, MySQL e imágenes activadas.
if(Test-Path -LiteralPath $ludusIni){$ludusArguments+=@('-c',$ludusIni)} # INS: no sustituir la configuración de un PHP externo.
$ludusUrl="http://127.0.0.1:$Puerto/" # INS: servidor accesible únicamente desde este equipo.
Write-Host "Ludus Maximus: $ludusUrl" # INS: dirección que debes abrir en el navegador.
Write-Host 'Para detener la web, pulsa Ctrl+C en esta ventana.' # INS: el proceso permanece visible para su propietario.
if(-not $SinNavegador){Start-Process -FilePath $ludusUrl} # INS: abrir el navegador es una acción explícita del lanzador del usuario.
& $ludusPhp @ludusArguments -S "127.0.0.1:$Puerto" (Join-Path $PSScriptRoot 'router.php') # INS: enrutador que protege configuración y base de datos.
exit $LASTEXITCODE # INS: conservar el error real si el puerto está ocupado.
