# Qué archivo modifica cada parte

Las abreviaturas de los comentarios son: `DOC` documentación/arranque; `INS` instalación; `BD` datos; `USR` acceso y permisos; `ADM` administración; `LUD` instalaciones; `GLD` gladiadores; `ATR` atributos; `RZA` razas; `ENT` entrenamiento; `TAC` tácticas; `CMB` combate; `MED` salud; `MER` mercado; `ESP` espionaje; `ECO` economía; `CAL` calendario; `UI` pantalla; `IMG` imagen; `IDI` traducción; `RET` retirada; `AZR` dados; `QA` prueba.

Los comentarios explican la finalidad junto a cada bloque o línea de instrucciones. Las llaves y cierres no necesitan repetir el comentario. En VS Code puedes buscar una abreviatura o un nombre de método para localizar una regla.

| Archivo | Para qué sirve | Qué modificar aquí |
| --- | --- | --- |
| `Proyecto.md` | Reglas vigentes y decisiones | Actualizar cuando cambie el juego. |
| `index.php` | Entrada y errores controlados | Redirección al instalador y arranque. |
| `install.php` | Asistente de instalación | Campos, comprobaciones y selección SQL. |
| `router.php` | Servidor PHP local | Rutas y protección de carpetas privadas. |
| `ludus/bootstrap.php` | Arranque compartido | Sesión, Madrid, cabeceras y carga de clases. |
| `ludus/Installer.php` | Instala sin borrar NAFLM | Credenciales iniciales y lectura segura de settings. |
| `ludus/Database.php` | PDO y esquema `lm_` | Tablas, relaciones, índices y transacciones. |
| `ludus/Rules.php` | Valores y catálogos centrales | Rangos raciales, retratos, sueldos, precios, modos y curva de entrenamiento. |
| `ludus/Dice.php` | Todo el azar del juego | d20, selección uniforme, tiradas combinadas y semilla. |
| `ludus/Engine.php` | Simulador de combates | `fight`: asaltos; `strike`: precisión/daño/contraataque; `medical`: lesiones. |
| `ludus/Game.php` | Operaciones del juego | Mercado, gastos, obras, personal, eventos, entrenamiento y reserva. |
| `ludus/App.php` | Controlador HTTP | Acceso, permisos, formularios, emblemas y acciones de admin. |
| `ludus/View.php` | Todas las pantallas | Un método por pestaña; textos ES/EN junto a cada etiqueta. |
| `assets/ludus.css` | Aspecto y móvil | Colores al principio en `:root`; bloques comentados por componente. |
| `assets/ludus.js` | Interacción ligera | Menú móvil, confirmaciones y reloj; no calcula reglas. |
| `assets/ludus-mark.svg` | Emblema predeterminado | Logotipo vectorial propio. |
| `images/player_icons/` | Personajes NAFLM originales | El catálogo de Rules elige retratos existentes. |
| `ludus/cli.php` | Instalación y tareas por consola | `install`, `tick`, `check`. |
| `ludus/release.php` | Paquetes para internet | Lista de archivos, copia consistente de SQLite e inventario SHA-256. |
| `Subir-Alwaysdata.cmd` | Primera subida a alwaysdata | Ejecuta SSH/SCP; la contraseña se escribe solo en la consola. |
| `deploy/alwaysdata.py` | Instala el ZIP por SSH | Verifica archivos y datos; no sobrescribe un Ludus existente. |
| `deploy/package-github.py` | ZIP mínimo para GitHub | Selecciona código y recursos; comprime a nivel 9 sin datos privados. |
| `deploy/package-resources.php` | Catálogo gráfico del ZIP | Lee los retratos reales desde Rules y conserva todas las razas. |
| `Subir-GitHub-Alwaysdata.cmd` | Subida del paquete público | Usa tar/SSH/SCP de Windows sin FileZilla ni PHP local. |
| `docs/Paquete-GitHub.md` | README del ZIP | Subida a GitHub, instalación nueva y configuración alwaysdata. |
| `docs/Publicacion-Alwaysdata.md` | Guía del alojamiento concreto | Sitio, PHP 8.4, HTTPS, cuenta SSH y tareas. |
| `Iniciar-Ludus.cmd/.ps1` | Inicio local en Windows | Puerto y selección de PHP. |
| `.htaccess`, `web.config` | Protección Apache/IIS | Acceso HTTP y segmentos privados. |
| `var/config.php` | Configuración privada generada | Conexión; no subir a un repositorio público. |
| `var/ludus.sqlite` | Partida local | No editar a mano durante una ejecución. |
| `var/admin-access.json` | Acceso inicial solicitado | Solo lectura local por el dueño. |
| `tests/game.php` | Pruebas de reglas e integridad | Crea su propia base; nunca usa la partida local. |
| `tests/prepare-browser.php` | Partida de ejemplo separada | Prepara cuentas y resultados calculados para QA. |
| `tests/browser.cjs` | HTTP y Chrome | Comprueba flujos y guarda ocho capturas. |
| `tests/release.php` | Comprueba los ZIP de publicación | Integridad, archivos incluidos y conservación de la partida. |
| `tests/release-http.cjs` | Comprueba el ZIP ejecutándose | Acceso, permisos y rutas bajo `/ludus/`. |
| `tests/deploy.py` | Comprueba la extracción por SSH | Ensayo local con el paquete real, sin conexión a alwaysdata. |
| `tests/github-package.py` | Comprueba el ZIP público | Tamaño, imágenes, secretos excluidos y transferencia con tar de Windows. |
| `tests/github-install.cjs` | Instala el ZIP desde cero | Crea base y administrador, prueba las once pantallas y sus recursos. |

## Métodos de Game más útiles

`generate`: generar personaje; `createLudus` y `approve`: dotación inicial; `bid`, `reveal`, `closeAuctions`: mercado; `spy`: espionaje; `train`, `weekly`: entrenamiento y cierre económico; `build`, `hire`, `fire`: instalaciones y personal; `registerEvent`, `resolveEvent`, `tournament`: eventos; `retire`, `purge`: reserva y borrados; `tick`: coordina tareas vencidas; `importLegacy`: copia usuarios de NAFLM sin tocar su tabla.

Las consultas usan parámetros. Las operaciones económicas y los resultados se confirman en una transacción; no añadas un cobro fuera de ella. Los atributos secretos deben quedarse en PHP y SQL: no enviarlos como HTML oculto, JSON o JavaScript.

`PUB` identifica comentarios de publicación. Los ZIP con partida son privados y se guardan bajo `var/publicacion`, fuera del acceso HTTP.
