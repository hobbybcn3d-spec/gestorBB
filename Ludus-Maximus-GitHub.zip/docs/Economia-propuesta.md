# Ludus Maximus — Economía de la versión 1.0.0

El usuario delegó los detalles necesarios para implementar una versión jugable. Las propuestas anteriores pasan a ser **valores iniciales ajustables**, definidos en `Rules.php` y en las tarifas de Administración. Esta economía no implica dinero real ni copia una fórmula de Hattrick.

## Ingresos y gastos base

| Concepto | Denarios |
| --- | ---: |
| Dotación, una vez al aprobar | 6.000 |
| Patrocinio semanal si cuenta activa y acceso en quince días | 200 |
| Participación efectiva por gladiador/evento | 60 |
| Extra de podio primero/segundo/tercero | 300 / 180 / 100 |
| Alimentación semanal por gladiador activo | 20 |
| Mantenimiento semanal por nivel de edificio construido | 40 |
| Descubrimiento pagado de mercado | 100 |

Un ludus puede cobrar varios puestos. Neutrales y retirados usados por la Arena no cobran para nadie y sus premios no se reasignan. Un pase libre no es otra participación ni suma otro premio.

## Contratos

| Personal | Contratar niveles 1–5 | Salario semanal niveles 1–5 |
| --- | --- | --- |
| Entrenador | 500 / 1.500 / 3.500 / 8.000 / 15.000 | 100 / 160 / 240 / 350 / 500 |
| Ayudante | 300 / 700 / 1.500 / 3.000 / 5.000 | 50 / 80 / 120 / 170 / 230 |
| Médico | 400 / 900 / 1.800 / 3.500 / 6.000 | 60 / 100 / 150 / 210 / 280 |

El entrenador inicial se entrega sin tarifa de contratación, con salario normal. Cada ayudante cobra por separado. Salarios al cierre semanal, prorrateados por segundos de contrato; despedir conserva el tramo devengado. No hay indemnización inicial. La calidad médica requiere el edificio del mismo nivel.

## Obras

Nivel 1 de alojamiento y sala gratis al aprobar. Una sola obra, siete días, prepago y sin cancelación. El nivel anterior sigue operativo hasta terminar.

| Salto | Precio |
| --- | ---: |
| Alojamiento 1→2 | 1.200 |
| Sala 1→2 | 1.800 |
| Construir médicas 1 | 1.500 |
| Médicas 1→2 | 1.800 |
| Alojamiento 2→3 | 2.160 |
| Sala o médicas 2→3 | 3.240 |

Fórmula posterior: base del nivel 2 × 1,8^(nivel destino − 2), techo a decenas. Máximos: alojamiento 10, sala 6, médicas 5. Mantenimiento por tiempo construido y nivel operativo al cierre; la primera versión no reconstruye distintos niveles de un edificio dentro de la misma semana.

## Mercado

Salidas: humano 1.200; orco 1.500; elfo 1.500; enano 1.400; goblin 800; Grandote 4.500. Dependen de raza pública, nunca de atributos ocultos.

Primera puja puede igualar salida; siguientes al menos techo(última × 1,05). Un líder reserva dinero y plaza; el cierre cobra una vez y transfiere. Al perder la puja se liberan las reservas. El mantenimiento y las obras no pueden consumir dinero reservado. Sin comprador se borra la ficha. Aún no existe venta de jugadores entre usuarios.

## Cierre y recuperación

Patrocinio y mantenimiento se liquidan el lunes. La alimentación se prorratea por tiempo de incorporación. Si disponible no cubre gastos, se paga lo posible y se registra deuda: no se matan ni reponen gladiadores por impago. Se bloquean nuevas inversiones mientras haya mantenimiento pendiente. Futuros ingresos lo cubren primero y quedan registrados junto al descuento en el libro de cuentas.

Si no hay gladiadores y saldo menor que 800, puede pedir **una sola vez en la vida del ludus** un anticipo de 2.000 sin intereses. Se devuelve con el 20 % de ingresos después de liquidar mantenimiento. No habilita otro anticipo al devolverlo.

## Ejemplos de semana completa

Tres gladiadores + dos edificios nivel 1 + entrenador 1 = 60 + 80 + 100 = **240** de gasto.

| Eventos disputados por cada uno de los tres | Participación | Patrocinio | Gasto | Balance sin podio |
| --- | ---: | ---: | ---: | ---: |
| Cero | 0 | 200 | 240 | −40 |
| Uno | 180 | 200 | 240 | +140 |
| Dos | 360 | 200 | 240 | +320 |
| Cuatro | 720 | 200 | 240 | +680 |

Con médicas 1, médico 1 y ayudante 1, gasto **390** y balance **+530** con los cuatro eventos de los tres. Un primero y un tercero añaden 400.

Son comprobaciones aritméticas, no una garantía de equilibrio de largo plazo. El libro conserva los últimos cien movimientos en pantalla; los anteriores permanecen en SQL. Cambiar tarifas afecta operaciones futuras, sin modificar ingresos históricos.
