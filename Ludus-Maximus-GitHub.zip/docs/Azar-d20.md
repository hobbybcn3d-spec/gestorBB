# Ludus Maximus — Azar basado en d20

**Implementado v1.0.0 · 12 de noviembre de 2026 · ludus/Dice.php y ludus/Engine.php.**

Toda decisión aleatoria del juego parte de tiradas uniformes d20, con caras enteras de uno a veinte. Los cálculos deterministas de atributos, energía o economía no reciben tiradas adicionales.

La regla se refiere al mundo y motor del juego; la seguridad de cuentas, contraseñas y sesiones conserva su aleatoriedad técnica independiente.

## 1. Dar peso a los atributos

- Iniciativa = 2 × agilidad efectiva + 1d20.
- Acierto calculado por atributos, táctica, estado físico y suerte; las tiradas solo resuelven esa probabilidad.
- Daño determinado principalmente por fuerza y táctica, con variación d20 de ±5 %.
- Constitución fija aguante; resistencia fija gasto y recuperación.
- Consistencia reduce variación entre peleas.
- No hay victoria, muerte o daño crítico automático por sacar un veinte; tampoco derrota o lesión automática por sacar un uno.

No se fija un porcentaje universal de victorias por ser «mejor». Depende del conjunto de atributos, táctica y rivales.

## 2. Tiradas simples

| Uso | Resolución |
| --- | --- |
| Iniciativa | 2 × AG efectiva + 1d20. |
| Suerte al generar | Cara del d20: 1–20. |
| Objetivo battle royale | 1–16: otro ludus; 17–20: propio, si ambos grupos existen. |
| Respuesta Contraataque | 17–20: responde, si cumple energía y límite por asalto. |
| Sexo | 1–18: hombre; 19–20: mujer. |
| Predisposición tras primera lesión grave | 17–20: adquiere predisposición secreta del 20 %. |

Dentro del grupo elegido se sortea un objetivo válido sin sesgo. Si no hay miembros del grupo, usar el disponible según reglas existentes.

## 3. Consistencia y daño, sin azar continuo

Definir U20 = (2 × d20 − 21) / 19. Va de −1 a +1 en veinte pasos, simétricos y con media cero.

- Consistencia: rendimiento = 1 + amplitud × U20, una tirada por pelea. Amplitud = 0,10 − 0,09 × (consistencia − 1) / 19.
- Daño: multiplicador = 1 + 0,05 × U20, una nueva tirada por impacto acertado.

El daño queda entre 95 % y 105 %. La consistencia mantiene sus extremos ±10 % a ±1 %. No se cambia al gladiador guardado.

## 4. Porcentajes finos con tres d20

Una sola tirada d20 tiene saltos del 5 %. Eso no representa un 2 % de lesión ni un 0,1 % de muerte.

Combinar tres caras como dígitos en base veinte:

R = 1 + (d1 − 1) × 400 + (d2 − 1) × 20 + (d3 − 1).

R queda entre 1 y 8.000, con resultados equiprobables. **No sumar las tres caras**: la suma no sería uniforme.

Para una probabilidad p entre 0 y 1:

- k = redondear(8.000 × p) al entero más cercano.
- El éxito ocurre si R > 8.000 − k.
- Precisión: 1/8.000, equivalente a 0,0125 puntos porcentuales.
- Error máximo de redondeo: 0,00625 puntos porcentuales.

Esto conserva los pequeños efectos de suerte, altura y agilidad en lugar de redondearlos a saltos del 5 %. No se usan dados de otras caras.

## 5. Evaluación médica única

Para la distribución médica usar R de tres d20 como sorteo de categorías excluyentes:

| Resultado R | Consecuencia base |
| --- | --- |
| 1–8 | Muerte: 0,1 %. |
| 9–160 | Lesión no mortal ordinaria: 1,9 %. |
| 161–160 + incremento | Recaída: solo si tiene riesgo adicional. |
| Resto | Sin lesión permanente. |

Incremento: cuarenta resultados por cada 0,5 puntos porcentuales de riesgo añadido. Con el máximo +1,5 puntos hay ciento veinte resultados de recaída y total lesivo 280/8.000 = 3,5 %.

Sin predisposición, el tramo de recaída está vacío y total lesivo 160/8.000 = 2 %. Una de cada mil muertes en promedio sigue siendo ocho resultados entre ocho mil, no una cara entre veinte.

La evaluación se hace una vez por gladiador al finalizar evento. No se duplica por duelo ni por golpe. La predisposición posterior a una primera lesión grave usa otra tirada d20 del 20 %.

Distribución por gravedad delegada e implementada: d20 1–14, leve de tres días; 15–19, moderada de siete días; 20, grave de veintiún días. Cada gladiador se evalúa una sola vez al terminar el evento.

## 6. Razas

Mercado y neutrales:

| Cara d20 | Raza |
| --- | --- |
| 1–7 | Humano: 35 %. |
| 8–11 | Orco: 20 %. |
| 12–14 | Elfo: 15 %. |
| 15–17 | Enano: 15 %. |
| 18–19 | Goblin: 10 %. |
| 20 | Ogro: 5 %. |

Para los tres iniciales, repetir si sale veinte. Así se mantienen exactamente los pesos relativos 7:4:3:3:2 sin ogros.

## 7. Intervalos, listas y sorteos sin sesgo

Para elegir uno entre N resultados equiprobables:

1. Usar tantas tiradas d20 como sean necesarias para que 20 elevado al número de tiradas sea al menos N.
2. Interpretar sus caras menos uno como dígitos base veinte, formando un ticket desde cero.
3. Aceptar solo tickets inferiores a suelo(20^tiradas / N) × N.
4. Si queda fuera, repetir; si queda dentro, usar ticket módulo N como índice.

No hacer módulo directamente cuando veinte no es múltiplo de N.

Ejemplo: seis atributos posibles → aceptar caras 1–18 y repetir 19–20; hay tres caras por atributo. Un intervalo de cinco valores usa las veinte caras, cuatro por valor.

Aplicar este servicio a atributos al nacer, edad, nombres futuros, altura/peso al concretar su distribución, lista de objetivos, espionaje, sustitutos, cuadro y pases libres. Mantener los rangos, correlaciones y restricciones acordados: el d20 cambia la fuente de azar, no esos límites.

## 8. Empates y trazabilidad

Iniciativa: mayor puntuación; después mayor AG efectiva; después mayor consistencia; si persiste igualdad, sortear el orden de ese grupo mediante d20 sin sesgo.

Desempates finales de combate mantienen salud proporcional y energía antes del sorteo. El d20 no sustituye esas prioridades.

Registrar versión de reglas y la semilla o secuencia necesaria para comprobación interna del motor. No publicar secretos del gladiador ni semillas de datos privados en la crónica pública. La conservación de datos debe respetar el borrado de retirados y de informes de espionaje.
