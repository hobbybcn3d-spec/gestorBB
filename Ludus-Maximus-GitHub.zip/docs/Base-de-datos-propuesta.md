# Ludus Maximus — Base de datos implementada

**Versión 1.0.0 · Esquema en ludus/Database.php.** El nombre del documento se conserva para no romper enlaces antiguos. Sustituye la propuesta anterior de PostgreSQL.

SQLite por defecto; MySQL/MariaDB opcional para compartir base con NAFLM. Solo se crean tablas con prefijo `lm_`. Todas las tablas MySQL usan InnoDB y utf8mb4. SQLite activa claves foráneas, WAL y espera de escritura. No se ejecuta el instalador antiguo ni se elimina ninguna tabla de NAFLM.

## Tablas y relaciones

| Tabla | Contenido y relación principal |
| --- | --- |
| lm_meta | Versión del esquema, tarifas, reloj de tareas y fila de bloqueo transaccional. |
| lm_users | Usuario único normalizado, hash, rol, estado, idioma y actividad. legacy_id único opcional. |
| lm_ludus | Un ludus por usuario; nombre, emblema, saldo y deudas. |
| lm_buildings | Nivel de cada instalación; único ludus/tipo. |
| lm_jobs | Obra pagada, fechas, nivel objetivo y estado. |
| lm_staff | Contratos, nivel, salario, alta y baja sin borrar devengo. |
| lm_gladiators | Ficha, dueño actual/anterior, origen, raza, sexo, retrato, medidas, edad y salud. Seis atributos 1–20 en esta misma tabla, elección y fracciones de entrenamiento. |
| lm_events | Formato, fechas, máximo, estado, versión de reglas y semilla. |
| lm_registrations | Una selección manual o automática por ludus/evento. |
| lm_entries | Gladiadores inscritos, táctica, participación efectiva, puesto, premio y resultado médico. Nombre histórico independiente de la ficha. |
| lm_duels | Combates, ronda, fase, participantes por identificadores de inscripción, vencedor y resumen de asaltos sin atributos privados. |
| lm_auctions | Oferta, precio, líder y cierre ampliable. Gladiador único mientras exista. |
| lm_bids | Historial de pujas y ludus ofertante. |
| lm_reveals | Descubrimiento pagado único por usuario/gladiador, hasta cierre. |
| lm_spy_usage | Uso único por usuario/semana. No permite acumular acciones. |
| lm_spy_reports | Informe privado con caducidad; borrado al expirar o borrar el objetivo. |
| lm_ledger | Movimientos, ludus y referencia única para no duplicar cobros o ingresos. |
| lm_batches | Procesos ejecutados una vez: calendario, mercado normal y cierre semanal. |
| lm_attempts | Límite de acceso, clave hash de dirección/usuario, sin guardar IP legible. |
| lm_audit | Acciones de administrador sin contraseñas ni formulario completo. |

```mermaid
erDiagram
    lm_users ||--o| lm_ludus : posee
    lm_ludus ||--o{ lm_gladiators : mantiene
    lm_ludus ||--o{ lm_buildings : construye
    lm_ludus ||--o{ lm_staff : contrata
    lm_ludus ||--o{ lm_ledger : registra
    lm_events ||--o{ lm_entries : inscribe
    lm_events ||--o{ lm_duels : resuelve
    lm_gladiators o|--o{ lm_entries : participa
    lm_gladiators o|--o| lm_auctions : oferta
    lm_auctions ||--o{ lm_bids : recibe
    lm_users ||--o{ lm_spy_usage : consume
    lm_spy_usage ||--o| lm_spy_reports : revela
```

## Invariantes

- No hay otra tabla de habilidades ni duplicado de atributos. Salud y energía de combate son temporales; lesiones y predisposición sí persisten.
- La autorización se confirma junto a recursos iniciales; repetirla no crea otro ludus, saldo o gladiadores.
- Pujas, adjudicación, construcción, contratación, resultados y cierres se confirman en transacción. Una escritura de `lm_meta.write_lock` serializa las decisiones compartidas, también en MySQL.
- El saldo reservado y plazas reservadas se calculan desde las subastas abiertas líderes. No se mantiene un segundo contador que pueda quedar desincronizado.
- Ledger con referencia única: dotación, adjudicación y premios no se pueden repetir. Los cierres semanales tienen identificador único.
- Retirados y neutrales no tienen dueño actual. El dueño anterior solo es referencia, nunca destinatario de premios de Arena.
- Al borrar una ficha a cuarenta, la inscripción histórica conserva nombre/puesto/resultado y su FK de gladiador pasa a NULL. Una subasta sin comprador conserva su fila de cierre, con gladiador NULL. Los informes operativos se eliminan.
- Predisposición médica y progreso no se exportan a páginas públicas, ni como JSON o campos ocultos.

## Datos de NAFLM

El adaptador lee `coaches` al solicitar importación desde el panel. Se conserva `legacy_id`; los hashes antiguos se verifican solo con la contraseña real y se actualizan en la cuenta Ludus después de entrar. No se actualiza ni borra la fila original. Las colisiones de nombres se resuelven con sufijo, sin reemplazar al administrador recién creado.

No hay equivalencia automática entre equipos/partidos deportivos y ludus/eventos. El catálogo e imágenes se reutilizan como recursos, no se importan estadísticas de fútbol como atributos de gladiadores.

## Migraciones y operación

El esquema inicial utiliza `CREATE TABLE IF NOT EXISTS`. Las futuras versiones deben añadir migraciones incrementales con copia previa, sin `DROP TABLE` sobre datos de usuario. `schema_version` indica el punto de partida.

La conexión está en `var/config.php`, fuera de recursos públicos. Las pruebas usan otras bases y sus propios relojes. Consulta [Instalacion.md](Instalacion.md) para cron y copias, y [Verificacion.md](Verificacion.md) para motores realmente ejecutados.
