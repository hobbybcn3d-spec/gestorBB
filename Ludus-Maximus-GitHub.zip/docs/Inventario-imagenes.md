# Inventario de imágenes NAFLM para Ludus Maximus

**Investigación de recursos · 12 de noviembre de 2026.**

Este archivo identifica imágenes existentes, sin modificar código, reglas ni Proyecto.md. Fuente principal: lib/game_data_bb2025.php, catálogo $DEA y atributo is_bigguy. Todos los archivos citados están presentes en images/player_icons.

## 1. Criterio

- Humanos: modelos de humanos del catálogo, incluidos equipos humanos alternativos.
- Orcos, enanos, elfos y goblins: modelos de la especie, no todos los integrantes de un equipo de esa especie.
- Grandotes: todos los iconos utilizados por entradas con is_bigguy = 1.
- Una imagen no incorpora las reglas de su posición de Blood Bowl. Armas, máquinas o balones dibujados son apariencia; no crean equipamiento ni atributos nuevos.

Advertencia de clasificación: Human contiene un Halfling y un Ogre; Orc contiene un Goblin y un Troll; Dwarf contiene Deathroller. No copiar automáticamente todos los iconos de un equipo a la raza homónima.

## 2. Pools recomendados

Las rutas siguientes son relativas a images/player_icons y terminan en .gif.

### Humanos — 22 modelos

- Human: hlineman1.gif, hcatcher1.gif, hthrower1.gif, hblitzer1.gif.
- Amazon: amlineman1.gif, amthrower1.gif, amcatcher1.gif, amblitzer1.gif.
- Imperial Nobility: impline1.gif, impthrower1.gif, impbody1.gif, impnoble.gif.
- Bretonnian: bretsquire.gif, bretcatcher.gif, bretthrower.gif, bretknight.gif.
- Norse de apariencia humana: nlineman1.gif, noberserker1.gif, valkyrie.gif.
- Chaos Renegades humanos: marauder1.gif, maraudthr1.gif.
- Vampire, humano Thrall: vthrall1.gif; el catálogo le atribuye keyword Human.

No incluir hopeful.gif/halflings, beerpig.gif, hombres lobo o vampiros como humanos por pertenecer al mismo equipo.

### Orcos — 4 modelos

olineman1.gif, othrower1.gif, oblitzer1.gif, oblackorc1.gif.

No incluir goblin1.gif ni troll2.gif en esta raza: pertenecen a Goblin y Grandotes respectivamente.

### Elfos — 18 modelos

- Elven Union: eplineman1.gif, epthrower1.gif, epcatcher1.gif, epblitzer1.gif.
- Dark Elf: delineman1.gif, derunner1.gif, deassassin1.gif, deblitzer1.gif, dewitchelf1.gif.
- High Elf: helineman1.gif, hethrower1.gif, hecatcher1.gif, heblitzer1.gif.
- Wood Elf: welineman1.gif, wethrower1.gif, wecatcher2.gif, weblitzer2.gif.
- Renegade Dark Elf: delfrenegade1.gif.

### Enanos — 6 modelos

dlongbeard1.gif, drunner1.gif, dblitzer1.gif, dslayer1.gif, cddwarf1.gif, cddwarf2.gif.

Los dos últimos son variantes Chaos Dwarf del catálogo. Deathroller va a Grandotes por su indicador explícito.

### Goblins — 9 modelos

goblin1.gif, looney1.gif, bombardier1.gif, ooligan.gif, doomdiver.gif, fanatic1.gif, goscrappa1.gif, gobrenegade1.gif, uwgoblin1.gif.

Los Hobgoblins cdhobgoblin1.gif/cdhobgoblin2.gif son especie distinta y no se incluyen por defecto. Snotlings tampoco.

## 3. Grandotes — 19 imágenes con is_bigguy = 1

El nombre de raza será Grandotes, sustituyendo la etiqueta Ogros. La clasificación procede del indicador del catálogo, no únicamente de fuerza o tamaño visual.

| Archivo | Entradas representativas del catálogo | Referencia aproximada |
| --- | --- | --- |
| troll1.gif | Troll; Trained Troll | líneas 195–209 y 819–833 |
| ogre1.gif | Ogre; Ogre Runt Punter | 212–226 y 1831–1845 |
| minotaur1.gif | Minotaur | 229–243 |
| ddeathroller1an.gif | Deathroller | 569–583 |
| treeman1.gif | Altern/Loren Forest Treeman | 910–924 y 2261–2275 |
| tomb_guardian1.gif | Tomb Guardian | 1217–1231 |
| kroxigor1.gif | Kroxigor | 1308–1322 |
| troll2.gif | Troll; Black Orc Trained Troll | 1433–1447 y 3110–3124 |
| snowtroll1.gif | Yhetee | 1666–1680 |
| rtbeast1.gif | Rotspawn | 1757–1771 |
| pact_ogre1.gif | Ogre Blocker; Chaos Renegades Ogre | 1814–1828 y 2420–2434 |
| umummy1.gif | Mummy | 1939–1953 |
| vargheist.gif | Vargheist | 2046–2060 |
| ratogre1.gif | Rat Ogre | 2153–2167 |
| chaostroll1.gif | Chaos Renegades Troll | 2403–2417 |
| slannkrox1.gif | Slann Kroxigor | 2544–2558 |
| warptroll1.gif | Underworld Troll | 2685–2699 |
| snotling_pumpwagon1.gif | Pump Wagon | 3019–3033 |
| bloodspawn.gif | Bloodspawn | 3309–3323 |

Deathroller y Pump Wagon son máquinas, pero NAFLM los marca expresamente big guy. Se incluyen porque el usuario pide todos los considerados big guy. Su retrato no introduce armas o vehículos en las reglas del combate.

Mummy y Tomb Guardian están marcados is_bigguy incluso cuando pos_type es BK; por tanto clasificar por pos_type = BG solamente perdería imágenes válidas.

## 4. Iconos de raza

- Humanos: images/race_icons/human.png.
- Orcos: images/race_icons/orc.png.
- Elfos: images/race_icons/elf.png.
- Enanos: images/race_icons/dwarf.png.
- Goblins: images/race_icons/goblin.png.
- Grandotes: puede reutilizarse images/race_icons/ogres.png como icono genérico; la etiqueta del juego cambia a Grandotes.

## 5. Dimensiones observadas y presentación

Las imágenes son sprites pequeños, no ilustraciones grandes. Muestras verificadas:

| Imagen | Dimensión |
| --- | --- |
| hlineman1.gif | 28 × 28 |
| amblitzer1.gif | 28 × 28 |
| ogre1.gif | 38 × 38 |
| ddeathroller1an.gif | 38 × 38 |
| troll1.gif | 40 × 38 |
| bloodspawn.gif | 42 × 42 |
| tomb_guardian1.gif | 31 × 34 |

Recomendación visual: contenedor uniforme, object-fit contain y escalado pixelado/nearest-neighbor; no estirar todos los sprites a la misma proporción. En tablas compactas bastan contenedores de unos 48–64 px.

No hay un conjunto de retratos separado por sexo para todas las razas. El sexo del personaje es un dato de generación; no deducirlo automáticamente del nombre de archivo.

## 6. Límites de esta investigación

- Se ha comprobado catálogo, presencia de archivos y dimensiones de muestras.
- No se han alterado los archivos de imagen ni generado imágenes nuevas.
- El catálogo proporciona imágenes de Blood Bowl; la reutilización no garantiza una estética romana sin elementos deportivos.
- Los sprites reflejan distintas subespecies, pero Grandotes es una única raza de juego según el cambio pedido.
- Al retirar o cambiar raza de presentación, conservar la ruta de imagen seleccionada para que un mismo personaje no cambie aleatoriamente de retrato cada vez que se consulta.
