# Reutilización de NAFLM para Ludus Maximus

Investigación local de solo lectura. No se han abierto conexiones de base de datos ni ejecutado instaladores. No se incluyen datos de usuarios, contraseñas ni valores privados de configuración.

**Actualización de implementación 1.0.0:** el párrafo anterior describe la investigación inicial. Después se creó el adaptador en `Game::importLegacy` y se probó en MariaDB aislado con una tabla coaches de prueba. No se ha conectado ni modificado la base de producción. El índice original examinado está ahora conservado en `index.naflm.php`. Véanse [Proyecto.md](../Proyecto.md), [Instalacion.md](Instalacion.md) y [Verificacion.md](Verificacion.md).

## Archivos examinados

- lib/mysql.php: definición del esquema, conexión e instalación.
- lib/class_coach.php: autenticación y niveles de permiso.
- lib/class_tablehandler.php: creación de tablas.
- header.php e index.php: arranque y dependencias heredadas.
- lib/settings_default.php: nombres de variables y opciones por defecto.
- settings.php: se extrajeron únicamente nombres de variables de conexión, sin mostrar valores.

## Conexión existente

Variables exactas:

| Variable | Uso |
| --- | --- |
| db_host | Servidor MySQL. |
| db_name | Base de datos. |
| db_user | Usuario de conexión. |
| db_passwd | Contraseña de conexión. |
| db_version | Versión del esquema NAFLM; no confundir con versión de Ludus Maximus. |

No se encontró un prefijo de tablas, puerto o socket configurado en estos archivos. Las consultas usan coaches, teams y players directamente.

Un adapter PDO puede reutilizar servidor y base definidos por esas variables y crear tablas nuevas con prefijo lm_. Debe evitar imprimir la configuración y evitar ejecutar el arranque legacy completo solo para obtener cuatro valores de conexión.

## Usuarios existentes: coaches

| Columna | Esquema local declarado |
| --- | --- |
| coach_id | MEDIUMINT UNSIGNED, clave primaria autoincremental. |
| name | VARCHAR(60), nombre de acceso. |
| passwd | VARCHAR(255) en el esquema actualizado; una instalación antigua puede conservar VARCHAR(32). |
| ring | TINYINT UNSIGNED, permiso global, valor inicial cero. |
| retired | BOOLEAN, valor inicial cero; una cuenta retirada no puede entrar. |
| realname | VARCHAR(60), no necesario para el registro nuevo. |
| mail | VARCHAR(129), no obligatorio en Ludus Maximus. |
| phone | VARCHAR(25), no necesario. |
| settings | VARCHAR(320), opciones serializadas en el formato heredado. |
| activation_code | Código de recuperación heredado, no reutilizar como token moderno. |
| remember_token_hash | CHAR(64), hash de token persistente. |
| remember_token_expires | DATETIME, vencimiento del token heredado. |

El permiso global administrador es Coach::T_RING_GLOBAL_ADMIN = 5. Existe también permiso local de liga con valor cinco, guardado en memberships; no confundirlo con administrador global.

## Verificación de contraseñas

Coach::checkPasswd() contempla:

1. Si el valor almacenado tiene treinta y dos caracteres hexadecimales, comparar mediante hash_equals contra md5 de la contraseña presentada.
2. En otro caso usar password_verify con la contraseña presentada y el hash moderno.
3. Tras acceso correcto con MD5, actualizar a password_hash si la columna legacy ya admite su longitud.
4. Coach::login() impide acceso si retired está activo.

El parámetro MD5 que permanece en la firma se conserva por compatibilidad de llamadas; el método documenta que recibe contraseña real, no un hash reutilizable como credencial. No ofrecer un modo de autenticación que acepte directamente el hash guardado.

## Adapter propuesto para Ludus Maximus

- Leer coaches con PDO y consultas preparadas.
- Copiar solo lo necesario a lm_users, incluyendo un identificador original único, nombre, hash, rol y estado.
- Mantener importación idempotente mediante legacy_coach_id único.
- No sobrescribir al administrador inicial de Ludus Maximus si coincide un nombre importado.
- Conservar desactivación de retired; aplicar la política de aprobación acordada al importar.
- Verificar MD5 únicamente para hashes legacy detectados, y reescribir con password_hash moderno en lm_users al primer acceso válido.
- Usar columna para hashes de al menos 255 caracteres en la tabla nueva.
- No modificar coaches ni su contraseña por efecto secundario de un acceso a Ludus Maximus.
- No reutilizar las cookies antiguas obblmuserid / obblmpasswd ni compartir sesiones.
- Prever nombres que solo difieran en mayúsculas: el cambio de nombre legacy usa comparación BINARY, mientras la tabla nueva puede exigir unicidad normalizada.
- No copiar datos de contacto que el juego no necesita.

## Instalación y compatibilidad

No incluir directamente header.php, lib/mysql.php o Coach en el arranque moderno:

- mysql_connect, mysql_query y otras funciones mysql_* no están disponibles en PHP moderno.
- lib/mysql.php y class_tablehandler.php usan create_function.
- index.php usa get_magic_quotes_gpc.
- header.php inicia sesiones, carga módulos, conecta y valida tablas durante el arranque.
- El instalador antiguo requiere borrar install.php antes de usar su arranque normal.

El método Table::createTable() de lib/class_tablehandler.php ejecuta DROP TABLE IF EXISTS antes de crear. Por tanto, NO reutilizar setup_database() como migración de un sitio existente.

Para las tablas lm_ usar migraciones propias, CREATE TABLE IF NOT EXISTS y actualizaciones controladas. Para MySQL, elegir explícitamente InnoDB para las operaciones transaccionales; el creador legacy no declara motor.

Conservar el código NAFLM de referencia y sus tablas permite reutilizar recursos y cuentas sin convertir toda su instalación a PHP moderno ni reemplazar silenciosamente sus datos.

## Límites de la comprobación

El repositorio contiene la definición del esquema, no una base viva verificada. No se ha comprobado qué columnas tiene una instalación concreta ni que existan usuarios reales. El adapter deberá detectar la tabla coaches y las columnas necesarias en ejecución y tratar su ausencia sin romper una instalación nueva.
