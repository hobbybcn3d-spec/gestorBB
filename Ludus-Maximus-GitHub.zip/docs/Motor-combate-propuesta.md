# Ludus Maximus — Motor de combate implementado

**Especificación v1.0.0 · 12 de noviembre de 2026 · ludus/Engine.php.**

El usuario confirma las ocho decisiones y cambia la iniciativa a d20. Se integran los ajustes de diseño delegados para que pesen más los atributos. [Proyecto.md](../Proyecto.md) conserva las reglas vigentes y [Azar-d20.md](Azar-d20.md) define toda aleatoriedad del juego. El motor está implementado en `ludus/Engine.php`; la integración con eventos y datos, en `ludus/Game.php`. La comprobación de referencia al final es anterior a la implementación; los resultados de ejecución actuales están en [Verificacion.md](Verificacion.md).

## 1. Lo que se mantiene

- Seis atributos 1–20; habilidades y atributos son lo mismo.
- Táctica seleccionada antes del evento; sin órdenes durante la pelea.
- Salud y energía son estados temporales, no nuevos atributos entrenables.
- Salud inicial derivada de constitución y peso; energía inicial 100.
- Battle royale todos contra todos y selección 80/20 acordada.
- Máximo 50 asaltos por duelo y 75 por battle royale; después desempate acordado.
- Inconsciencia por salud en cero; lesión y muerte solo tras resolver el evento.
- Vencedores de individuales recuperan salud y energía para el siguiente duelo; misma recuperación para el duelo por tercero.

## 2. Notación

- limitar(x, a, b): recorta x para que quede entre a y b.
- d20: entero uniforme entre uno y veinte. U20 = (2 × d20 − 21) / 19. R3: entero 1–8.000 compuesto por tres d20, según Azar-d20.md.
- A: atacante; D: defensor.
- F, AG, C, R, CO y S: fuerza, agilidad, constitución, resistencia, consistencia y suerte.
- Peso normalizado P = limitar((peso_kg − 80) / 150, −1, 1), como en el diseño existente.

Las probabilidades se expresan entre 0 y 1: 0,05 son cinco puntos porcentuales. No confundirlos con un aumento relativo del 5 %.

## 3. Consistencia: un estado por pelea

Regla confirmada y adaptación d20:

1. Al empezar cada pelea, calcular amplitud = 0,10 − 0,09 × (CO − 1) / 19.
2. Tirar un d20 y calcular rendimiento = 1 + amplitud × U20.
3. Mantener ese mismo rendimiento durante toda esa pelea.

| Consistencia | Variación máxima del rendimiento |
| --- | --- |
| 1 | ±10 % |
| 10 | ±5,74 % aproximadamente |
| 20 | ±1 % |

Aplicarlo solo a fuerza y agilidad. No modificar constitución, resistencia, suerte, altura, peso ni riesgo médico.

En battle royale se sortea una vez para toda la pelea. En individuales se sortea de nuevo en cada duelo, incluido tercero. Nunca se reescriben los atributos guardados por esta variación temporal.

Esto representa regularidad: consistencia alta reduce malos y buenos extremos, no añade una bonificación permanente al promedio.

## 4. Fatiga

Energía E entre 0 y 100. Factor de fatiga:

fatiga(E) = 0,75 + 0,25 × limitar(E / 25, 0, 1).

| Energía actual | Factor |
| --- | ---: |
| 100 o 25 | 1,00 |
| 20 | 0,95 |
| 10 | 0,85 |
| 0 | 0,75 |

Atributos temporales efectivos:

- F efectiva = F × rendimiento × fatiga.
- AG efectiva = AG × rendimiento × fatiga.

No aplicar de nuevo un segundo porcentaje de cansancio al daño o acierto. Los efectos de fuerza/agilidad efectiva ya lo contienen.

Los valores efectivos pueden superar temporalmente el atributo nominal o bajar de uno por modificadores. No son valores almacenados ni subidas de nivel.

## 5. Iniciativa

Al comenzar cada asalto:

1. Considerar gladiadores conscientes.
2. Calcular AG efectiva con la energía de ese momento.
3. Iniciativa = 2 × AG efectiva + 1d20. El factor dos es el ajuste delegado para dar más peso a la preparación.
4. Ordenar de mayor a menor; empate por AG efectiva, después consistencia y después sorteo d20 sin sesgo.
5. Cada gladiador conserva como máximo una acción ordinaria en ese asalto.

Se recalcula cada asalto; no fijar para toda la pelea. El orden no se reordena a mitad de asalto por energía que cambie después.

La suerte no se suma también aquí: ya interviene en acierto con su límite acordado. La táctica no añade otro bono de iniciativa en esta versión.

Ejemplo sin fatiga y con rendimiento 1: agilidad 6 y d20 de 3 dan iniciativa 15; agilidad 4 y d20 de 8 dan 16. La agilidad pesa más, pero la tirada aún puede invertir órdenes cercanos.

Si alguien queda inconsciente antes de su acción, pierde esa acción. No ataca después de caer.

## 6. Gasto y recuperación de energía

Coste ordinario:

coste = (6 − 0,2 × R) × (1 + 0,10 × P) × factor de gasto de táctica.

| Resistencia, peso 80 kg y Normal | Coste por ataque |
| --- | ---: |
| 1 | 5,8 |
| 5 | 5 |
| 10 | 4 |
| 20 | 2 |

Factores de gasto: Normal 1; Agresivo 1,20; Defensivo 0,90; Contraataque 1; Evasivo 1,10.

Regla confirmada y adaptación d20:

- Un ataque válido gasta todo el coste, acierte o falle.
- La esquiva pasiva no cobra otro coste; su esfuerzo está representado en el factor Evasivo de la acción ordinaria.
- Contraatacar sí paga el coste de otro ataque.
- Solo se puede atacar si E es al menos el coste; puede quedar exactamente en cero después de pagarlo.
- Si no alcanza para el ataque ordinario, recuperar aliento automáticamente.
- Recuperación = 10 + R / 2, con tope de energía 100.
- Recuperar ocupa la acción ordinaria, sin daño ni recuperación de salud.
- Después de elegir recuperación, no puede contraatacar durante el resto de ese asalto. La prohibición se limpia al empezar el siguiente.
- No hay recuperación pasiva adicional por asalto ni por golpear o esquivar.

Ejemplo con R 5: coste Normal a 80 kg = 5; recuperación = 12,5. Si empieza su acción con energía 3, termina recuperando hasta 15,5 y no ataca.

## 7. Acierto y daño

Se mantienen los coeficientes anteriores, concretando el orden:

### 7.1. Acierto

p = limitar(
0,60
+ limitar(0,20 × (AG efectiva A − AG efectiva D) / 19, −0,20, 0,20)
+ limitar(0,0005 × (altura_cm A − altura_cm D), −0,05, 0,05)
+ 0,03 × P del defensor
+ exposición de táctica del defensor
+ 0,05 × (S A − S D) / 19,
0,10, 0,90).

| Táctica del defensor | Exposición añadida al acierto rival |
| --- | ---: |
| Normal | 0 |
| Agresivo | +0,05 |
| Defensivo | −0,05 |
| Contraataque | 0 |
| Evasivo | −0,08 |

Convertir p en k = redondear(8.000 × p). Tirar R3 y acertar si R3 > 8.000 − k, conservando los porcentajes finos. Un fallo se trata como esquiva a efectos de Contraataque.

La iniciativa no se vuelve a sumar al acierto. La suerte no añade luego otra tirada de daño o crítico.

### 7.2. Daño de un ataque acertado

Daño = (3 + 0,6 × F efectiva A) × (1 + 0,05 × P A) × factor de daño de táctica A × (1 + 0,05 × U20).

Factores: Normal 1; Agresivo 1,15; Defensivo 0,85; Contraataque 0,90; Evasivo 0,80.

Salud inicial = (60 + 4 × constitución) × (1 + 0,10 × P).

Restar el daño a la salud, sin bajar de cero. En cero, inconsciente y fuera del combate. No tirar lesión o muerte en ese momento.

No hay armadura, equipo, daño crítico o habilidad especial añadidos. El tamaño se representa por altura/peso, no por otro bono racial duplicado.

## 8. Contraataque

Límite confirmado:

- Solo quien usa Contraataque.
- Debe estar consciente, no estar recuperando aliento y tener energía para otro ataque.
- Tras esquivar un ataque ordinario, responde inmediatamente si el d20 sale 17–20: 20 %.
- Como máximo una respuesta ejecutada por gladiador y asalto.
- Los sorteos fallidos de respuesta no gastan energía; puede tener otra oportunidad si vuelve a esquivar, hasta ejecutar una.
- La respuesta cuesta energía y usa las mismas fórmulas de acierto/daño con su táctica.
- No consume la acción ordinaria que aún pudiera tener.
- Un contraataque no genera otro contraataque, aunque falle.
- Si deja inconsciente al atacante original, se elimina antes de cualquier acción posterior.

Limitar a una evita cadenas de respuestas cuando muchos gladiadores eligen al mismo objetivo.

## 9. Orden de cálculo

### Preparar pelea

1. Recuperar atributos, táctica, altura y peso válidos.
2. Calcular P, salud inicial y energía 100.
3. Sortear rendimiento de consistencia una sola vez por pelea.

### Cada asalto

1. Limpiar marcas de recuperación y contraataque usado.
2. Calcular iniciativas y orden usando la energía al comenzar.
3. Recorrer ese orden, omitiendo a quien ya esté inconsciente.
4. Antes de la acción, comprobar si ya terminó la pelea.

### Acción ordinaria de un gladiador

1. Calcular su coste con resistencia, peso y táctica.
2. Si no alcanza energía, recuperar y terminar su acción.
3. Seleccionar un objetivo consciente válido con el 80/20 y sus alternativas.
4. Guardar energía actual de atacante y defensor para calcular sus valores efectivos de este ataque.
5. Cobrar coste del atacante.
6. Calcular acierto con los valores efectivos guardados y sortear.
7. Si acierta, calcular daño, descontar salud y comprobar inconsciencia.
8. Si falla, comprobar reacción de Contraataque, con su energía actual y límites.
9. Registrar solo lo necesario para el resumen de asalto.

El atacante no recibe una penalización de fatiga por el coste del golpe que acaba de pagar hasta la siguiente acción/reacción: se usa su energía anterior al pago. El defensor se evalúa con la energía que tiene en ese instante.

Una reacción repite el cálculo básico con roles invertidos, su propio estado antes de pagar y sin permitir reacciones encadenadas.

### Terminar

1. Si queda un gladiador en pie, resolver victoria.
2. Si se alcanza el límite de asaltos, aplicar desempate ya acordado.
3. En individuales preparar siguiente duelo y recuperación según formato.
4. Al terminar el evento completo: podio, evaluación médica única, premios y crónica final.

Mantener precisión interna y redondear solo al mostrar. La comprobación de inconsciencia usa salud real menor o igual a cero, no el texto redondeado de la pantalla.

## 10. Confirmaciones y ajustes de esta revisión

El usuario confirma gasto al fallar, fatiga, recuperación automática, defensa sin gasto adicional, límite de contraataques y pérdida de acción por inconsciencia. La iniciativa se cambia a d20.

Ajustes de diseño delegados:

- Iniciativa 2 × AG efectiva + 1d20, para que el cambio desde d10 no duplique el peso relativo del azar.
- Daño con variación limitada a ±5 % en lugar de ±10 %.
- Consistencia resuelta con una sola cara d20 transformada en U20.
- Porcentajes finos resueltos con tres d20 en base veinte, sin alterar los riesgos médicos acordados.
- No introducir críticos o fallos automáticos por caras uno o veinte.

## 11. Comprobación de referencia limitada

Se hicieron cálculos de referencia en memoria, sin crear el motor del repositorio:

| Atributos entrenables de A | Atributos entrenables de B | Duelos | Victorias de A |
| --- | --- | ---: | ---: |
| Todos a 4 | Todos a 4 | 3.000 | 49,90 % |
| Todos a 6 | Todos a 4 | 3.000 | 94,27 % |
| Todos a 8 | Todos a 4 | 3.000 | 99,83 % |

Condiciones: ambos humanos, 180 cm y 80 kg, suerte diez, modo Normal, cinco atributos iguales al valor indicado, energía cien, factor de consistencia d20, gasto y recuperación confirmados, iniciativa doble, acierto R3, daño ±5 % y límite cincuenta asaltos. Semilla inicial del cálculo: 0x31a20.

Son ejemplos controlados, no probabilidades universales ni validación de todas las razas o tácticas. Aumentar cinco atributos a la vez acumula ventajas de daño, aguante, precisión y energía; no implica que subir un solo punto dé esas tasas.

No se han comprobado todavía battle royale, contraataques, costes de todas las tácticas, alturas/pesos diferentes ni economía. El código definitivo deberá probar esos casos.

## 12. Pendientes reales

- Simular todas las razas y tácticas con sus rangos reales de nacimiento y progresión.
- Comprobar la frecuencia de agotamiento, recuperaciones y desempates por límite.
- Cerrar distribución por gravedad de lesión y cálculo semanal médico.
- Implementar el motor con comentarios breves y mapa de archivos cuando corresponda.
