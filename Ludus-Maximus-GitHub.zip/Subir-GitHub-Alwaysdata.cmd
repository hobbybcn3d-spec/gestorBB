@echo off
rem PUB: primera instalacion desde el ZIP GitHub, sin FileZilla ni PHP local.
setlocal
cd /d "%~dp0"
where ssh >nul 2>nul
if errorlevel 1 goto faltan
where scp >nul 2>nul
if errorlevel 1 goto faltan
where tar >nul 2>nul
if errorlevel 1 goto faltan
if not exist "%~dp0var\deployment-manifest.json" goto paquete
rem PUB: solo estos archivos pueden viajar; nunca la base ni claves de var.
if not exist "%~dp0var\publicacion" mkdir "%~dp0var\publicacion"
tar -a -cf "%~dp0var\publicacion\codigo-github.zip" --no-recursion -T "%~dp0var\deployment-files.txt"
if errorlevel 1 goto error
echo.
echo Subida a la cuenta alwaysdata hobbybcn3d.
echo Escribe tu clave SSH cuando la consola la pida, no en el chat.
echo Puede solicitarla tres veces. No se muestran caracteres al escribir.
echo Esta opcion instala un juego nuevo y conserva la web NAFLM actual.
echo.
rem PUB: preparar el destino privado de la transferencia.
ssh hobbybcn3d@ssh-hobbybcn3d.alwaysdata.net python3 - prepare < "%~dp0deploy\alwaysdata.py"
if errorlevel 1 goto error
rem PUB: transferir el codigo comprimido con OpenSSH de Windows.
scp "%~dp0var\publicacion\codigo-github.zip" hobbybcn3d@ssh-hobbybcn3d.alwaysdata.net:.ludus-upload/package.zip
if errorlevel 1 goto error
rem INS: verificar e instalar sin sustituir un directorio que ya exista.
ssh hobbybcn3d@ssh-hobbybcn3d.alwaysdata.net python3 - install-clean < "%~dp0deploy\alwaysdata.py"
if errorlevel 1 goto error
echo.
echo Archivos instalados. Configura el sitio siguiendo README.md.
echo Despues abre https://hobbybcn3d.alwaysdata.net/ludus/install.php
goto terminar
:paquete
echo Primero extrae el archivo Ludus-Maximus-GitHub.zip con todos sus archivos.
echo Este lanzador se ejecuta desde la carpeta extraida.
goto terminar
:faltan
echo Faltan OpenSSH o tar de Windows. Consulta la alternativa del README.md.
goto terminar
:error
echo Publicacion detenida. Revisa el mensaje anterior. No repitas si ya existe Ludus.
:terminar
pause
