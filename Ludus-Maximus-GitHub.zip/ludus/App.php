<?php
declare(strict_types=1); // DOC: controlador HTTP con autenticación y permisos centralizados.
namespace Ludus; // DOC: las páginas nunca incluyen el arranque mysql_* de NAFLM.

final class App
{
    public Database $db;public Game $game;public ?array $user=null;public ?array $ludus=null;public string $lang='es'; // USR: contexto validado de esta petición.
    public function __construct()
    {
        $config=require LUDUS_CONFIG_FILE;$this->db=new Database($config);$this->game=new Game($this->db,time()); // BD: configuración fuera de recursos públicos; QA usa una base independiente.
        if(isset($_SESSION['uid'])){$this->user=$this->db->one('SELECT * FROM lm_users WHERE id=?',[(int)$_SESSION['uid']]);if($this->user&&$this->user['status']==='suspended'){unset($_SESSION['uid']);$this->user=null;}} // USR: permisos no dependen de datos enviados por navegador.
        $this->lang=$_SESSION['lang']??($this->user['lang']??'es');if(!in_array($this->lang,['es','en'],true)){$this->lang='es';} // IDI: español predeterminado.
        if($this->user){$this->db->run('UPDATE lm_users SET last_seen=? WHERE id=?',[$this->game->now,$this->user['id']]);$this->ludus=$this->game->ludus((int)$this->user['id']);} // CAL: actividad real para inscripción automática.
        if((int)$this->db->meta('last_tick','0')<$this->game->now-30){$this->game->tick();if($this->user){$this->ludus=$this->game->ludus((int)$this->user['id']);}} // CAL: tareas por visita complementadas por cron.
    }
    public function tr(string $es,string $en): string {return $this->lang==='en'?$en:$es;} // IDI: textos de interfaz sin servicios externos.
    public function admin(): bool {return $this->user!==null&&$this->user['role']==='admin'&&$this->user['status']==='active';} // ADM: estado y rol comprobados juntos.
    public function playing(): bool {return $this->user!==null&&$this->user['status']==='active'&&$this->ludus!==null;} // USR: pendiente no equivale a jugador.
    public function redirect(string $route='home',array $params=[]): never {header('Location: index.php?'.http_build_query(['r'=>$route]+$params),true,303);exit;} // USR: PRG impide reenviar formularios al recargar.
    public function flash(string $message,bool $error=false): void {$_SESSION['flash']=['message'=>$message,'error'=>$error];} // UI: respuesta directa a una acción, no avisos de actividad.
    private function needAdmin(): void {if(!$this->admin()){throw new \RuntimeException($this->tr('Acceso reservado al administrador.','Administrator access required.'));}} // ADM: también protege peticiones directas.
    private function needLudus(): int {if(!$this->playing()){throw new \RuntimeException($this->tr('Tu cuenta necesita autorización.','Your account requires approval.'));}return (int)$this->ludus['id'];} // USR: regla común a todas las acciones de juego.
    private function token(): void {if(!isset($_POST['csrf'])||!hash_equals($_SESSION['csrf'],(string)$_POST['csrf'])){throw new \RuntimeException($this->tr('La sesión del formulario caducó. Recarga la página.','The form session expired. Reload the page.'));}} // USR: CSRF obligatorio en toda escritura.
    public function run(): void
    {
        if($_SERVER['REQUEST_METHOD']==='POST'){$this->post();} // USR: un único manejador de escrituras.
        $route=(string)($_GET['r']??'home'); // UI: ruta por consulta, compatible con alojamiento sin rewrites.
        if($route==='emblem'){$this->emblem();return;} // IMG: entrega controlada de archivos privados procesados.
        $public=['home','login','register','rivals','gladiator','about']; // USR: ninguna otra página admite visitas anónimas.
        if(!$this->user&&!in_array($route,$public,true)){$this->redirect('login');} // USR: acceso necesario para pantallas privadas.
        if($this->user&&$this->user['must_change']&&$route!=='password'){$this->redirect('password');} // USR: temporal exige nueva contraseña.
        if($this->user&&$this->user['status']==='pending'&&!in_array($route,['home','rivals','gladiator','password','about'],true)){$this->redirect('home');} // USR: cuenta pendiente solo ve estado y contenido público.
        if($route==='admin'&&!$this->admin()){http_response_code(403);$route='forbidden';} // ADM: no renderizar datos administrativos a usuarios.
        (new View($this))->render($route); // UI: vistas reciben contexto, no una identidad inventada.
    }
    private function post(): never
    {
        $action=(string)($_POST['action']??'');$back=(string)($_POST['back']??'home');$allowed=['home','login','register','ludus','gladiators','training','staff','calendar','results','market','spy','economy','admin','password'];if(!in_array($back,$allowed,true)){$back='home';} // USR: no permitir redirecciones externas.
        try{
            $this->token(); // USR: validar antes de cualquier cambio de estado.
            if($this->user&&$this->user['must_change']&&!in_array($action,['password','logout','language'],true)){$this->redirect('password');} // USR: una contraseña temporal tampoco puede saltarse el cambio enviando un POST directo.
            if($action==='language'){$lang=$_POST['lang']??'es';if(!in_array($lang,['es','en'],true)){throw new \RuntimeException('Idioma no válido.');}$_SESSION['lang']=$lang;if($this->user){$this->db->update('lm_users',['lang'=>$lang],(int)$this->user['id']);}$this->redirect($back);} // IDI: cambiar idioma no duplica datos.
            if($action==='logout'){$_SESSION=[];session_regenerate_id(true);$_SESSION['csrf']=bin2hex(random_bytes(32));$this->redirect('home');} // USR: cerrar sin borrar cuenta o ludus.
            if($action==='login'){$this->login();} // USR: autenticar solo contraseña real, también legado.
            if($action==='register'){$this->register();} // USR: cuenta pendiente sin dotación antes de aprobar.
            if($action==='password'){$this->password();} // USR: renovación de contraseña temporal o propia.
            if(str_starts_with($action,'admin_')){$this->needAdmin();$this->adminPost($action);$this->flash($this->tr('Cambio administrativo guardado.','Administrative change saved.'));$this->redirect('admin');} // ADM: todos los controles pasan por el mismo permiso.
            $lid=$this->needLudus(); // USR: bloquear escrituras a pendientes y anónimos.
            if($action==='train'){$choices=$_POST['training']??[];$this->db->atomic(function()use($choices,$lid){foreach($choices as $id=>$attr){$this->game->train($lid,(int)$id,(string)$attr);}});} // ENT: solo actualiza elecciones del propio ludus.
            elseif($action==='retire'){$this->game->retire($lid,(int)$_POST['id']);} // RET: retiro irreversible confirmado por formulario.
            elseif($action==='build'){$this->game->build($lid,(string)$_POST['type']);} // LUD: obra pagada y sin cancelación.
            elseif($action==='hire'){$this->game->hire($lid,(string)$_POST['type'],(int)$_POST['level']);} // ECO: gasto y contrato dentro de transacción.
            elseif($action==='fire'){$this->game->fire($lid,(int)$_POST['id']);} // ECO: mantiene devengo del trabajador despedido.
            elseif($action==='bid'){$this->game->bid($lid,(int)$_POST['auction'],(int)$_POST['amount']);} // MER: la cifra recibida se revalida contra la oferta actual.
            elseif($action==='reveal'){$this->game->reveal((int)$this->user['id'],$lid,(int)$_POST['auction']);$back='spy';} // ESP: informe privado hasta cierre de subasta.
            elseif($action==='spy'){$this->game->spy((int)$this->user['id'],$lid,(int)$_POST['target']);} // ESP: una acción semanal gratuita.
            elseif($action==='event_register'){$players=$_POST['players']??[];$choices=[];foreach($players as $id){$choices[(int)$id]=(string)($_POST['modes'][$id]??'normal');}$this->game->registerEvent($lid,(int)$_POST['event'],$choices);$this->flash($this->tr('Selección y tácticas guardadas.','Roster and tactics saved.'));$this->redirect('calendar',['event'=>(int)$_POST['event']]);} // CAL: selección manual explícita.
            elseif($action==='rename'){$name=trim((string)($_POST['name']??''));if(mb_strlen($name)<3||mb_strlen($name)>60){throw new \RuntimeException('El nombre debe tener entre 3 y 60 caracteres.');}$this->db->update('lm_ludus',['name'=>$name],$lid);if(isset($_FILES['logo'])&&$_FILES['logo']['error']!==UPLOAD_ERR_NO_FILE){$this->uploadLogo($lid);}} // IMG: imagen opcional y nombre de ludus.
            elseif($action==='pay_debt'){$this->db->atomic(function()use($lid){$debt=(int)$this->db->value('SELECT maintenance_debt FROM lm_ludus WHERE id=?',[$lid]);$pay=min($debt,max(0,$this->game->available($lid)));if(!$pay){throw new \RuntimeException('No hay deuda o dinero disponible.');}$this->game->debit($lid,$pay,'debt','Liquidación manual','debt:'.bin2hex(random_bytes(12)));$this->db->run('UPDATE lm_ludus SET maintenance_debt=maintenance_debt-? WHERE id=?',[$pay,$lid]);});} // ECO: liquidación sin consumir reservas.
            elseif($action==='loan'){$this->db->atomic(function()use($lid){$l=$this->db->one('SELECT * FROM lm_ludus WHERE id=?',[$lid]);if($this->game->roster($lid)||(int)$l['balance']>=800||$l['loan_debt']||$this->db->one('SELECT id FROM lm_ledger WHERE ref_key=?',['recovery:'.$lid])){throw new \RuntimeException('El anticipo solo está disponible una vez, sin gladiadores ni fondos.');}$this->db->run('UPDATE lm_ludus SET balance=balance+2000,loan_debt=2000 WHERE id=?',[$lid]);$this->db->insert('lm_ledger',['ludus_id'=>$lid,'amount'=>2000,'type'=>'loan','label'=>'Anticipo único de la Arena','ref_key'=>'recovery:'.$lid,'created_at'=>$this->game->now]);});} // ECO: vía de recuperación sin regalar gladiadores ni repetir anticipos.
            else{throw new \RuntimeException($this->tr('Acción no válida.','Invalid action.'));} // USR: no invocar funciones por nombre enviado por usuario.
            $this->flash($this->tr('Cambios guardados.','Changes saved.')); // UI: resultado del formulario actual.
        }catch(\Throwable $e){error_log('Ludus action '.$action.': '.$e->getMessage());$message=$e instanceof \PDOException?$this->tr('No se pudo completar la operación. No se han aplicado cambios parciales.','The operation could not be completed. No partial changes were applied.'):$e->getMessage();$this->flash($message,true);} // USR: sin consultas ni trazas privadas en pantalla.
        $this->redirect($back); // USR: terminar con redirección segura.
    }
    private function login(): never
    {
        $name=mb_strtolower(trim((string)($_POST['username']??'')),'UTF-8');$password=(string)($_POST['password']??'');$key=hash('sha256',($_SERVER['REMOTE_ADDR']??'local').'|'.$name);$attempt=$this->db->one('SELECT * FROM lm_attempts WHERE attempt_key=?',[$key]); // USR: límite de intentos sin guardar IP legible.
        if($attempt&&(int)$attempt['failures']>=10&&(int)$attempt['last_at']>$this->game->now-900){throw new \RuntimeException($this->tr('Demasiados intentos. Espera quince minutos.','Too many attempts. Wait fifteen minutes.'));} // USR: frenar pruebas de contraseñas.
        $u=$this->db->one('SELECT * FROM lm_users WHERE username_key=?',[$name]);$valid=false; // USR: no revelar existencia de cuenta al fallar.
        if($u){$hash=$u['password_hash'];$valid=strlen($hash)===32&&ctype_xdigit($hash)?hash_equals(strtolower($hash),md5($password)):password_verify($password,$hash);} // USR: solo compatibilidad de verificación con el MD5 heredado.
        if(!$valid||$u['status']==='suspended'){if($attempt){$fail=(int)$attempt['last_at']<$this->game->now-900?1:(int)$attempt['failures']+1;$this->db->run('UPDATE lm_attempts SET failures=?,last_at=? WHERE attempt_key=?',[$fail,$this->game->now,$key]);}else{$this->db->run('INSERT INTO lm_attempts(attempt_key,failures,last_at) VALUES(?,?,?)',[$key,1,$this->game->now]);}throw new \RuntimeException($this->tr('Usuario o contraseña incorrectos.','Incorrect username or password.'));} // USR: fallo controlado y no enumeración.
        if(password_needs_rehash($u['password_hash'],PASSWORD_DEFAULT)){$this->db->update('lm_users',['password_hash'=>password_hash($password,PASSWORD_DEFAULT)],(int)$u['id']);} // USR: actualizar hashes antiguos tras comprobar contraseña.
        $this->db->run('DELETE FROM lm_attempts WHERE attempt_key=?',[$key]);session_regenerate_id(true);$_SESSION['uid']=(int)$u['id'];$_SESSION['csrf']=bin2hex(random_bytes(32));$_SESSION['lang']=$u['lang'];$this->redirect($u['must_change']?'password':'home'); // USR: sesión nueva después de autenticar.
    }
    private function register(): never
    {
        $name=trim((string)($_POST['username']??''));$password=(string)($_POST['password']??''); // USR: solo los dos campos acordados.
        if(!preg_match('/^[\p{L}\p{N}_-]{3,24}$/u',$name)||strlen($password)<8||strlen($password)>128){throw new \RuntimeException($this->tr('Usuario de 3–24 caracteres y contraseña de 8–128.','Username 3–24 characters; password 8–128.'));} // USR: límites claros y sin correo.
        $key=mb_strtolower($name,'UTF-8');if($this->db->one('SELECT id FROM lm_users WHERE username_key=?',[$key])){throw new \RuntimeException($this->tr('Ese nombre de usuario ya existe.','That username is already taken.'));} // USR: unicidad independiente de mayúsculas.
        $id=$this->db->insert('lm_users',['username'=>$name,'username_key'=>$key,'password_hash'=>password_hash($password,PASSWORD_DEFAULT),'role'=>'user','status'=>'pending','lang'=>$this->lang,'last_seen'=>$this->game->now,'created_at'=>$this->game->now]); // USR: no crear ludus ni dinero todavía.
        session_regenerate_id(true);$_SESSION['uid']=$id;$_SESSION['csrf']=bin2hex(random_bytes(32));$this->redirect('home'); // UI: mostrar pantalla de espera.
    }
    private function password(): never
    {
        if(!$this->user){throw new \RuntimeException('Accede primero.');}$password=(string)($_POST['new_password']??'');if(strlen($password)<8||strlen($password)>128){throw new \RuntimeException('La contraseña debe tener entre 8 y 128 caracteres.');} // USR: misma política que registro.
        if(!$this->user['must_change']&&!password_verify((string)($_POST['old_password']??''),$this->user['password_hash'])){throw new \RuntimeException('La contraseña actual no coincide.');} // USR: cambio voluntario exige la contraseña vigente.
        $this->db->update('lm_users',['password_hash'=>password_hash($password,PASSWORD_DEFAULT),'must_change'=>0],(int)$this->user['id']);session_regenerate_id(true);$_SESSION['csrf']=bin2hex(random_bytes(32));$this->flash($this->tr('Contraseña actualizada.','Password updated.'));$this->redirect(); // USR: temporal no permanece reutilizable.
    }
    private function adminPost(string $action): void
    {
        if($action==='admin_approve'){$this->game->approve((int)$_POST['user']);} // ADM: cuenta y recursos en operación única.
        elseif($action==='admin_status'){$id=(int)$_POST['user'];if($id===(int)$this->user['id']){throw new \RuntimeException('No puedes suspender tu propia cuenta.');}$status=$_POST['status']==='active'?'active':'suspended';if($status==='active'){$this->game->approve($id);}else{$this->db->update('lm_users',['status'=>$status],$id);}} // ADM: reactivar también dota una cuenta que todavía no tenía ludus, sin duplicar recursos.
        elseif($action==='admin_role'){$id=(int)$_POST['user'];if($id===(int)$this->user['id']){throw new \RuntimeException('No retires tu propio acceso administrador.');}$this->db->update('lm_users',['role'=>$_POST['role']==='admin'?'admin':'user'],$id);} // ADM: conceder privilegios globales explícitamente.
        elseif($action==='admin_reset'){$pw=(string)($_POST['temporary']??'');if(strlen($pw)<8||strlen($pw)>128){throw new \RuntimeException('La temporal necesita al menos ocho caracteres.');}$this->db->update('lm_users',['password_hash'=>password_hash($pw,PASSWORD_DEFAULT),'must_change'=>1],(int)$_POST['user']);} // ADM: no consultar contraseña anterior ni cambiar aprobación.
        elseif($action==='admin_tick'){$this->game->tick();} // ADM: tareas vencidas, no premios duplicados.
        elseif($action==='admin_market'){$this->game->openMarket();} // ADM: tanda extraordinaria de diez, solo si no existe otra abierta.
        elseif($action==='admin_resolve'){$this->game->resolveEvent((int)$_POST['event'],true);} // ADM: celebrar ahora es una decisión del organizador.
        elseif($action==='admin_import'){$count=$this->game->importLegacy();$this->flash('Importadas '.$count.' cuentas como pendientes.');} // BD: importación no destructiva desde coaches.
        elseif($action==='admin_event'){$format=$_POST['format']==='royale'?'royale':'duel';$date=\DateTimeImmutable::createFromFormat('Y-m-d\TH:i',(string)$_POST['starts'],new \DateTimeZone('Europe/Madrid'));$title=trim((string)$_POST['title']);$max=(int)$_POST['maximum'];if(!$date||mb_strlen($title)<3||mb_strlen($title)>100||$max<1||$max>16){throw new \RuntimeException('Revisa título, fecha y máximo entre uno y dieciséis.');}$data=['title'=>$title,'format'=>$format,'starts_at'=>$date->getTimestamp(),'closes_at'=>$date->getTimestamp()-900,'max_per_ludus'=>$max];$id=(int)($_POST['event']??0);if($id){$event=$this->db->one('SELECT * FROM lm_events WHERE id=?',[$id]);if(!$event||$event['status']!=='scheduled'){throw new \RuntimeException('Solo se modifican eventos pendientes.');}$this->db->update('lm_events',$data,$id);}else{$this->db->insert('lm_events',$data+['seed'=>bin2hex(random_bytes(24)),'created_at'=>$this->game->now,'rules_version'=>Rules::VERSION]);}} // CAL: admin configura fechas, horas y cupos.
        elseif($action==='admin_credit'){$amount=(int)$_POST['amount'];if($amount<1||$amount>1000000){throw new \RuntimeException('Importe entre uno y un millón.');}$this->db->atomic(fn()=> $this->game->credit((int)$_POST['ludus'],$amount,'admin','Ajuste del administrador','admin:'.bin2hex(random_bytes(16))));} // ADM: ajuste trazable y sin consumir reservas.
        elseif($action==='admin_rates'){$rates=[];foreach(Rules::DEFAULTS as $key=>$default){$v=(int)($_POST[$key]??$default);if($v<0||$v>1000000){throw new \RuntimeException('Tarifa fuera de rango.');}$rates[$key]=$v;}$this->db->setMeta('economy',json_encode($rates));} // ECO: nuevas tarifas sin reescribir historial.
        elseif($action==='admin_gladiator'){$id=(int)$_POST['gladiator'];$changes=[];foreach(Rules::ATTRS as $attr){$v=(int)$_POST[$attr];if($v<1||$v>20){throw new \RuntimeException('Atributos entre uno y veinte.');}$changes[$attr]=$v;}if(isset($_POST['heal'])){$changes['injured_until']=0;}$this->db->update('lm_gladiators',$changes,$id);} // ADM: corrección manual documentada, sin revelar predisposición.
        else{throw new \RuntimeException('Control administrativo no válido.');} // ADM: lista cerrada de operaciones.
        $this->db->insert('lm_audit',['user_id'=>$this->user['id'],'action'=>$action,'detail'=>'Acción administrativa completada','created_at'=>$this->game->now]); // ADM: nunca registrar contraseña o datos secretos del formulario.
    }
    private function uploadLogo(int $ludus): void
    {
        $f=$_FILES['logo'];if($f['error']!==UPLOAD_ERR_OK||$f['size']>204800||!is_uploaded_file($f['tmp_name'])){throw new \RuntimeException('Logo de hasta 200 KiB en PNG, JPG o WebP.');} // IMG: límite previo a descomprimir.
        $info=getimagesize($f['tmp_name']);if(!$info||$info[0]>1024||$info[1]>1024||!in_array($info[2],[IMAGETYPE_PNG,IMAGETYPE_JPEG,IMAGETYPE_WEBP],true)){throw new \RuntimeException('Formato no válido o dimensiones mayores de 1024 × 1024.');} // IMG: comprobar contenido real, no extensión recibida.
        if(!function_exists('imagecreatefromstring')){throw new \RuntimeException('El servidor necesita la extensión GD para procesar logos.');} // IMG: fallo legible sin instalar dependencias ocultas.
        $src=imagecreatefromstring(file_get_contents($f['tmp_name']));if(!$src){throw new \RuntimeException('No se pudo leer la imagen.');}$dst=imagecreatetruecolor(256,256);imagealphablending($dst,false);imagesavealpha($dst,true);$side=min($info[0],$info[1]);imagecopyresampled($dst,$src,0,0,(int)(($info[0]-$side)/2),(int)(($info[1]-$side)/2),256,256,$side,$side); // IMG: recorte cuadrado centrado y salida estática.
        $dir=LUDUS_ROOT.'/var/emblems';if(!is_dir($dir)){mkdir($dir,0700,true);}$name=bin2hex(random_bytes(16)).'.png';if(!imagepng($dst,$dir.'/'.$name)){throw new \RuntimeException('No se pudo guardar el emblema.');}imagedestroy($src);imagedestroy($dst);$this->db->update('lm_ludus',['logo'=>$name],$ludus); // IMG: nombre generado, nunca ejecutar contenido subido.
    }
    private function emblem(): void
    {
        $l=$this->db->one('SELECT logo FROM lm_ludus WHERE id=?',[(int)($_GET['id']??0)]);$file=$l&&$l['logo']?LUDUS_ROOT.'/var/emblems/'.basename($l['logo']):''; // IMG: limitar lectura a emblemas generados.
        if(!$file||!is_file($file)){header('Content-Type: image/svg+xml');readfile(LUDUS_ROOT.'/assets/ludus-mark.svg');return;} // IMG: predeterminado para cualquier ludus sin logo.
        header('Content-Type: image/png');readfile($file); // IMG: solo imagen reprocesada, nunca archivo original.
    }
}
