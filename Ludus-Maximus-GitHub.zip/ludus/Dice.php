<?php
declare(strict_types=1); // DOC: mantiene enteros coherentes en las tiradas.
namespace Ludus; // DOC: evita colisiones con aleatorios de NAFLM.

final class Dice
{
    private int $counter=0; // AZR: posición reproducible de la secuencia.
    public function __construct(private string $seed) {} // AZR: semilla independiente por evento o generación.
    public function d20(): int
    {
        do { $bytes=hash_hmac('sha256',(string)$this->counter++,$this->seed,true); $n=unpack('N',substr($bytes,0,4))[1]; } while($n>=4294967280); // AZR: rechazo evita sesgo al convertir treinta y dos bits.
        return $n%20+1; // AZR: solo caras de uno a veinte.
    }
    public function index(int $size): int
    {
        if($size<1){throw new \InvalidArgumentException('Empty random pool');} // AZR: no seleccionar listas vacías.
        if($size===1){return 0;} // AZR: un único resultado no necesita tirada.
        $space=1;$digits=0;while($space<$size){$space*=20;$digits++;} // AZR: tantas caras como necesite el tamaño de lista.
        $limit=intdiv($space,$size)*$size; // AZR: zona que se puede repartir uniformemente.
        do{$ticket=0;for($i=0;$i<$digits;$i++){$ticket=$ticket*20+$this->d20()-1;}}while($ticket>=$limit); // AZR: repetir tickets sobrantes sin sesgo.
        return $ticket%$size; // AZR: índice válido de la lista.
    }
    public function range(int $min,int $max): int { return $min+$this->index($max-$min+1); } // AZR: intervalo inclusivo.
    public function pick(array $values): mixed { return $values[$this->index(count($values))]; } // AZR: elemento uniforme.
    public function unit(): float { return (2*$this->d20()-21)/19; } // AZR: variación simétrica de menos uno a uno.
    public function ticket(): int { return 1+($this->d20()-1)*400+($this->d20()-1)*20+$this->d20()-1; } // AZR: tres caras como dígitos, no suma.
    public function chance(float $probability): bool { return $this->ticket()>8000-(int)round(8000*max(0,min(1,$probability))); } // AZR: precisión 1/8000 para suerte y medicina.
    public function shuffle(array $values): array { for($i=count($values)-1;$i>0;$i--){$j=$this->index($i+1);[$values[$i],$values[$j]]=[$values[$j],$values[$i]];}return $values; } // AZR: permutación Fisher–Yates usando solo caras d20.
}
