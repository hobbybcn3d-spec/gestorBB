<?php
declare(strict_types=1); // DOC: arranque único del motor moderno.
define('LUDUS_ROOT',dirname(__DIR__)); // DOC: todas las rutas parten del proyecto, no del directorio del servidor.
define('LUDUS_CONFIG_FILE',LUDUS_ROOT.'/var/'.basename(getenv('LUDUS_CONFIG_FILE')?:'config.php')); // QA: configuración alternativa solo por entorno del servidor; nunca por URL.
date_default_timezone_set('Europe/Madrid'); // CAL: reloj de reglas en hora peninsular con cambios de estación.
foreach(['Rules','Dice','Engine','Database','Game','Installer','View','App'] as $class){require_once __DIR__.'/'.$class.'.php';} // DOC: carga explícita, sin Composer ni arranque legado.
if(PHP_SAPI!=='cli'){ // USR: sesiones solo para peticiones web.
    ini_set('session.use_strict_mode','1'); // USR: no aceptar identificadores de sesión arbitrarios.
    session_name('ludus_maximus'); // USR: no reutilizar cookies inseguras de NAFLM.
    session_set_cookie_params(['httponly'=>true,'secure'=>!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off','samesite'=>'Lax','path'=>'/']); // USR: proteger la cookie sin romper vista local HTTP.
    session_start(); // USR: iniciar después de configurar la cookie.
    if(empty($_SESSION['csrf'])){$_SESSION['csrf']=bin2hex(random_bytes(32));} // USR: token independiente del dado del juego.
    header('X-Content-Type-Options: nosniff'); // USR: contenido interpretado con su MIME real.
    header('Referrer-Policy: same-origin'); // USR: no enviar rutas privadas a sitios externos.
    header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'"); // USR: scripts propios y formularios locales.
    header('Cache-Control: no-store'); // ESP: no conservar informes privados en caché tras caducar.
}
