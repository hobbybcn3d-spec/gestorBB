<?php
declare(strict_types=1); // DOC: obliga a respetar tipos en las reglas del juego.
namespace Ludus; // DOC: separa Ludus Maximus del código legado de NAFLM.

final class Rules
{
    public const VERSION = '1.0.0'; // DOC: versión de aplicación y reglas de instalación.
    public const ATTRS = ['strength','agility','constitution','stamina','consistency','luck']; // ATR: un único conjunto, sin habilidades duplicadas.
    public const TRAINABLE = ['strength','agility','constitution','stamina','consistency']; // ENT: suerte no se entrena.
    public const LABELS = ['strength'=>'Fuerza','agility'=>'Agilidad','constitution'=>'Constitución','stamina'=>'Resistencia','consistency'=>'Consistencia','luck'=>'Suerte']; // ATR: nombres legibles de las seis características.
    public const MODES = ['normal','aggressive','defensive','counter','evasive']; // TAC: modos elegidos antes del evento.
    public const MODE_LABELS = ['normal'=>'Normal','aggressive'=>'Agresivo','defensive'=>'Defensivo','counter'=>'Contraataque','evasive'=>'Evasivo']; // TAC: etiquetas españolas.
    public const MODIFIERS = ['normal'=>[1.0,0.0,1.0],'aggressive'=>[1.15,0.05,1.2],'defensive'=>[0.85,-0.05,0.9],'counter'=>[0.9,0.0,1.0],'evasive'=>[0.8,-0.08,1.1]]; // CMB: daño, exposición y gasto por táctica.
    public const DEFAULTS = ['initial_balance'=>6000,'sponsor'=>200,'participation'=>60,'prize_1'=>300,'prize_2'=>180,'prize_3'=>100,'gladiator_upkeep'=>20,'building_upkeep'=>40,'reveal_cost'=>100]; // ECO: cifras de partida aceptadas como diseño operativo.
    public const WAGES = ['trainer'=>[1=>100,160,240,350,500],'assistant'=>[1=>50,80,120,170,230],'medic'=>[1=>60,100,150,210,280]]; // ECO: salarios semanales por nivel.
    public const HIRE = ['trainer'=>[1=>500,1500,3500,8000,15000],'assistant'=>[1=>300,700,1500,3000,5000],'medic'=>[1=>400,900,1800,3500,6000]]; // ECO: coste de contratación, inicial gratuito aparte.
    public const TRAINERS = [1=>1.0,1.1,1.2,1.3,1.35]; // ENT: efecto de la calidad del entrenador.
    public const RACES = [
        'human'=>['es'=>'Humanos','en'=>'Humans','weight'=>7,'market'=>35,'height'=>[160,205],'mass'=>[55,120],'max'=>[6,6,6,6,6],'price'=>1200,'icon'=>'human.png','portraits'=>['hlineman1.gif','hcatcher1.gif','hthrower1.gif','hblitzer1.gif','amlineman1.gif','amblitzer1.gif','impline1.gif','impbody1.gif','bretsquire.gif','bretknight.gif','nlineman1.gif','noberserker1.gif','valkyrie.gif','vthrall1.gif']],
        'orc'=>['es'=>'Orcos','en'=>'Orcs','weight'=>4,'market'=>20,'height'=>[175,225],'mass'=>[85,180],'max'=>[8,4,8,5,5],'price'=>1500,'icon'=>'orc.png','portraits'=>['olineman1.gif','othrower1.gif','oblitzer1.gif','oblackorc1.gif']],
        'elf'=>['es'=>'Elfos','en'=>'Elves','weight'=>3,'market'=>15,'height'=>[165,210],'mass'=>[45,90],'max'=>[4,9,4,7,6],'price'=>1500,'icon'=>'elf.png','portraits'=>['eplineman1.gif','epthrower1.gif','epcatcher1.gif','epblitzer1.gif','delineman1.gif','derunner1.gif','deassassin1.gif','deblitzer1.gif','dewitchelf1.gif','helineman1.gif','hethrower1.gif','hecatcher1.gif','heblitzer1.gif','welineman1.gif','wethrower1.gif','wecatcher2.gif','weblitzer2.gif','delfrenegade1.gif']],
        'dwarf'=>['es'=>'Enanos','en'=>'Dwarves','weight'=>3,'market'=>15,'height'=>[120,155],'mass'=>[60,115],'max'=>[6,4,9,7,5],'price'=>1400,'icon'=>'dwarf.png','portraits'=>['dlongbeard1.gif','drunner1.gif','dblitzer1.gif','dslayer1.gif','cddwarf1.gif','cddwarf2.gif']],
        'goblin'=>['es'=>'Goblins','en'=>'Goblins','weight'=>2,'market'=>10,'height'=>[95,140],'mass'=>[20,50],'max'=>[4,10,4,8,5],'price'=>800,'icon'=>'goblin.png','portraits'=>['goblin1.gif','looney1.gif','bombardier1.gif','ooligan.gif','doomdiver.gif','fanatic1.gif','goscrappa1.gif','gobrenegade1.gif','uwgoblin1.gif']],
        'big'=>['es'=>'Grandotes','en'=>'Big Guys','weight'=>0,'market'=>5,'height'=>[230,310],'mass'=>[180,350],'max'=>[11,4,10,4,4],'price'=>4500,'icon'=>'ogres.png','portraits'=>['bloodspawn.gif','chaostroll1.gif','ddeathroller1an.gif','kroxigor1.gif','minotaur1.gif','ogre1.gif','pact_ogre1.gif','ratogre1.gif','rtbeast1.gif','slannkrox1.gif','snotling_pumpwagon1.gif','snowtroll1.gif','tomb_guardian1.gif','treeman1.gif','troll1.gif','troll2.gif','umummy1.gif','vargheist.gif','warptroll1.gif']],
    ]; // RZA: perfiles propios y sprites NAFLM; Grandotes usa todos los is_bigguy inventariados.

    public static function capacity(int $level): int { return 8 + 4 * ($level - 1); } // LUD: alojamiento inicial ocho y cuatro plazas por mejora.
    public static function age(array $g, int $now): float { return (float)$g['age_start'] + max(0,$now-(int)$g['born_at'])/8640000; } // GLD: cien días reales equivalen a un año.
    public static function week(int $now): string { return (new \DateTimeImmutable('@'.$now))->setTimezone(new \DateTimeZone('Europe/Madrid'))->modify('monday this week')->format('Y-m-d'); } // CAL: identifica la semana local del juego.
    public static function nextWeek(int $now): int { return (new \DateTimeImmutable('@'.$now))->setTimezone(new \DateTimeZone('Europe/Madrid'))->modify('next monday')->setTime(0,0)->getTimestamp(); } // CAL: caducidad semanal con horario de verano.
    public static function weeksFor(int $level): int { return $level<=5 ? 2 : ($level<=10 ? 4 : ($level<=15 ? 8 : 12)); } // ENT: curva de progreso acordada.
    public static function names(string $race, string $sex): array
    {
        $starts = ['human'=>['Aul','Cass','Dec','Fab','Jul','Luc','Marc','Oct','Sev','Val'],'orc'=>['Gr','Gor','Krag','Mog','Rag','Thr','Ugr','Var','Zag','Zor'],'elf'=>['Ael','Aer','Cal','Eli','Fae','Gal','Ith','Lia','Syl','Tha'],'dwarf'=>['Bald','Brom','Dain','Dur','Gar','Grim','Kaz','Or','Thor','Ulf'],'goblin'=>['Bik','Giz','Grek','Kik','Mik','Nib','Skab','Snig','Tik','Zik'],'big'=>['Borg','Brak','Drog','Grom','Grum','Horg','Krog','Morg','Rog','Throg']]; // GLD: raíces lingüísticas de nombres por raza.
        $ends = $sex==='f' ? ['a','ara','ela','ena','ia','ila','ina','ora','una','yra'] : ['an','ar','as','en','er','ik','in','on','or','us']; // GLD: diez terminaciones por sexo producen cien nombres.
        $first=[]; foreach($starts[$race] as $a){ foreach($ends as $b){ $first[]=$a.$b; } } // GLD: catálogo reproducible de cien nombres por raza y sexo.
        $prefix=['Ash','Bronze','Dark','Deep','Doom','Ember','Flint','Gold','Granite','Grey','Iron','Moon','Night','Oak','Red','Shadow','Stone','Storm','Sun','Wolf']; // GLD: veinte raíces de apellidos.
        $suffix=['blade','born','brand','fall','fist','guard','heart','mantle','scar','shield']; // GLD: diez finales generan doscientos apellidos.
        $last=[]; foreach($prefix as $a){ foreach($suffix as $b){$last[]=$a.$b;} } // GLD: catálogo determinista; los sorteos posteriores usan d20.
        return [$first,$last]; // GLD: nombres no dependen del navegador ni de servicios externos.
    }
}
