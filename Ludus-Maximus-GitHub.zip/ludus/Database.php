<?php
declare(strict_types=1); // DOC: conexión portable con errores controlados.
namespace Ludus; // DOC: las tablas lm_ no alteran coaches ni equipos de NAFLM.

final class Database
{
    public \PDO $pdo; // BD: conexión compartida de la petición.
    public string $driver; // BD: distingue SQLite de MySQL en la migración.
    public function __construct(array $config)
    {
        $this->driver=$config['driver']??'sqlite'; // BD: SQLite permite instalar sin servidor adicional.
        if($this->driver==='mysql'){$dsn='mysql:host='.$config['host'].';port='.($config['port']??3306).';dbname='.$config['database'].';charset=utf8mb4';$user=$config['user'];$pass=$config['password'];}else{$dsn='sqlite:'.LUDUS_ROOT.'/var/'.basename($config['database']??'ludus.sqlite');$user=null;$pass=null;} // BD: credenciales solo desde configuración privada.
        $this->pdo=new \PDO($dsn,$user,$pass,[\PDO::ATTR_ERRMODE=>\PDO::ERRMODE_EXCEPTION,\PDO::ATTR_DEFAULT_FETCH_MODE=>\PDO::FETCH_ASSOC,\PDO::ATTR_EMULATE_PREPARES=>false]); // BD: consultas preparadas y excepciones uniformes.
        if($this->driver==='sqlite'){$this->pdo->exec('PRAGMA foreign_keys=ON');$this->pdo->exec('PRAGMA busy_timeout=10000');$this->pdo->exec('PRAGMA journal_mode=WAL');} // BD: integridad y espera ante escrituras concurrentes.
    }
    public function run(string $sql,array $args=[]): \PDOStatement {$q=$this->pdo->prepare($sql);$q->execute($args);return $q;} // BD: todos los datos pasan por parámetros.
    public function all(string $sql,array $args=[]): array {return $this->run($sql,$args)->fetchAll();} // BD: devuelve filas de una consulta.
    public function one(string $sql,array $args=[]): ?array {$r=$this->run($sql,$args)->fetch();return $r===false?null:$r;} // BD: diferencia ausencia de fila de una fila vacía.
    public function value(string $sql,array $args=[]): mixed {return $this->run($sql,$args)->fetchColumn();} // BD: lectura escalar.
    public function insert(string $table,array $data): int
    {
        if(!preg_match('/^lm_[a-z_]+$/',$table)){throw new \LogicException('Invalid internal table');} // BD: nombres de tabla únicamente internos.
        $keys=array_keys($data);$sql='INSERT INTO '.$table.' ('.implode(',',$keys).') VALUES ('.implode(',',array_fill(0,count($keys),'?')).')'; // BD: construir inserción con nombres controlados.
        $this->run($sql,array_values($data));return (int)$this->pdo->lastInsertId(); // BD: recuperar identificador insertado.
    }
    public function update(string $table,array $data,int $id): void {$fields=array_map(fn($k)=>$k.'=?',array_keys($data));$this->run('UPDATE '.$table.' SET '.implode(',',$fields).' WHERE id=?',[...array_values($data),$id]);} // BD: actualización interna por clave primaria.
    public function atomic(callable $fn): mixed
    {
        if($this->pdo->inTransaction()){return $fn();} // BD: operaciones anidadas pertenecen a la transacción exterior.
        $this->pdo->beginTransaction(); // BD: todo cambio importante empieza protegido.
        try{$this->run("UPDATE lm_meta SET value=value WHERE mkey='write_lock'");$result=$fn();$this->pdo->commit();return $result;}catch(\Throwable $e){if($this->pdo->inTransaction()){$this->pdo->rollBack();}throw $e;} // BD: serializar pujas/premios y deshacer fallos parciales.
    }
    public function meta(string $key,?string $default=null): ?string {$v=$this->value('SELECT value FROM lm_meta WHERE mkey=?',[$key]);return $v===false?$default:(string)$v;} // BD: parámetro versionado de aplicación.
    public function setMeta(string $key,string $value): void {if($this->one('SELECT mkey FROM lm_meta WHERE mkey=?',[$key])){$this->run('UPDATE lm_meta SET value=? WHERE mkey=?',[$value,$key]);}else{$this->run('INSERT INTO lm_meta(mkey,value) VALUES(?,?)',[$key,$value]);}} // BD: guardar sin sintaxis exclusiva de un motor.

    public function migrate(): void
    {
        $pk=$this->driver==='mysql'?'INTEGER PRIMARY KEY AUTO_INCREMENT':'INTEGER PRIMARY KEY AUTOINCREMENT'; // BD: única diferencia de autoincremento.
        $tail=$this->driver==='mysql'?' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci':''; // BD: MySQL siempre transaccional.
        $tables=[ // BD: esquema aditivo; nunca DROP TABLE de datos heredados.
            'meta'=>"mkey VARCHAR(100) PRIMARY KEY,value TEXT NOT NULL",
            'users'=>"id $pk,username VARCHAR(60) NOT NULL,username_key VARCHAR(100) NOT NULL UNIQUE,password_hash VARCHAR(255) NOT NULL,legacy_id INTEGER UNIQUE,role VARCHAR(16) NOT NULL DEFAULT 'user',status VARCHAR(16) NOT NULL DEFAULT 'pending',must_change INTEGER NOT NULL DEFAULT 0,lang VARCHAR(5) NOT NULL DEFAULT 'es',last_seen INTEGER NOT NULL,created_at INTEGER NOT NULL",
            'ludus'=>"id $pk,user_id INTEGER NOT NULL UNIQUE,name VARCHAR(100) NOT NULL,logo VARCHAR(200),balance INTEGER NOT NULL DEFAULT 0,maintenance_debt INTEGER NOT NULL DEFAULT 0,loan_debt INTEGER NOT NULL DEFAULT 0,created_at INTEGER NOT NULL,FOREIGN KEY(user_id) REFERENCES lm_users(id)",
            'buildings'=>"id $pk,ludus_id INTEGER NOT NULL,type VARCHAR(20) NOT NULL,level INTEGER NOT NULL,created_at INTEGER NOT NULL,UNIQUE(ludus_id,type),FOREIGN KEY(ludus_id) REFERENCES lm_ludus(id)",
            'jobs'=>"id $pk,ludus_id INTEGER NOT NULL,type VARCHAR(20) NOT NULL,target_level INTEGER NOT NULL,starts_at INTEGER NOT NULL,ends_at INTEGER NOT NULL,paid INTEGER NOT NULL,status VARCHAR(16) NOT NULL DEFAULT 'active',FOREIGN KEY(ludus_id) REFERENCES lm_ludus(id)",
            'staff'=>"id $pk,ludus_id INTEGER NOT NULL,type VARCHAR(20) NOT NULL,level INTEGER NOT NULL,hired_at INTEGER NOT NULL,fired_at INTEGER,salary INTEGER NOT NULL,FOREIGN KEY(ludus_id) REFERENCES lm_ludus(id)",
            'gladiators'=>"id $pk,ludus_id INTEGER,former_ludus_id INTEGER,origin VARCHAR(20) NOT NULL,state VARCHAR(16) NOT NULL,race VARCHAR(16) NOT NULL,sex VARCHAR(1) NOT NULL,name VARCHAR(100) NOT NULL,portrait VARCHAR(80) NOT NULL,height INTEGER NOT NULL,weight INTEGER NOT NULL,age_start INTEGER NOT NULL,born_at INTEGER NOT NULL,owner_since INTEGER NOT NULL DEFAULT 0,retired_at INTEGER NOT NULL DEFAULT 0,strength INTEGER NOT NULL,agility INTEGER NOT NULL,constitution INTEGER NOT NULL,stamina INTEGER NOT NULL,consistency INTEGER NOT NULL,luck INTEGER NOT NULL,training VARCHAR(20) NOT NULL DEFAULT 'strength',progress TEXT NOT NULL,injured_until INTEGER NOT NULL DEFAULT 0,injured_at INTEGER NOT NULL DEFAULT 0,injury VARCHAR(20),latent INTEGER NOT NULL DEFAULT 0,first_grave INTEGER NOT NULL DEFAULT 0,FOREIGN KEY(ludus_id) REFERENCES lm_ludus(id),FOREIGN KEY(former_ludus_id) REFERENCES lm_ludus(id),CHECK(strength BETWEEN 1 AND 20),CHECK(agility BETWEEN 1 AND 20),CHECK(constitution BETWEEN 1 AND 20),CHECK(stamina BETWEEN 1 AND 20),CHECK(consistency BETWEEN 1 AND 20),CHECK(luck BETWEEN 1 AND 20)",
            'events'=>"id $pk,title VARCHAR(120) NOT NULL,format VARCHAR(16) NOT NULL,starts_at INTEGER NOT NULL,closes_at INTEGER NOT NULL,max_per_ludus INTEGER NOT NULL DEFAULT 3,status VARCHAR(16) NOT NULL DEFAULT 'scheduled',seed VARCHAR(100) NOT NULL,created_at INTEGER NOT NULL,resolved_at INTEGER,rules_version VARCHAR(30) NOT NULL",
            'registrations'=>"id $pk,event_id INTEGER NOT NULL,ludus_id INTEGER NOT NULL,source VARCHAR(16) NOT NULL,UNIQUE(event_id,ludus_id),FOREIGN KEY(event_id) REFERENCES lm_events(id),FOREIGN KEY(ludus_id) REFERENCES lm_ludus(id)",
            'entries'=>"id $pk,event_id INTEGER NOT NULL,gladiator_id INTEGER,ludus_id INTEGER,name_snapshot VARCHAR(100) NOT NULL,source VARCHAR(16) NOT NULL,mode VARCHAR(20) NOT NULL,position INTEGER,medical VARCHAR(20),prize INTEGER NOT NULL DEFAULT 0,played INTEGER NOT NULL DEFAULT 0,UNIQUE(event_id,gladiator_id),FOREIGN KEY(event_id) REFERENCES lm_events(id),FOREIGN KEY(gladiator_id) REFERENCES lm_gladiators(id) ON DELETE SET NULL,FOREIGN KEY(ludus_id) REFERENCES lm_ludus(id)",
            'duels'=>"id $pk,event_id INTEGER NOT NULL,round_no INTEGER NOT NULL,stage VARCHAR(20) NOT NULL,participants TEXT NOT NULL,winner_entry INTEGER,summary TEXT NOT NULL,FOREIGN KEY(event_id) REFERENCES lm_events(id)",
            'auctions'=>"id $pk,gladiator_id INTEGER UNIQUE,starts_at INTEGER NOT NULL,ends_at INTEGER NOT NULL,original_end INTEGER NOT NULL,opening INTEGER NOT NULL,leader_id INTEGER,amount INTEGER NOT NULL DEFAULT 0,status VARCHAR(16) NOT NULL DEFAULT 'open',FOREIGN KEY(gladiator_id) REFERENCES lm_gladiators(id) ON DELETE SET NULL,FOREIGN KEY(leader_id) REFERENCES lm_ludus(id)",
            'bids'=>"id $pk,auction_id INTEGER NOT NULL,ludus_id INTEGER NOT NULL,amount INTEGER NOT NULL,created_at INTEGER NOT NULL,FOREIGN KEY(auction_id) REFERENCES lm_auctions(id),FOREIGN KEY(ludus_id) REFERENCES lm_ludus(id)",
            'reveals'=>"id $pk,auction_id INTEGER NOT NULL,user_id INTEGER NOT NULL,gladiator_id INTEGER NOT NULL,attribute VARCHAR(20) NOT NULL,value INTEGER NOT NULL,created_at INTEGER NOT NULL,UNIQUE(user_id,gladiator_id),FOREIGN KEY(auction_id) REFERENCES lm_auctions(id),FOREIGN KEY(user_id) REFERENCES lm_users(id),FOREIGN KEY(gladiator_id) REFERENCES lm_gladiators(id) ON DELETE CASCADE",
            'spy_usage'=>"id $pk,user_id INTEGER NOT NULL,week_key VARCHAR(12) NOT NULL,created_at INTEGER NOT NULL,UNIQUE(user_id,week_key),FOREIGN KEY(user_id) REFERENCES lm_users(id)",
            'spy_reports'=>"id $pk,usage_id INTEGER NOT NULL UNIQUE,user_id INTEGER NOT NULL,target_id INTEGER,attribute VARCHAR(20) NOT NULL,value INTEGER NOT NULL,target_name VARCHAR(100) NOT NULL,expires_at INTEGER NOT NULL,FOREIGN KEY(usage_id) REFERENCES lm_spy_usage(id),FOREIGN KEY(user_id) REFERENCES lm_users(id),FOREIGN KEY(target_id) REFERENCES lm_gladiators(id) ON DELETE CASCADE",
            'ledger'=>"id $pk,ludus_id INTEGER NOT NULL,amount INTEGER NOT NULL,type VARCHAR(30) NOT NULL,label VARCHAR(200) NOT NULL,ref_key VARCHAR(180) NOT NULL UNIQUE,created_at INTEGER NOT NULL,FOREIGN KEY(ludus_id) REFERENCES lm_ludus(id)",
            'batches'=>"batch_key VARCHAR(150) PRIMARY KEY,created_at INTEGER NOT NULL",
            'attempts'=>"attempt_key VARCHAR(100) PRIMARY KEY,failures INTEGER NOT NULL,last_at INTEGER NOT NULL",
            'audit'=>"id $pk,user_id INTEGER,action VARCHAR(60) NOT NULL,detail VARCHAR(250) NOT NULL,created_at INTEGER NOT NULL",
        ];
        foreach($tables as $name=>$definition){$this->pdo->exec('CREATE TABLE IF NOT EXISTS lm_'.$name.' ('.$definition.')'.$tail);} // BD: instalación repetible sin borrar tablas.
        if($this->meta('write_lock')===null){$this->setMeta('write_lock','1');} // BD: fila que serializa cambios críticos.
        $this->setMeta('schema_version','1'); // BD: punto de partida para futuras migraciones incrementales.
    }
}
