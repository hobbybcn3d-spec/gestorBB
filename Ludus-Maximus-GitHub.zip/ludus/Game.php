<?php
declare(strict_types=1); // DOC: servicios de juego independientes de las pantallas.
namespace Ludus; // DOC: reutilización segura de recursos, sin arrancar NAFLM legado.

final class Game
{
    public function __construct(public Database $db,public int $now) {} // CAL: reloj inyectable para pruebas sin cambiar el servidor.
    public function economy(): array {return array_replace(Rules::DEFAULTS,json_decode($this->db->meta('economy','{}'),true)?:[]);} // ECO: tarifas editables por el administrador.
    public function ludus(int $user): ?array {return $this->db->one('SELECT * FROM lm_ludus WHERE user_id=?',[$user]);} // LUD: un ludus por dueño.
    public function level(int $ludus,string $type): int {return (int)($this->db->value('SELECT level FROM lm_buildings WHERE ludus_id=? AND type=?',[$ludus,$type])?:0);} // LUD: cero significa edificio aún no construido.
    public function reserved(int $ludus): int {return (int)$this->db->value("SELECT COALESCE(SUM(amount),0) FROM lm_auctions WHERE leader_id=? AND status='open'",[$ludus]);} // MER: dinero inmovilizado por pujas líderes.
    public function available(int $ludus): int {return (int)$this->db->value('SELECT balance FROM lm_ludus WHERE id=?',[$ludus])-$this->reserved($ludus);} // ECO: disponible nunca incluye una reserva.
    public function freeSlots(int $ludus): int {return Rules::capacity(max(1,$this->level($ludus,'housing')))-(int)$this->db->value("SELECT COUNT(*) FROM lm_gladiators WHERE ludus_id=? AND state='active'",[$ludus])-(int)$this->db->value("SELECT COUNT(*) FROM lm_auctions WHERE leader_id=? AND status='open'",[$ludus]);} // LUD: las subastas también reservan plaza.
    public function roster(int $ludus): array {return $this->db->all("SELECT * FROM lm_gladiators WHERE ludus_id=? AND state='active' ORDER BY id",[$ludus]);} // GLD: plantilla actual, sin reserva ni fallecidos.

    public function generate(?int $owner,bool $initial=false,string $origin='arena',?Dice $dice=null): int
    {
        $dice??=new Dice(bin2hex(random_bytes(24)));$roll=$dice->d20();while($initial&&$roll===20){$roll=$dice->d20();} // AZR: sin Grandotes en los tres iniciales.
        $race=$roll<=7?'human':($roll<=11?'orc':($roll<=14?'elf':($roll<=17?'dwarf':($roll<=19?'goblin':'big')))); // RZA: probabilidades exactas heredadas de la planificación.
        $rule=Rules::RACES[$race];$sex=$dice->d20()<=18?'m':'f';[$first,$last]=Rules::names($race,$sex); // GLD: nombre y sexo a través del servicio d20.
        $height=$dice->range(...$rule['height']);$fraction=($height-$rule['height'][0])/max(1,$rule['height'][1]-$rule['height'][0]); // GLD: correlación física con variación individual.
        $massFraction=max(0,min(1,0.65*$fraction+0.35*($dice->range(0,1000)/1000)));$mass=(int)round($rule['mass'][0]+$massFraction*($rule['mass'][1]-$rule['mass'][0])); // GLD: pesos coherentes dentro de su rango.
        $data=['ludus_id'=>$owner,'origin'=>$origin,'state'=>$owner?'active':($origin==='market'?'market':'reserve'),'race'=>$race,'sex'=>$sex,'name'=>$dice->pick($first).' '.$dice->pick($last),'portrait'=>$dice->pick($rule['portraits']),'height'=>$height,'weight'=>$mass,'age_start'=>$dice->range(18,25),'born_at'=>$this->now,'owner_since'=>$owner?$this->now:0,'progress'=>'{}']; // GLD: solo valores reales acordados, sin clones de plantilla.
        foreach(Rules::TRAINABLE as $index=>$attribute){$max=$rule['max'][$index];$data[$attribute]=$dice->range((int)ceil($max/2-1),$max);} // ATR: máximo racial y mitad menos uno, redondeado hacia arriba.
        $data['luck']=$dice->d20();return $this->db->insert('lm_gladiators',$data); // ATR: suerte excepcional entre uno y veinte.
    }

    public function createLudus(int $user): int
    {
        if($old=$this->ludus($user)){return (int)$old['id'];} // ADM: aprobación repetida no genera recursos adicionales.
        $u=$this->db->one('SELECT username FROM lm_users WHERE id=?',[$user]);if(!$u){throw new \RuntimeException('Usuario inexistente.');} // USR: no crear ludus huérfanos.
        $id=$this->db->insert('lm_ludus',['user_id'=>$user,'name'=>'Ludus de '.$u['username'],'balance'=>0,'created_at'=>$this->now]); // LUD: nombre editable y emblema predeterminado.
        foreach(['housing','training'] as $type){$this->db->insert('lm_buildings',['ludus_id'=>$id,'type'=>$type,'level'=>1,'created_at'=>$this->now]);} // LUD: solamente los dos edificios iniciales.
        $this->db->insert('lm_staff',['ludus_id'=>$id,'type'=>'trainer','level'=>1,'hired_at'=>$this->now,'salary'=>100]); // ENT: entrenador inicial nivel uno.
        $this->credit($id,$this->economy()['initial_balance'],'initial','Dotación inicial','initial:'.$user); // ECO: dotación contable trazable.
        for($i=0;$i<3;$i++){$this->generate($id,true,'initial');} // GLD: tres personajes nuevos, sin Grandotes.
        return $id; // LUD: clave del ludus creado.
    }

    public function credit(int $ludus,int $amount,string $type,string $label,string $ref): void
    {
        if($amount<0){throw new \LogicException('Negative credit');} // ECO: pagos negativos no se disfrazan de ingresos.
        if($this->db->one('SELECT id FROM lm_ledger WHERE ref_key=?',[$ref])){return;} // ECO: un premio solo se ingresa una vez.
        $w=$this->db->one('SELECT * FROM lm_ludus WHERE id=?',[$ludus]);if(!$w){throw new \RuntimeException('Ludus inexistente.');} // ECO: destinatario válido.
        $debt=min($amount,(int)$w['maintenance_debt']);$loan=min((int)$w['loan_debt'],(int)floor(($amount-$debt)*0.2)); // ECO: mantenimiento primero y anticipo después.
        $this->db->run('UPDATE lm_ludus SET balance=balance+?,maintenance_debt=maintenance_debt-?,loan_debt=loan_debt-? WHERE id=?',[$amount-$debt-$loan,$debt,$loan,$ludus]); // ECO: no consumir dinero previamente reservado.
        $this->db->insert('lm_ledger',['ludus_id'=>$ludus,'amount'=>$amount,'type'=>$type,'label'=>$label,'ref_key'=>$ref,'created_at'=>$this->now]); // ECO: historial del ingreso bruto.
        foreach(['debt'=>$debt,'loan'=>$loan] as $kind=>$paid){if($paid){$this->db->insert('lm_ledger',['ludus_id'=>$ludus,'amount'=>-$paid,'type'=>$kind,'label'=>'Devolución '.$kind,'ref_key'=>$ref.':'.$kind,'created_at'=>$this->now]);}} // ECO: descuentos visibles, sin borrar el ingreso.
    }
    public function debit(int $ludus,int $amount,string $type,string $label,string $ref): void
    {
        if($this->db->one('SELECT id FROM lm_ledger WHERE ref_key=?',[$ref])){return;} // ECO: no cobrar dos veces una operación.
        if($amount<0||$this->available($ludus)<$amount){throw new \RuntimeException('No hay denarios disponibles suficientes.');} // ECO: respeta fondos de pujas.
        $this->db->run('UPDATE lm_ludus SET balance=balance-? WHERE id=?',[$amount,$ludus]); // ECO: descontar el importe confirmado.
        $this->db->insert('lm_ledger',['ludus_id'=>$ludus,'amount'=>-$amount,'type'=>$type,'label'=>$label,'ref_key'=>$ref,'created_at'=>$this->now]); // ECO: operación registrada para reintentos.
    }
    private function canInvest(int $ludus): void {if((int)$this->db->value('SELECT maintenance_debt FROM lm_ludus WHERE id=?',[$ludus])>0){throw new \RuntimeException('Liquida el mantenimiento pendiente antes de invertir.');}} // ECO: evita crecer dejando impagos.

    public function approve(int $user): void {$this->db->atomic(function()use($user){$u=$this->db->one('SELECT * FROM lm_users WHERE id=?',[$user]);if(!$u){throw new \RuntimeException('Usuario inexistente.');}$this->createLudus($user);$this->db->update('lm_users',['status'=>'active'],$user);});} // ADM: estado y recursos se entregan juntos.
    public function bid(int $ludus,int $auction,int $amount): void
    {
        $this->db->atomic(function()use($ludus,$auction,$amount){ // MER: una sola transacción protege dinero, plaza y cierre.
            $this->canInvest($ludus);$a=$this->db->one('SELECT * FROM lm_auctions WHERE id=?',[$auction]); // MER: leer la oferta vigente bajo bloqueo.
            if(!$a||$a['status']!=='open'||(int)$a['ends_at']<=$this->now){throw new \RuntimeException('La subasta ya está cerrada.');} // MER: la hora del servidor decide.
            $minimum=$a['amount']?(int)ceil((int)$a['amount']*1.05):(int)$a['opening']; // MER: primera oferta o incremento mínimo cinco por ciento.
            if($amount<$minimum||$amount>100000000){throw new \RuntimeException('La puja no alcanza el mínimo requerido.');} // MER: limitar enteros y comprobar la oferta actual.
            $own=(int)$a['leader_id']===$ludus;$available=$this->available($ludus)+($own?(int)$a['amount']:0); // MER: al elevar oferta propia se libera solo su reserva previa.
            if($amount>$available){throw new \RuntimeException('No hay denarios disponibles suficientes.');} // MER: evita gastar la misma cartera varias veces.
            if(!$own&&$this->freeSlots($ludus)<1){throw new \RuntimeException('Amplía el alojamiento para reservar otra plaza.');} // LUD: las subastas activas cuentan contra capacidad.
            $end=(int)$a['ends_at'];if($end-$this->now<=900){$end+=900;} // MER: oferta válida tardía añade quince minutos.
            $this->db->update('lm_auctions',['leader_id'=>$ludus,'amount'=>$amount,'ends_at'=>$end],$auction); // MER: cambiar líder libera automáticamente al anterior.
            $this->db->insert('lm_bids',['auction_id'=>$auction,'ludus_id'=>$ludus,'amount'=>$amount,'created_at'=>$this->now]); // MER: conservar máximo pujador e historial público.
        });
    }
    public function reveal(int $user,int $ludus,int $auction): void
    {
        $this->db->atomic(function()use($user,$ludus,$auction){$a=$this->db->one("SELECT * FROM lm_auctions WHERE id=? AND status='open' AND ends_at>?",[$auction,$this->now]);if(!$a||!$a['gladiator_id']){throw new \RuntimeException('La subasta ya está cerrada.');}$g=$this->db->one('SELECT * FROM lm_gladiators WHERE id=?',[$a['gladiator_id']]);if($this->db->one('SELECT id FROM lm_reveals WHERE user_id=? AND gladiator_id=?',[$user,$g['id']])){throw new \RuntimeException('Ya has descubierto un atributo de este gladiador.');}$attr=(new Dice(bin2hex(random_bytes(24))))->pick(['strength','agility','stamina','consistency','luck']);$this->debit($ludus,$this->economy()['reveal_cost'],'reveal','Descubrimiento de mercado','reveal:'.$user.':'.$g['id']);$this->db->insert('lm_reveals',['auction_id'=>$auction,'user_id'=>$user,'gladiator_id'=>$g['id'],'attribute'=>$attr,'value'=>$g[$attr],'created_at'=>$this->now]);}); // MER: único descubrimiento pagado sin revelar constitución ya pública.
    }
    public function spy(int $user,int $ludus,int $target): void
    {
        $this->db->atomic(function()use($user,$ludus,$target){$week=Rules::week($this->now);if($this->db->one('SELECT id FROM lm_spy_usage WHERE user_id=? AND week_key=?',[$user,$week])){throw new \RuntimeException('Ya has usado el espionaje de esta semana.');}$g=$this->db->one("SELECT * FROM lm_gladiators WHERE id=? AND state='active' AND ludus_id IS NOT NULL AND ludus_id<>?",[$target,$ludus]);if(!$g){throw new \RuntimeException('Elige un gladiador de otro ludus.');}$attr=(new Dice(bin2hex(random_bytes(24))))->pick(Rules::ATTRS);$id=$this->db->insert('lm_spy_usage',['user_id'=>$user,'week_key'=>$week,'created_at'=>$this->now]);$this->db->insert('lm_spy_reports',['usage_id'=>$id,'user_id'=>$user,'target_id'=>$target,'attribute'=>$attr,'value'=>$g[$attr],'target_name'=>$g['name'],'expires_at'=>Rules::nextWeek($this->now)]);}); // ESP: acción secreta, gratuita y única; sin notificación al rival.
    }
    public function train(int $ludus,int $gladiator,string $attribute): void {if(!in_array($attribute,Rules::TRAINABLE,true)){throw new \RuntimeException('Atributo de entrenamiento no válido.');}$this->db->run("UPDATE lm_gladiators SET training=? WHERE id=? AND ludus_id=? AND state='active'",[$attribute,$gladiator,$ludus]);} // ENT: solo la selección final del lunes se aplica.
    public function retire(int $ludus,int $id): void {$this->db->atomic(function()use($ludus,$id){$g=$this->db->one("SELECT * FROM lm_gladiators WHERE id=? AND ludus_id=? AND state='active'",[$id,$ludus]);if(!$g){throw new \RuntimeException('Gladiador no disponible.');}$this->db->update('lm_gladiators',['ludus_id'=>null,'former_ludus_id'=>$ludus,'state'=>'reserve','retired_at'=>$this->now],$id);$this->db->run('DELETE FROM lm_entries WHERE gladiator_id=? AND position IS NULL',[$id]);$this->purge();});} // RET: irreversible, libera plaza y permite uso posterior por Arena.
    public function build(int $ludus,string $type): void
    {
        $this->db->atomic(function()use($ludus,$type){$this->canInvest($ludus);if(!in_array($type,['housing','training','medical'],true)){throw new \RuntimeException('Instalación no válida.');}if($this->db->one("SELECT id FROM lm_jobs WHERE ludus_id=? AND status='active'",[$ludus])){throw new \RuntimeException('Ya hay una obra en curso.');}$level=$this->level($ludus,$type);$cap=['housing'=>10,'training'=>6,'medical'=>5][$type];if($level>=$cap){throw new \RuntimeException('Instalación en su nivel máximo.');}$next=$level+1;$price=$type==='medical'&&$next===1?1500:(int)(ceil((($type==='housing'?1200:1800)*pow(1.8,$next-2))/10)*10);$ref='build:'.$ludus.':'.$type.':'.$next;$this->debit($ludus,$price,'building','Obra '.$type.' nivel '.$next,$ref);$this->db->insert('lm_jobs',['ludus_id'=>$ludus,'type'=>$type,'target_level'=>$next,'starts_at'=>$this->now,'ends_at'=>$this->now+604800,'paid'=>$price]);}); // LUD: obra única, pagada al inicio y siete días sin cancelación.
    }
    public function hire(int $ludus,string $type,int $level): void
    {
        $this->db->atomic(function()use($ludus,$type,$level){$this->canInvest($ludus);if(!isset(Rules::WAGES[$type][$level])){throw new \RuntimeException('Contrato no válido.');}$staff=$this->db->all('SELECT * FROM lm_staff WHERE ludus_id=? AND type=? AND fired_at IS NULL',[$ludus,$type]);$limit=$type==='assistant'?($this->level($ludus,'training')>=2?2:1):1;if(count($staff)>=$limit){throw new \RuntimeException('Despide primero al trabajador que quieres sustituir.');}if($type==='medic'&&$level>$this->level($ludus,'medical')){throw new \RuntimeException('Construye o mejora las instalaciones médicas antes de contratar.');}$this->debit($ludus,Rules::HIRE[$type][$level],'hire','Contratación '.$type.' '.$level,'hire:'.bin2hex(random_bytes(12)));$this->db->insert('lm_staff',['ludus_id'=>$ludus,'type'=>$type,'level'=>$level,'hired_at'=>$this->now,'salary'=>Rules::WAGES[$type][$level]]);}); // ENT: salario por nivel y límites de edificios.
    }
    public function fire(int $ludus,int $id): void {$this->db->run('UPDATE lm_staff SET fired_at=? WHERE id=? AND ludus_id=? AND fired_at IS NULL',[$this->now,$id,$ludus]);} // ECO: conserva historial para liquidar parte devengada.

    public function registerEvent(int $ludus,int $event,array $choices): void
    {
        $this->db->atomic(function()use($ludus,$event,$choices){$e=$this->db->one("SELECT * FROM lm_events WHERE id=? AND status='scheduled'",[$event]);if(!$e||(int)$e['closes_at']<=$this->now){throw new \RuntimeException('Las inscripciones están cerradas.');}if(count($choices)<1||count($choices)>(int)$e['max_per_ludus']){throw new \RuntimeException('Selecciona entre uno y el máximo permitido.');}$selected=[];foreach($choices as $id=>$mode){$g=$this->db->one("SELECT * FROM lm_gladiators WHERE id=? AND ludus_id=? AND state='active' AND injured_until<=?",[(int)$id,$ludus,$this->now]);if(!$g||!in_array($mode,Rules::MODES,true)){throw new \RuntimeException('Un participante no está disponible.');}$selected[]=['g'=>$g,'mode'=>$mode];}$this->db->run('DELETE FROM lm_entries WHERE event_id=? AND ludus_id=?',[$event,$ludus]);$reg=$this->db->one('SELECT id FROM lm_registrations WHERE event_id=? AND ludus_id=?',[$event,$ludus]);if($reg){$this->db->update('lm_registrations',['source'=>'manual'],(int)$reg['id']);}else{$this->db->insert('lm_registrations',['event_id'=>$event,'ludus_id'=>$ludus,'source'=>'manual']);}foreach($selected as $item){$this->addEntry($event,$item['g'],$item['mode']);}}); // CAL: una selección manual menor no se completa automáticamente.
    }
    private function addEntry(int $event,array $g,string $mode='normal'): int {return $this->db->insert('lm_entries',['event_id'=>$event,'gladiator_id'=>$g['id'],'ludus_id'=>$g['ludus_id'],'name_snapshot'=>$g['name'],'source'=>$g['ludus_id']?'user':'arena','mode'=>$mode]);} // CAL: referencia histórica independiente del gladiador vivo.

    public function resolveEvent(int $id,bool $force=false): void
    {
        $this->db->atomic(function()use($id,$force){ // CMB: resultado, medicina y premios se confirman juntos.
            $event=$this->db->one('SELECT * FROM lm_events WHERE id=?',[$id]);if(!$event||$event['status']!=='scheduled'){return;} // CMB: resolver una vez.
            if(!$force&&(int)$event['starts_at']>$this->now){return;} // CAL: usuarios no adelantan el reloj.
            if($force&&(int)$event['starts_at']>$this->now){$event['starts_at']=$this->now;$event['closes_at']=$this->now;$this->db->update('lm_events',['starts_at'=>$this->now,'closes_at'=>$this->now],$id);} // ADM: celebrar ahora deja la nueva fecha registrada.
            $at=(int)$event['starts_at'];$dice=new Dice($event['seed']); // AZR: repetir una transacción no altera el resultado.
            $valid=$this->db->all("SELECT e.id FROM lm_entries e LEFT JOIN lm_gladiators g ON g.id=e.gladiator_id WHERE e.event_id=? AND (g.id IS NULL OR g.state<>'active' OR g.injured_until>?)",[$id,$at]);foreach($valid as $bad){$this->db->run('DELETE FROM lm_entries WHERE id=?',[$bad['id']]);} // MED: retirar lesionados antes de competir.
            $ludi=$this->db->all("SELECT l.* FROM lm_ludus l JOIN lm_users u ON u.id=l.user_id WHERE u.status='active' AND u.last_seen>=?",[$at-1296000]); // CAL: ventana de quince días.
            foreach($ludi as $l){if($this->db->one('SELECT id FROM lm_registrations WHERE event_id=? AND ludus_id=?',[$id,$l['id']])){continue;}$pool=$this->db->all("SELECT * FROM lm_gladiators WHERE ludus_id=? AND state='active' AND injured_until<=?",[$l['id'],$at]);$pool=$dice->shuffle($pool);$this->db->insert('lm_registrations',['event_id'=>$id,'ludus_id'=>$l['id'],'source'=>'auto']);foreach(array_slice($pool,0,(int)$event['max_per_ludus']) as $g){$this->addEntry($id,$g);}} // CAL: completar solo ausencia de selección manual.
            $count=(int)$this->db->value('SELECT COUNT(*) FROM lm_entries WHERE event_id=?',[$id]); // CMB: mínimo global, no cuatro por ludus.
            foreach($this->db->all('SELECT DISTINCT ludus_id FROM lm_entries WHERE event_id=? AND ludus_id IS NOT NULL',[$id]) as $l){$chosen=$this->db->all('SELECT id FROM lm_entries WHERE event_id=? AND ludus_id=? ORDER BY id',[$id,$l['ludus_id']]);foreach(array_slice($chosen,(int)$event['max_per_ludus']) as $excess){$this->db->run('DELETE FROM lm_entries WHERE id=?',[$excess['id']]);$count--;}} // CAL: si admin redujo el máximo, conservar los primeros seleccionados hasta el nuevo límite.
            $reserve=$dice->shuffle($this->db->all("SELECT * FROM lm_gladiators WHERE state='reserve' AND injured_until<=?",[$at])); // RET: disponibles sin reponer fallecidos.
            foreach($reserve as $g){if($count>=4){break;}if(Rules::age($g,$at)>=40){continue;}$this->addEntry($id,$g);$count++;} // RET: elegir sin duplicados y respetar edad.
            while($count<4){$gid=$this->generate(null,false,'arena',$dice);$this->addEntry($id,$this->db->one('SELECT * FROM lm_gladiators WHERE id=?',[$gid]));$count++;} // GLD: nuevos neutrales persistidos cuando falta reserva.
            $entries=$this->db->all('SELECT * FROM lm_entries WHERE event_id=? ORDER BY id',[$id]);$fighters=[];$entryByG=[]; // CMB: preparar referencias de esta competición.
            foreach($entries as $entry){$g=$this->db->one('SELECT * FROM lm_gladiators WHERE id=?',[$entry['gladiator_id']]);$g['mode']=$entry['mode'];$fighters[$g['id']]=$g;$entryByG[$g['id']]=$entry;} // CMB: no guardar fotografía completa de atributos en resultados.
            if($event['format']==='royale'){$fight=Engine::fight(array_values($fighters),$dice,true);$ranking=$fight['ranking'];$this->saveFight($id,1,'royale',$fight,$entryByG,array_keys($fighters));}else{$ranking=$this->tournament($id,$fighters,$entryByG,$dice);} // CMB: motor compartido para ambos formatos.
            $eco=$this->economy();foreach($ranking as $offset=>$gid){ // CMB: evaluación médica única y premios del puesto final.
                $entry=$entryByG[$gid];$g=$fighters[$gid];$medical=Engine::medical($g,$dice);$position=$offset+1;$isHuman=$entry['source']==='user';$played=(int)$this->db->value('SELECT played FROM lm_entries WHERE id=?',[$entry['id']]); // MED: nadie es inmune por ser sustituto.
                $prize=$isHuman&&$played>0?$eco['participation']+($position<=3?$eco['prize_'.$position]:0):0; // ECO: Arena no reasigna premios.
                $this->db->update('lm_entries',['position'=>$position,'medical'=>$medical['kind'],'prize'=>$prize],(int)$entry['id']); // CMB: clasificación estable antes de borrar fichas futuras.
                $change=['latent'=>$medical['latent'],'first_grave'=>$medical['first_grave']]; // MED: guardar antecedentes solo en tabla interna.
                if($medical['kind']==='death'){$change+=['state'=>'dead','ludus_id'=>null,'former_ludus_id'=>$g['ludus_id']?:$g['former_ludus_id'],'retired_at'=>$at,'injured_until'=>0];}elseif($medical['days']){$change+=['injury'=>$medical['kind'],'injured_at'=>$at,'injured_until'=>$at+$medical['days']*86400];} // MED: baja real, no daño de combate persistente.
                $this->db->update('lm_gladiators',$change,(int)$gid); // GLD: no modificar atributos de retirados.
                if($prize){$this->credit((int)$entry['ludus_id'],$prize,'event','Evento #'.$id.' · puesto '.$position,'event:'.$id.':entry:'.$entry['id']);} // ECO: clave única evita duplicar ingresos.
            }
            $this->db->update('lm_events',['status'=>'finished','resolved_at'=>$this->now],$id); // CAL: la página ya puede mostrar podio y crónica.
        });
    }

    private function saveFight(int $event,int $round,string $stage,array $fight,array $entryMap,array $ids): void
    {
        $this->db->insert('lm_duels',['event_id'=>$event,'round_no'=>$round,'stage'=>$stage,'participants'=>json_encode(array_map(fn($id)=>(int)$entryMap[$id]['id'],$ids)),'winner_entry'=>$fight['winner']?$entryMap[$fight['winner']]['id']:null,'summary'=>json_encode(['logs'=>$fight['logs'],'limit'=>$fight['limit'],'rounds'=>$fight['rounds']],JSON_UNESCAPED_UNICODE)]); // CMB: crónica sin atributos secretos ni copia de ficha.
        foreach($ids as $gid){$this->db->run('UPDATE lm_entries SET played=played+1 WHERE id=?',[$entryMap[$gid]['id']]);} // ENT: pases libres no cuentan como duelo disputado.
    }
    private function tournament(int $event,array $fighters,array $entryMap,Dice $dice): array
    {
        $ids=$dice->shuffle(array_keys($fighters));$size=1;while($size<count($ids)){$size*=2;}$byes=$size-count($ids);$pairs=[];$eliminated=[];$semis=[];$round=1; // CMB: siguiente potencia de dos, sin parejas de dos pases libres.
        for($i=0;$i<$byes;$i++){$pairs[]=[array_shift($ids),null];}while($ids){$pairs[]=[array_shift($ids),array_shift($ids)];}$pairs=$dice->shuffle($pairs); // AZR: sorteo sin cabezas de serie.
        while(true){$next=[];$losers=[];foreach($pairs as [$a,$b]){if($b===null){$next[]=$a;continue;}$fight=Engine::fight([$fighters[$a],$fighters[$b]],$dice);$winner=$fight['winner'];$loser=$winner===$a?$b:$a;$next[]=$winner;$losers[]=$loser;$eliminated[]=$loser;$this->saveFight($event,$round,'round',$fight,$entryMap,[$a,$b]);}if(count($pairs)===2){$semis=$losers;}if(count($next)===1){$champion=$next[0];$runner=$losers[0];break;}$pairs=[];while($next){$pairs[]=[array_shift($next),array_shift($next)];}$round++;} // CMB: cada duelo reinicia salud, energía y rendimiento.
        $top=[$champion,$runner];if(count($semis)===2){$bronze=Engine::fight([$fighters[$semis[0]],$fighters[$semis[1]]],$dice);$third=$bronze['winner'];$fourth=$third===$semis[0]?$semis[1]:$semis[0];$top[]=$third;$top[]=$fourth;$this->saveFight($event,$round,'bronze',$bronze,$entryMap,$semis);} // CMB: los semifinalistas se recuperan para el tercer puesto.
        foreach(array_reverse($eliminated) as $gid){if(!in_array($gid,$top,true)){$top[]=$gid;}}return $top; // CMB: ningún participante aparece dos veces.
    }

    public function openMarket(?int $start=null,?int $end=null,string $key='manual'): void
    {
        $this->db->atomic(function()use($start,$end,$key){if($this->db->one("SELECT id FROM lm_auctions WHERE status='open'")){throw new \RuntimeException('Ya existe una tanda de mercado abierta.');}$start??=$this->now;$end??=$start+259200;$dice=new Dice(bin2hex(random_bytes(24)));for($i=0;$i<10;$i++){$id=$this->generate(null,false,'market',$dice);$g=$this->db->one('SELECT race FROM lm_gladiators WHERE id=?',[$id]);$this->db->insert('lm_auctions',['gladiator_id'=>$id,'starts_at'=>$start,'ends_at'=>$end,'original_end'=>$end,'opening'=>Rules::RACES[$g['race']]['price']]);}$this->db->setMeta('market_key',$key);}); // MER: exactamente diez ofertas nuevas.
    }
    private function closeAuctions(): void
    {
        foreach($this->db->all("SELECT * FROM lm_auctions WHERE status='open' AND ends_at<=?",[$this->now]) as $a){ // MER: cierre definitivo incluye todas las ampliaciones.
            if($a['leader_id']){$this->db->update('lm_auctions',['status'=>'sold'],(int)$a['id']);$this->debit((int)$a['leader_id'],(int)$a['amount'],'auction','Adjudicación #'.$a['id'],'auction:'.$a['id']);$this->db->update('lm_gladiators',['ludus_id'=>$a['leader_id'],'state'=>'active','owner_since'=>$this->now],(int)$a['gladiator_id']);}else{$this->db->update('lm_auctions',['status'=>'unsold'],(int)$a['id']);if($a['gladiator_id']){$this->deleteGladiator((int)$a['gladiator_id']);}} // MER: liberar reserva antes de convertirla en compra; sin pujas se borra.
            $this->db->run('DELETE FROM lm_reveals WHERE auction_id=?',[$a['id']]); // ESP: no dejar atributos pagados accesibles tras cerrar.
        }
    }
    private function deleteGladiator(int $id): void {$this->db->run('DELETE FROM lm_entries WHERE gladiator_id=? AND position IS NULL',[$id]);$this->db->run('DELETE FROM lm_gladiators WHERE id=?',[$id]);} // RET: FK conserva nombres históricos y elimina informes operativos.
    public function purge(): void {foreach($this->db->all("SELECT * FROM lm_gladiators WHERE state IN ('reserve','dead') AND ludus_id IS NULL") as $g){if(Rules::age($g,$this->now)>=40){$this->deleteGladiator((int)$g['id']);}}$this->db->run('DELETE FROM lm_spy_reports WHERE expires_at<=?',[$this->now]);} // RET: borrado real a cuarenta y espionaje caducado.

    public function tick(): void
    {
        $this->db->atomic(function(){ // CAL: avance automático de las tareas pendientes.
            foreach($this->db->all("SELECT * FROM lm_jobs WHERE status='active' AND ends_at<=?",[$this->now]) as $job){$b=$this->db->one('SELECT id FROM lm_buildings WHERE ludus_id=? AND type=?',[$job['ludus_id'],$job['type']]);if($b){$this->db->update('lm_buildings',['level'=>$job['target_level']],(int)$b['id']);}else{$this->db->insert('lm_buildings',['ludus_id'=>$job['ludus_id'],'type'=>$job['type'],'level'=>$job['target_level'],'created_at'=>$job['ends_at']]);}$this->db->update('lm_jobs',['status'=>'finished'],(int)$job['id']);} // LUD: completar obra sin cancelarla ni cobrar otra vez.
            $this->closeAuctions(); // MER: cerrar antes de ofrecer nueva tanda.
            foreach($this->db->all("SELECT id FROM lm_events WHERE status='scheduled' AND starts_at<=? ORDER BY starts_at LIMIT 40",[$this->now]) as $e){$this->resolveEvent((int)$e['id']);} // CMB: recuperar eventos vencidos con límite de trabajo por petición.
            $current=(new \DateTimeImmutable('@'.$this->now))->setTimezone(new \DateTimeZone('Europe/Madrid'))->modify('monday this week')->setTime(0,0); // CAL: comienzo de la semana actual.
            $last=(int)$this->db->meta('last_week_at',(string)$current->getTimestamp()); // CAL: no inventar semanas anteriores a la instalación.
            for($i=0;$i<12&&$last<$current->getTimestamp();$i++){$next=(new \DateTimeImmutable('@'.$last))->setTimezone(new \DateTimeZone('Europe/Madrid'))->modify('+1 week')->getTimestamp();$this->weekly($last,$next);$last=$next;} // ENT: cerrar semanas una sola vez.
            $this->db->setMeta('last_week_at',(string)$last); // CAL: marcador durable de recuperación.
            $this->ensureCalendar($current); // CAL: crear próximos encuentros sin duplicarlos.
            $monday=$current->setTime(18,0);$end=$monday->modify('+3 days');$marketKey='market:'.$current->format('Y-m-d'); // MER: horario real lunes a jueves.
            if($this->now>=$monday->getTimestamp()&&$this->now<$end->getTimestamp()&&!$this->db->one('SELECT batch_key FROM lm_batches WHERE batch_key=?',[$marketKey])&&!$this->db->one("SELECT id FROM lm_auctions WHERE status='open'")){$this->openMarket($monday->getTimestamp(),$end->getTimestamp(),$marketKey);$this->db->run('INSERT INTO lm_batches(batch_key,created_at) VALUES(?,?)',[$marketKey,$this->now]);} // MER: una tanda de diez por semana.
            $this->purge();$this->db->setMeta('last_tick',(string)$this->now); // CAL: conservar reloj y eliminar datos vencidos.
        });
    }
    private function ensureCalendar(\DateTimeImmutable $monday): void
    {
        for($week=0;$week<3;$week++){foreach([1=>'royale',3=>'duel',5=>'royale',6=>'duel'] as $day=>$format){$date=$monday->modify('+'.($week*7+$day).' days')->setTime(20,0);if($date->getTimestamp()<=$this->now){continue;}$key='calendar:'.$date->format('Y-m-d').':'.$format;if($this->db->one('SELECT batch_key FROM lm_batches WHERE batch_key=?',[$key])){continue;}$this->db->insert('lm_events',['title'=>$format==='royale'?'La arena de Marte':'Duelos del Coliseo','format'=>$format,'starts_at'=>$date->getTimestamp(),'closes_at'=>$date->getTimestamp()-900,'max_per_ludus'=>3,'seed'=>bin2hex(random_bytes(24)),'created_at'=>$this->now,'rules_version'=>Rules::VERSION]);$this->db->run('INSERT INTO lm_batches(batch_key,created_at) VALUES(?,?)',[$key,$this->now]);}} // CAL: plantilla por defecto modificable por admin.
    }
    private function weekly(int $start,int $end): void
    {
        $key='weekly:'.$end;if($this->db->one('SELECT batch_key FROM lm_batches WHERE batch_key=?',[$key])){return;} // CAL: idempotencia del entrenamiento y mantenimiento.
        $eco=$this->economy();foreach($this->db->all('SELECT l.*,u.last_seen,u.status FROM lm_ludus l JOIN lm_users u ON u.id=l.user_id') as $l){ // ECO: liquidación individual del ludus.
            $lid=(int)$l['id'];$roster=$this->roster($lid);$staff=$this->db->all('SELECT * FROM lm_staff WHERE ludus_id=? AND hired_at<? AND (fired_at IS NULL OR fired_at>?)',[$lid,$end,$start]);$trainer=0;$assistants=0;$medic=0;$cost=0; // ENT: trabajadores efectivos de esta semana.
            foreach($staff as $s){$until=$s['fired_at']?min($end,(int)$s['fired_at']):$end;$portion=max(0,$until-max($start,(int)$s['hired_at']))/max(1,$end-$start);$cost+=(int)round($s['salary']*$portion);if(!$s['fired_at']||(int)$s['fired_at']>=$end){if($s['type']==='trainer'){$trainer=max($trainer,(int)$s['level']);}elseif($s['type']==='assistant'){$assistants+=(int)$s['level'];}else{$medic=max($medic,(int)$s['level']);}}} // ECO: prorrateo que no desaparece al despedir.
            foreach($this->db->all('SELECT * FROM lm_buildings WHERE ludus_id=?',[$lid]) as $b){$cost+=(int)round($eco['building_upkeep']*$b['level']*max(0,$end-max($start,(int)$b['created_at']))/max(1,$end-$start));} // ECO: edificios construidos, no proyectos inexistentes.
            foreach($roster as $g){$cost+=(int)round($eco['gladiator_upkeep']*max(0,$end-max($start,(int)$g['owner_since']))/max(1,$end-$start));$count=(int)$this->db->value("SELECT COUNT(DISTINCT e.event_id) FROM lm_entries e JOIN lm_events v ON v.id=e.event_id WHERE e.gladiator_id=? AND e.source='user' AND e.played>0 AND v.status='finished' AND v.starts_at>=? AND v.starts_at<?",[$g['id'],$start,$end]);$attr=$g['training'];$progress=json_decode($g['progress'],true)?:[];$value=(int)$g[$attr]; // ENT: solo eventos reales y elección final de atributo.
                if($count&&$trainer&&$value<20){$h=max(-1,min(1,($g['height']-180)/100));$p=max(-1,min(1,($g['weight']-80)/150));$physical=$attr==='strength'?1+0.15*($h+$p)/2:($attr==='stamina'?1-0.15*($h+$p)/2:1);$advance=($count>=2?1:0.5)*Rules::TRAINERS[$trainer]*(1+0.035*$assistants)*(1+min(0.10,0.02*max(0,$this->level($lid,'training')-1)))*$physical/Rules::weeksFor($value);$progress[$attr]=($progress[$attr]??0)+$advance;while($progress[$attr]>=1&&$value<20){$progress[$attr]-=1;$value++;}$this->db->update('lm_gladiators',[$attr=>$value,'progress'=>json_encode($progress)],(int)$g['id']);} // ENT: fracciones conservadas, máximo veinte.
                $g[$attr]=$value; // ENT: el declive usa el valor después de entrenar; no sobrescribe por error una subida de esta semana.
                if(Rules::age($g,$end)>=35){$dice=new Dice('decline:'.$key.':'.$g['id']);$changes=[];foreach(['strength','agility','constitution','stamina'] as $a){if($dice->chance(min(0.12,0.02+0.01*(Rules::age($g,$end)-35)))){$changes[$a]=max(1,(int)($changes[$a]??$g[$a])-1);}}if($changes){$this->db->update('lm_gladiators',$changes,(int)$g['id']);}} // GLD: decisión delegada de declive gradual; reserva no entra aquí.
                if($medic&&(int)$g['injured_until']>$end){$covered=max(0,$end-max($start,(int)$g['injured_at']));$until=max($end,(int)$g['injured_until']-(int)round($covered*0.2*$medic));$this->db->update('lm_gladiators',['injured_until'=>$until],(int)$g['id']);} // MED: bonus semanal solo sobre tiempo realmente transcurrido.
            }
            if($l['status']==='active'&&(int)$l['last_seen']>=$end-1296000){$this->credit($lid,$eco['sponsor'],'sponsor','Patrocinio semanal',$key.':sponsor:'.$lid);} // ECO: ayuda de actividad independiente de premios.
            $pay=min($cost,max(0,$this->available($lid)));if($pay){$this->debit($lid,$pay,'maintenance','Mantenimiento semanal',$key.':maintenance:'.$lid);}if($cost>$pay){$this->db->run('UPDATE lm_ludus SET maintenance_debt=maintenance_debt+? WHERE id=?',[$cost-$pay,$lid]);} // ECO: no consumir reservas ni matar gladiadores por deuda.
        }
        $this->db->run('INSERT INTO lm_batches(batch_key,created_at) VALUES(?,?)',[$key,$this->now]); // CAL: cierre durable de esta semana.
    }

    public function importLegacy(): int
    {
        if($this->db->driver!=='mysql'){throw new \RuntimeException('La importación requiere la misma conexión MySQL que NAFLM.');} // BD: no inventar usuarios cuando no existe coaches.
        $rows=$this->db->all('SELECT coach_id,name,passwd,ring,retired FROM coaches');$count=0; // USR: no ejecutar clases ni instalador antiguos.
        $this->db->atomic(function()use($rows,&$count){foreach($rows as $r){if($this->db->one('SELECT id FROM lm_users WHERE legacy_id=?',[$r['coach_id']])){continue;}$name=$r['name'];$key=mb_strtolower($name,'UTF-8');if($this->db->one('SELECT id FROM lm_users WHERE username_key=?',[$key])){$name.='_naf'.$r['coach_id'];$key=mb_strtolower($name,'UTF-8');}$id=$this->db->insert('lm_users',['username'=>$name,'username_key'=>$key,'password_hash'=>$r['passwd'],'legacy_id'=>$r['coach_id'],'role'=>(int)$r['ring']===5?'admin':'user','status'=>$r['retired']?'suspended':'pending','last_seen'=>$this->now,'created_at'=>$this->now]);$count++;}});return $count; // USR: preservar hashes para verificar y actualizar al primer acceso.
    }
}
