<?php
declare(strict_types=1); // DOC: instalador sin dependencias de mysql_*.
namespace Ludus; // DOC: conserva instaladores antiguos como referencia, no los ejecuta.

final class Installer
{
    public static function legacyConfig(): array
    {
        $source=is_file(LUDUS_ROOT.'/settings.php')?file_get_contents(LUDUS_ROOT.'/settings.php'):'';$out=[]; // BD: leer configuración sin ejecutar PHP heredado.
        foreach(['db_host','db_name','db_user','db_passwd'] as $key){if(preg_match('/\\$'.preg_quote($key,'/').'\\s*=\\s*([\'\"])(.*?)\\1\\s*;/s',$source,$m)){$out[$key]=$m[1]==="'"?str_replace(["\\'","\\\\"],["'","\\"],$m[2]):stripcslashes($m[2]);}} // BD: solo asignaciones literales, nunca eval ni salida de secretos.
        return $out; // BD: el formulario usa estas claves únicamente al elegir reutilizar NAFLM.
    }
    public static function install(array $config,string $username,string $password): Database
    {
        if(($config['driver']??'sqlite')==='mysql'&&preg_match('/^([^:]+):(\d+)$/',(string)($config['host']??''),$hostParts)){$config['host']=$hostParts[1];$config['port']=(int)$hostParts[2];} // BD: NAFLM admite host:puerto; PDO recibe ambos por separado.
        if(is_file(LUDUS_ROOT.'/var/config.php')){throw new \RuntimeException('La instalación ya está completada.');} // ADM: impedir reinstalaciones sobre una cuenta existente.
        if(!preg_match('/^[\p{L}\p{N}_-]{3,24}$/u',$username)||strlen($password)<8||strlen($password)>128){throw new \RuntimeException('Usuario de 3–24 caracteres y contraseña de 8–128.');} // USR: mismos límites que el registro.
        if(!is_dir(LUDUS_ROOT.'/var')&&!mkdir(LUDUS_ROOT.'/var',0700,true)){throw new \RuntimeException('No se puede crear var.');} // BD: datos privados separados del código.
        if(!is_writable(LUDUS_ROOT.'/var')){throw new \RuntimeException('La carpeta var debe permitir escritura al servidor PHP.');} // BD: comprobar antes de cambiar datos.
        $lock=fopen(LUDUS_ROOT.'/var/install.lock','x');if(!$lock){throw new \RuntimeException('Otra instalación está en curso.');} // BD: evita dos instalaciones simultáneas.
        try{
            $db=new Database($config);$db->migrate(); // BD: crear solo tablas propias y conservar las antiguas.
            if((int)$db->value('SELECT COUNT(*) FROM lm_users')>0){throw new \RuntimeException('Esta base ya contiene cuentas de Ludus. Restaura su configuración; no se sobrescriben usuarios.');} // ADM: no apropiarse de una instalación existente.
            $game=new Game($db,time());$now=time(); // CAL: referencias reales del servidor.
            $db->atomic(function()use($db,$game,$username,$password,$now){$id=$db->insert('lm_users',['username'=>$username,'username_key'=>mb_strtolower($username,'UTF-8'),'password_hash'=>password_hash($password,PASSWORD_DEFAULT),'role'=>'admin','status'=>'active','last_seen'=>$now,'created_at'=>$now]);$game->createLudus($id);$db->setMeta('installed','1');$db->setMeta('installed_at',(string)$now);$db->setMeta('economy',json_encode(Rules::DEFAULTS));}); // ADM: cuenta con todos los permisos y dotación una sola vez.
            $game->tick(); // CAL: calendario y mercado inicial sin esperar una tarea externa.
            $config['secret']=bin2hex(random_bytes(32)); // USR: secreto de autenticación independiente del d20.
            $php="<?php\n// BD: configuración privada creada por el instalador; no publicar.\nreturn ".var_export($config,true).";\n"; // BD: no incorporar credenciales a archivos de código versionados.
            if(file_put_contents(LUDUS_ROOT.'/var/config.php.tmp',$php,LOCK_EX)===false||!rename(LUDUS_ROOT.'/var/config.php.tmp',LUDUS_ROOT.'/var/config.php')){throw new \RuntimeException('No se pudo guardar la configuración privada.');} // BD: escritura completa antes de activar instalación.
            @chmod(LUDUS_ROOT.'/var/config.php',0600); // BD: restringir lectura en servidores compatibles.
            file_put_contents(LUDUS_ROOT.'/var/admin-access.json',json_encode(['username'=>$username,'password'=>$password],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)); // ADM: entrega local solicitada por el dueño, protegida de HTTP.
            @chmod(LUDUS_ROOT.'/var/admin-access.json',0600); // ADM: archivo de acceso privado.
            return $db; // BD: la aplicación puede arrancar inmediatamente.
        }finally{fclose($lock);unlink(LUDUS_ROOT.'/var/install.lock');} // BD: liberar únicamente nuestro archivo de bloqueo.
    }
}
