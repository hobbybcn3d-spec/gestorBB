<?php
declare(strict_types=1); // DOC: simulación independiente de interfaz y base de datos.
namespace Ludus; // DOC: motor propio guiado por las reglas documentadas.

final class Engine
{
    private static function clamp(float $v,float $min,float $max): float {return max($min,min($max,$v));} // CMB: acota un modificador.
    private static function fatigue(float $energy): float {return 0.75+0.25*self::clamp($energy/25,0,1);} // CMB: cansancio gradual, máximo veinticinco por ciento.
    private static function agility(array $s): float {return $s['g']['agility']*$s['performance']*self::fatigue($s['energy']);} // CMB: agilidad temporal, no reescribe atributo.
    private static function cost(array $s): float {return (6-0.2*$s['g']['stamina'])*(1+0.1*$s['mass'])*Rules::MODIFIERS[$s['mode']][2];} // CMB: energía por esfuerzo, acierte o falle.

    public static function fight(array $gladiators,Dice $dice,bool $royale=false): array
    {
        $states=[];$logs=[];$fallen=[];$cap=$royale?75:50; // CMB: límites finitos por formato.
        foreach($gladiators as $g){ // CMB: preparar únicamente gladiadores del encuentro.
            $mass=self::clamp(((int)$g['weight']-80)/150,-1,1); // CMB: masa relativa acotada.
            $hp=(60+4*$g['constitution'])*(1+0.1*$mass); // CMB: aguante por constitución y peso.
            $amplitude=0.10-0.09*($g['consistency']-1)/19; // CMB: consistencia reduce extremos.
            $candidate=$g['mode']??'normal';$mode=in_array($candidate,Rules::MODES,true)?$candidate:'normal'; // TAC: Normal también cuando un servicio no envía el campo de modo.
            $states[(int)$g['id']]=['g'=>$g,'hp'=>$hp,'initial'=>$hp,'energy'=>100.0,'mass'=>$mass,'performance'=>1+$amplitude*$dice->unit(),'mode'=>$mode,'counter'=>false,'rest'=>false]; // CMB: estado temporal de esta pelea.
        }
        for($round=1;$round<=$cap;$round++){ // CMB: recorrer asaltos con tope conocido.
            $live=array_keys(array_filter($states,fn($s)=>$s['hp']>0)); // CMB: solo conscientes.
            if(count($live)<2){break;} // CMB: terminar al quedar un único gladiador.
            $order=[];$highlights=[]; // CMB: orden y resumen de este asalto.
            foreach($live as $id){$states[$id]['counter']=false;$states[$id]['rest']=false;$ag=self::agility($states[$id]);$order[]=['id'=>$id,'score'=>2*$ag+$dice->d20(),'ag'=>$ag,'co'=>$states[$id]['g']['consistency'],'tie'=>$dice->range(1,8000)];} // CMB: doble agilidad y dado veinte por asalto.
            usort($order,fn($a,$b)=>($b['score']<=>$a['score'])?:($b['ag']<=>$a['ag'])?:($b['co']<=>$a['co'])?:($b['tie']<=>$a['tie'])?:($a['id']<=>$b['id'])); // CMB: orden estable con desempate reproducible.
            foreach($order as $turn){ // CMB: una acción ordinaria en su posición.
                $id=$turn['id'];if($states[$id]['hp']<=0){continue;} // CMB: caer antes del turno lo pierde.
                $targets=array_keys(array_filter($states,fn($s)=>$s['hp']>0&&(int)$s['g']['id']!==$id)); // CMB: blancos válidos excluyen al propio actor.
                if(!$targets){break;} // CMB: conservar el resumen del último asalto antes de terminar.
                $cost=self::cost($states[$id]); // CMB: calcula gasto antes de decidir recuperación.
                if($states[$id]['energy']+0.000001<$cost){$states[$id]['energy']=min(100,$states[$id]['energy']+10+$states[$id]['g']['stamina']/2);$states[$id]['rest']=true;$highlights[]=['type'=>'rest','actor'=>$states[$id]['g']['name']];continue;} // CMB: recuperar ocupa acción y bloquea respuestas restantes.
                $owner=(int)($states[$id]['g']['ludus_id']??0);$friends=[];$enemies=[]; // CMB: Arena no forma alianza por dueño vacío.
                foreach($targets as $target){if($owner>0&&$owner===(int)($states[$target]['g']['ludus_id']??0)){$friends[]=$target;}else{$enemies[]=$target;}} // CMB: separar propio ludus de rivales.
                $pool=($friends&&$enemies)?($dice->d20()<=16?$enemies:$friends):($enemies?:$friends); // AZR: ochenta por ciento rivales, veinte propios si hay ambos.
                $target=$dice->pick($pool); // AZR: blanco uniforme dentro del grupo.
                self::strike($states,$id,$target,$dice,$highlights,$fallen,false); // CMB: acierto, daño y respuesta atómicos de este golpe.
            }
            if($highlights){$logs[]=['round'=>$round,'events'=>array_slice($highlights,0,24),'omitted'=>max(0,count($highlights)-24)];} // CMB: crónica compacta, no atributos secretos.
        }
        $survivors=array_keys(array_filter($states,fn($s)=>$s['hp']>0)); // CMB: supervivientes antes del desempate por límite.
        $tieOrder=$dice->shuffle($survivors);$tieRank=array_flip($tieOrder); // AZR: sorteo solo como último criterio.
        usort($survivors,function($a,$b)use($states,$tieRank){$x=$states[$a];$y=$states[$b];return ($y['hp']/$y['initial']<=>$x['hp']/$x['initial'])?:($y['energy']<=>$x['energy'])?:($tieRank[$a]<=>$tieRank[$b]);}); // CMB: salud proporcional y energía al límite.
        $ranking=array_merge($survivors,array_reverse($fallen)); // CMB: última caída queda por delante de primeras.
        return ['ranking'=>$ranking,'winner'=>$ranking[0]??null,'logs'=>$logs,'limit'=>count($survivors)>1,'rounds'=>min($cap,$round),'states'=>array_map(fn($s)=>['hp'=>round($s['hp'],2),'energy'=>round($s['energy'],2)],$states)]; // CMB: solo resumen temporal del resultado.
    }

    private static function strike(array &$s,int $a,int $d,Dice $dice,array &$log,array &$fallen,bool $reaction): void
    {
        if($s[$a]['hp']<=0||$s[$d]['hp']<=0){return;} // CMB: no golpear a un eliminado ni actuar inconsciente.
        $cost=self::cost($s[$a]);if($s[$a]['energy']+0.000001<$cost){return;} // CMB: respuestas sin energía se omiten.
        $agiA=self::agility($s[$a]);$agiD=self::agility($s[$d]);$force=$s[$a]['g']['strength']*$s[$a]['performance']*self::fatigue($s[$a]['energy']); // CMB: capturar estado previo al cobro.
        $s[$a]['energy']=max(0,$s[$a]['energy']-$cost); // CMB: pagar tanto si acierta como si falla.
        $p=0.60+self::clamp(0.20*($agiA-$agiD)/19,-0.20,0.20)+self::clamp(0.0005*($s[$a]['g']['height']-$s[$d]['g']['height']),-0.05,0.05)+0.03*$s[$d]['mass']+Rules::MODIFIERS[$s[$d]['mode']][1]+0.05*($s[$a]['g']['luck']-$s[$d]['g']['luck'])/19; // CMB: atributos, alcance, masa, táctica y suerte sin duplicar fatiga.
        if($dice->chance(self::clamp($p,0.1,0.9))){ // AZR: tres d20 conservan efectos menores del cinco por ciento.
            $damage=(3+0.6*$force)*(1+0.05*$s[$a]['mass'])*Rules::MODIFIERS[$s[$a]['mode']][0]*(1+0.05*$dice->unit()); // CMB: atributos dominan; variación limitada a cinco por ciento.
            $s[$d]['hp']=max(0,$s[$d]['hp']-$damage); // CMB: salud temporal nunca negativa.
            $knockout=$s[$d]['hp']<=0; // CMB: caer no implica lesión ni muerte.
            if($knockout){$fallen[]=$d;} // CMB: conservar orden real de eliminaciones.
            $log[]=['type'=>$knockout?'ko':($reaction?'counter':'hit'),'actor'=>$s[$a]['g']['name'],'target'=>$s[$d]['g']['name'],'damage'=>round($damage,1)]; // CMB: datos públicos del asalto.
        }elseif(!$reaction&&$s[$d]['mode']==='counter'&&!$s[$d]['counter']&&!$s[$d]['rest']&&$s[$d]['energy']>=self::cost($s[$d])&&$dice->d20()>=17){ // CMB: respuesta válida tras esquiva, máximo una por asalto.
            $s[$d]['counter']=true;self::strike($s,$d,$a,$dice,$log,$fallen,true); // CMB: reacción pagada que no permite otra cadena.
        }
    }

    public static function medical(array $g,Dice $dice): array
    {
        $roll=$dice->ticket();$extra=(int)($g['latent']??0); // MED: antecedente secreto medido en décimas de punto porcentual.
        if($roll<=8){return ['kind'=>'death','days'=>0,'latent'=>$extra,'first_grave'=>(int)($g['first_grave']??0)];} // MED: ocho entre ocho mil, una muerte por mil en promedio.
        $relapse=$roll>160&&$roll<=160+$extra*8; // MED: cinco décimas equivalen a cuarenta combinaciones.
        if($roll>160&&!$relapse){return ['kind'=>'none','days'=>0,'latent'=>$extra,'first_grave'=>(int)($g['first_grave']??0)];} // MED: categorías excluyentes, sin lesión extra por golpe.
        $severity=$dice->d20();$days=$severity<=14?3:($severity<=19?7:21); // MED: decisión operativa setenta leve, veinticinco moderada, cinco grave.
        $first=(int)($g['first_grave']??0); // MED: primera lesión grave puede dejar predisposición.
        if($relapse){$extra=min(15,$extra+5);} // MED: recaída incrementa medio punto hasta máximo uno y medio.
        if($days>=14&&!$first){$first=1;if($dice->d20()>=17){$extra=max(5,$extra);}} // MED: veinte por ciento de predisposición tras primera grave.
        return ['kind'=>$days===21?'severe':($days===7?'moderate':'light'),'days'=>$days,'latent'=>$extra,'first_grave'=>$first]; // MED: interfaz recibe lesión, nunca factor secreto.
    }
}
