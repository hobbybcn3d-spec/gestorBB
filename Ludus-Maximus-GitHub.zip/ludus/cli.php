<?php
declare(strict_types=1); // DOC: herramienta de instalación y cron sin navegador.
if(PHP_SAPI!=='cli'){http_response_code(404);exit;} // ADM: nunca exponer comandos por HTTP.
require __DIR__.'/bootstrap.php'; // DOC: mismas reglas y servicios que la aplicación.
$command=$argv[1]??'help'; // DOC: comando solicitado.
try{
    if($command==='install'){$password=getenv('LUDUS_ADMIN_PASSWORD')?:rtrim(strtr(base64_encode(random_bytes(18)),'+/','-_'),'=');$config=['driver'=>'sqlite','database'=>'ludus.sqlite'];\Ludus\Installer::install($config,getenv('LUDUS_ADMIN_USER')?:'admin',$password);echo "Instalado. Credenciales en var/admin-access.json (archivo privado).\n";exit;} // ADM: contraseña generada y entregada en archivo protegido, no en argumentos.
    if(!is_file(LUDUS_ROOT.'/var/config.php')){throw new RuntimeException('Ejecuta primero install.php o el comando install.');} // BD: comprobación legible de configuración.
    $config=require LUDUS_ROOT.'/var/config.php';$db=new \Ludus\Database($config);$game=new \Ludus\Game($db,time()); // BD: abrir instalación existente sin recrearla.
    if($command==='tick'){$game->tick();echo "Tareas ejecutadas sin duplicar cierres.\n";}elseif($command==='check'){echo json_encode(['version'=>\Ludus\Rules::VERSION,'driver'=>$db->driver,'users'=>(int)$db->value('SELECT COUNT(*) FROM lm_users'),'gladiators'=>(int)$db->value('SELECT COUNT(*) FROM lm_gladiators'),'events'=>(int)$db->value('SELECT COUNT(*) FROM lm_events'),'timezone'=>date_default_timezone_get()],JSON_PRETTY_PRINT)."\n";}else{echo "Comandos: install, tick, check. Instala con el asistente web para MySQL.\n";} // DOC: diagnósticos sin revelar claves.
}catch(Throwable $e){fwrite(STDERR,"Error: ".$e->getMessage()."\n");exit(1);} // DOC: código de salida útil para cron y pruebas.
