# Ludus Maximus — Proyecto

**Versión 1.0.0 · Actualizado el 13 de noviembre de 2026 · Funcional local; publicación en preparación.**

Documento maestro para leer y modificar en Visual Studio Code. La autorización del usuario permite implementar y resolver los detalles que faltaban. Las cifras delegadas de esta versión son ajustables; no son fórmulas oficiales de Hattrick.

La especificación anterior íntegra se conserva en [historial v0.31](docs/Proyecto-historial-v0.31.md). Este documento sustituye sus propuestas pendientes cuando aquí se concreta una decisión. **No se han migrado ni alterado datos de producción de NAFLM.**

## 1. Qué hemos creado y cómo mantenerlo

Un gestor de ludus de gladiadores de fantasía, inspirado en el ritmo de gestión de Hattrick y construido sobre el proyecto local NAFLM 2025. Se reutilizan sus imágenes y catálogo de personajes, y se incorpora un adaptador para sus cuentas. El combate de gladiadores implementa nuestras reglas d20; no ejecuta las reglas de partidos de Blood Bowl.

- Conservar aquí todas las decisiones vigentes y actualizar los documentos de detalle cuando cambien.
- «Atributos» y «habilidades» significan lo mismo: hay un solo conjunto de seis valores, sin otro árbol de habilidades.
- Comentar el código mediante abreviaturas y explicaciones breves. [Mapa de archivos y abreviaturas](docs/Mapa-archivos.md).
- Resolver propuestas delegadas para una versión jugable y registrar sus números; ajustar después con datos de partidas.
- Conservar históricos separados para evitar reglas contradictorias dentro del documento vigente.

Documentación práctica: [instalar y abrir](docs/Instalacion.md), [estructura SQL](docs/Base-de-datos-propuesta.md), [economía](docs/Economia-propuesta.md), [motor](docs/Motor-combate-propuesta.md), [d20](docs/Azar-d20.md), [recursos gráficos](docs/Inventario-imagenes.md), [reutilización de NAFLM](docs/Reutilizacion-NAFLM.md), [verificación y capturas](docs/Verificacion.md).

## 2. Identidad, cuentas y privacidad

**Nombre:** Ludus Maximus. Arena romana sencilla, marrones y rojos, tablas compactas y versión móvil. Español por defecto y selector de inglés. Emblema vectorial propio y personajes originales existentes. No hay equipamiento jugable en esta versión aunque los retratos originales lleven armas.

**Acceso:** registro abierto con usuario y contraseña; sin correo obligatorio. Usuario de 3–24 letras, números, guion o guion bajo; contraseña de al menos ocho caracteres. El administrador autoriza antes de jugar. Una cuenta pendiente puede consultar su estado y visitar información pública, sin recibir aún recursos. La autorización crea su ludus una sola vez.

**Inicio:** tres gladiadores aleatorios de 18–25 años, sin Grandotes; 6.000 denarios; ocho plazas; alojamiento y sala de entrenamiento nivel 1; entrenador nivel 1 gratuito al crearse. No se entrega enfermería ni otros empleados.

**Administrador:** cuenta inicial con rol administrador y todas las operaciones de organización: autorizar/suspender/reactivar cuentas; otorgar o quitar rol a otros usuarios; asignar contraseñas temporales; crear/modificar/celebrar eventos; abrir tandas extraordinarias; ejecutar tareas; importar usuarios NAFLM; cambiar tarifas, ingresar ajustes de dinero y corregir atributos/recuperación. No puede suspenderse o quitarse su propio acceso por accidente. Acciones registradas en auditoría sin contraseñas.

Contraseñas mediante hash. Una temporal obliga a cambiarla al entrar; asignarla no autoriza la cuenta. La copia de acceso inicial solicitada está en **var/admin-access.json**, solo para lectura local; no publica la contraseña ni recupera contraseñas posteriores.

**Visitas sin cuenta:** directorio y perfil de ludus con nombre, emblema, dueño, nombres y razas de gladiadores activos. No muestran atributos, economía, entrenamientos, estado médico ni informes. Resultados y crónicas requieren cuenta autorizada. El dueño ve los seis atributos de sus gladiadores. El administrador puede inspeccionarlos por su función de gestión. La predisposición médica queda fuera de la interfaz.

## 3. Ludus, instalaciones y personal

Nombre del ludus editable de 3–60 caracteres. Emblema predeterminado modificable: PNG/JPEG/WebP de hasta **200 KiB** y **1.024 × 1.024 píxeles**. El servidor decodifica, recorta y convierte a PNG de 256 × 256; no acepta archivos ejecutables ni SVG subido.

| Instalación | Inicio | Efecto y máximo de esta versión |
| --- | --- | --- |
| Alojamiento | Nivel 1 | Capacidad = 8 + 4 × (nivel − 1); máximo nivel 10. |
| Sala de entrenamiento | Nivel 1 | +2 % de avance por nivel sobre el primero, hasta +10 %; máximo nivel 6. |
| Instalaciones médicas | No construidas | Permiten médico hasta su mismo nivel; máximo nivel 5, sin bono médico adicional del edificio. |

Una obra por ludus, sin cola ni cancelación; se paga al iniciar y dura **siete días reales**. El nivel anterior sigue operativo hasta terminar. Se construye enfermería antes de contratar médico. Las mejoras liberan su efecto al terminar, no al comprarlas.

| Personal | Niveles | Función y límite |
| --- | --- | --- |
| Entrenador | 1–5 | Un puesto. Multiplica el avance por 1 / 1,10 / 1,20 / 1,30 / 1,35. |
| Ayudante | 1–5 | Un puesto con sala nivel 1; dos desde nivel 2. Cada nivel contratado suma 3,5 % al factor de ayudantes. |
| Médico | 1–5 | Un puesto, limitado por enfermería. Bonus de recuperación semanal del 20 % por nivel sobre tiempo cubierto. |

Los empleados continúan hasta despedirlos. Contratación y salarios en sección 10. Sin médico, la baja se recupera normalmente al transcurrir sus días reales. El médico no reduce la probabilidad de morir ni evita lesiones.

## 4. Gladiadores: razas, atributos y generación

**Cambio confirmado de esta implementación:** la raza antes llamada Ogros pasa a llamarse **Grandotes**. Agrupa los **19 modelos** que NAFLM marca como `is_bigguy=1`, incluidos ogros, trolls, minotauros, árboles, momias y otros grandes. El nombre del archivo original de imagen puede seguir conteniendo `ogre`; es un recurso conservado, no otra raza jugable.

| Raza | Mercado | Inicio, sin Grandotes | Altura | Peso estable |
| --- | ---: | ---: | ---: | ---: |
| Humanos | 35 % | 7/19 | 160–205 cm | 55–120 kg |
| Orcos | 20 % | 4/19 | 175–225 cm | 85–180 kg |
| Elfos | 15 % | 3/19 | 165–210 cm | 45–90 kg |
| Enanos | 15 % | 3/19 | 120–155 cm | 60–115 kg |
| Goblins | 10 % | 2/19 | 95–140 cm | 20–50 kg |
| Grandotes | 5 % | 0 | 230–310 cm | 180–350 kg |

Cada generación sortea independientemente; no hay cupos garantizados en una tanda de diez. Sexo: 90 % hombre / 10 % mujer. El sexo no añade diferencias de combate. Los retratos son modelos de la raza; no garantizan representar visualmente el sexo generado.

Los seis atributos van de **1 a 20**. Fuerza: daño; agilidad: iniciativa y precisión; constitución: salud; resistencia: gasto y recuperación de energía; consistencia: estabilidad de rendimiento; suerte: hasta cinco puntos porcentuales en precisión. No se entrenan sexo, edad, altura ni peso.

Los máximos raciales son máximos **de nacimiento**, no límites de progreso. Mínimo = techo(máximo / 2 − 1). Cada atributo se sortea uniforme en su rango, sin bolsa fija ni compensación entre valores. Suerte independiente: **d20, del 1 al 20**.

| Raza | Fuerza | Agilidad | Constitución | Resistencia | Consistencia | Suerte |
| --- | --- | --- | --- | --- | --- | --- |
| Humanos | 2–6 | 2–6 | 2–6 | 2–6 | 2–6 | 1–20 |
| Orcos | 3–8 | 1–4 | 3–8 | 2–5 | 2–5 | 1–20 |
| Elfos | 1–4 | 4–9 | 1–4 | 3–7 | 2–6 | 1–20 |
| Enanos | 2–6 | 1–4 | 4–9 | 3–7 | 2–5 | 1–20 |
| Goblins | 1–4 | 4–10 | 1–4 | 3–8 | 2–5 | 1–20 |
| Grandotes | 5–11 | 1–4 | 4–10 | 1–4 | 1–4 | 1–20 |

Altura entera uniforme dentro de su rango. Para peso correlacionado: fracción de altura = posición entre mínimo y máximo; fracción de peso = 65 % de esa fracción + 35 % de una variación d20 uniforme entre 0 y 1 en milésimas. Se convierte al rango racial y redondea a kilos. Altura y peso permanecen estables.

**Nombres:** catálogos reproducibles de cien nombres por raza y sexo y doscientos apellidos combinatorios; selección aleatoria d20. Se definen en `Rules::names`, sin servicios externos. No se exige nombre único entre gladiadores.

**Edad:** 100 días reales equivalen a un año; comienza entre 18 y 25. Desde 35, al cierre semanal cada atributo físico —fuerza, agilidad, constitución, resistencia— puede perder uno, nunca por debajo de 1. Probabilidad delegada por atributo = mínimo(12 %, 2 % + 1 % × años por encima de 35). Consistencia y suerte no declinan por esta regla. Se aplica después de entrenar y solo a activos.

## 5. Entrenamiento semanal

El dueño elige un atributo entrenable por gladiador mediante desplegable. Se aplica **la elección existente al cierre del lunes a las 00:00 de Madrid**. Cambiar de elección conserva las fracciones acumuladas de los demás atributos. La suerte no se entrena.

| Eventos del calendario realmente disputados en la semana | Avance |
| --- | ---: |
| Ninguno | 0 % |
| Uno | 50 % |
| Dos, tres o cuatro | 100 % |

Cada torneo cuenta una vez por gladiador, aunque tenga varias rondas. Puede participar en los cuatro eventos. Inscribirse sin combatir no cuenta. Los lesionados conservan el avance de los eventos ya disputados; un ludus con todos lesionados no suma participación por los sustitutos de la Arena.

| Nivel actual | Semanas base para subir un punto al 100 % |
| --- | ---: |
| 1–5 | 2 |
| 6–10 | 4 |
| 11–15 | 8 |
| 16–19 | 12 |
| 20 | Máximo |

Avance = participación / semanas base × factor del entrenador × (1 + 0,035 × suma de niveles de ayudantes) × (1 + mínimo(0,10; 0,02 × (nivel sala − 1))) × factor físico.

Para factor físico: H = limitar((altura − 180)/100, −1, 1); P = limitar((peso − 80)/150, −1, 1); tamaño combinado T = (H + P)/2. Fuerza: 1 + 0,15T; resistencia: 1 − 0,15T; restantes entrenables: 1. Son variaciones de hasta ±15 % de **velocidad de aprendizaje**, no puntos extra de atributo. No hay otro bono por raza ni ralentización adicional por edad en esta versión. Sin entrenador no hay progreso.

## 6. Calendario y participación

Reloj real `Europe/Madrid`, incluido horario de verano. Plantilla inicial: martes battle royale, jueves individuales, sábado battle royale y domingo individuales, todos a las **20:00**. El administrador cambia título, formato, fecha, hora y máximo por ludus; por defecto tres, configurable entre 1 y 16. Se prepara calendario con tres semanas de horizonte.

Inscripción cierra **quince minutos antes**. El dueño elige de uno al máximo del evento y asigna una táctica por participante. **Normal** por defecto; no se cambian órdenes durante el combate. Una selección manual menor no se completa automáticamente. Al resolver se excluyen lesionados, fallecidos y retirados que ya no puedan participar.

Si falta selección manual, el sistema elige aleatoriamente gladiadores disponibles de cada ludus cuyo dueño haya entrado en los **últimos quince días**. Si no hay ninguno disponible, no participa ese ludus. No hay notificaciones automáticas.

Mínimo global por evento: **cuatro gladiadores**, en ambos formatos. Se completa con retirados disponibles menores de cuarenta; si faltan, se generan neutrales nuevos y persistentes. No se crean cuatro por ludus ni un segundo equipo artificial por usuario.

**Battle royale:** todos simultáneos; pueden atacar a su propio ludus. Cuando hay compañeros y enemigos, 80 % de elegir enemigo y 20 % compañero; uniforme dentro del grupo elegido. Si solo quedan compañeros se atacan entre sí. Los neutrales no son compañeros entre ellos. Gana el último consciente, con desempate por límite si procede.

**Individuales:** cuadro de eliminación directa, que sustituyó al suizo en la definición anterior. Emparejamiento aleatorio, pases libres para ajustar cuadro y combate por tercer puesto entre semifinalistas. Puede haber duelos entre gladiadores del mismo dueño. Salud y energía se restauran entre duelos, también antes del tercero; lesiones se evalúan una sola vez al finalizar todo el evento.

**Resultados:** podio 1–2–3 claro, clasificación completa, lesionados y fallecidos separados, crónica de texto resumida por asaltos disponible completa al terminar. Un ludus puede llevarse varios puestos. Se conserva el nombre histórico aunque la ficha se borre después.

## 7. Motor de combate d20

Todo resultado aleatorio del juego utiliza `Dice`: d20 y combinaciones de d20 con rechazo sin sesgo para rangos. Las semillas se generan de forma segura y se conservan por evento para repetir transacciones sin alterar resultados. No se usa un d20 aislado que redondee cualquier probabilidad pequeña a 5 %.

Notación: F fuerza, AG agilidad, C constitución, R resistencia, CO consistencia, S suerte; P peso normalizado de sección 5; U20 = (2 × d20 − 21)/19, entre −1 y 1.

- Salud inicial = (60 + 4C) × (1 + 0,10P); energía inicial 100.
- Una tirada por pelea fija rendimiento = 1 + (0,10 − 0,09 × (CO − 1)/19) × U20. Consistencia reduce la variación de ±10 % a ±1 %.
- Fatiga = 0,75 + 0,25 × limitar(energía/25, 0, 1). Multiplica fuerza y agilidad efectivas, junto al rendimiento. A energía ≥25 no penaliza; como máximo resta 25 %.
- Iniciativa de cada asalto = **2 × agilidad efectiva + d20**. Desempates por agilidad, consistencia y sorteo reproducible; identificador como último criterio estable si también empatan las tiradas.
- Coste por intento = (6 − 0,20R) × (1 + 0,10P) × factor de energía de táctica. Se paga tanto al acertar como al fallar. Con energía insuficiente se descansa en vez de atacar: recupera 10 + R/2, hasta 100, y bloquea respuestas durante el resto del asalto.
- Probabilidad de acertar = 0,60 + limitar(0,20 × (AG efectiva atacante − defensora)/19, −0,20, 0,20) + limitar(0,0005 × diferencia de altura en cm, −0,05, 0,05) + 0,03P del defensor + exposición de su táctica + 0,05 × diferencia de suerte/19. Resultado limitado entre 10 % y 90 %. La suerte cambia como máximo cinco puntos porcentuales frente al rival.
- Acierto mediante ticket uniforme de tres d20: 8.000 combinaciones. Daño = (3 + 0,60 × fuerza efectiva) × (1 + 0,05P atacante) × daño de táctica × (1 + 0,05U20). El azar del daño se limita a ±5 %.
- Salud en cero: inconsciente y eliminado; pierde turnos pendientes. No equivale a muerte.
- Contraataque: tras fallo enemigo, modo contraataque permite respuesta con d20 ≥17, máximo una por asalto, con energía suficiente y sin haber descansado; paga coste y no encadena reacciones.
- Tope: 50 asaltos por duelo y 75 por battle royale. Si quedan varios, decide salud proporcional, energía y sorteo. Los eliminados se ordenan por caída inversa.

| Modo | Daño | Exposición al golpe rival | Energía |
| --- | ---: | ---: | ---: |
| Normal | ×1,00 | 0 | ×1,00 |
| Agresivo | ×1,15 | +5 puntos porcentuales | ×1,20 |
| Defensivo | ×0,85 | −5 puntos porcentuales | ×0,90 |
| Contraataque | ×0,90 | 0; respuesta descrita arriba | ×1,00 |
| Evasivo | ×0,80 | −8 puntos porcentuales | ×1,10 |

Los atributos influyen más que las fluctuaciones; no se garantiza victoria absoluta por puntuación. La comprobación de balance inicial y sus límites están en [Verificacion.md](docs/Verificacion.md).

## 8. Lesiones, muertes, retirada y reserva

Una evaluación médica por gladiador **al finalizar el evento**, tanto de usuario como neutral, incluso si es ganador. Base total 2 %: muerte 0,1 % y lesión no mortal 1,9 %, categorías excluyentes. Ticket de tres d20: 1–8 muerte; 9–160 lesión. «Una por mil» es una media probabilística, no un contador garantizado.

Severidad delegada para completar la versión: d20, 1–14 leve de tres días; 15–19 moderada de siete días; 20 grave de veintiún días. Las lesiones son días reales, y bloquean los siguientes eventos mientras no se recupere. Salud y energía del combate no persisten entre eventos.

Predisposición a recaídas privada: 20 % de adquirirla tras la primera grave; empieza añadiendo 0,5 puntos porcentuales al riesgo de lesión; cada recaída añade otros 0,5 hasta un máximo de 1,5. No aumenta la mortalidad. Nadie ve este factor en las pantallas ni aparece como atributo entrenable.

Bonus del médico al cierre semanal: reduce la fecha de fin en tiempo cubierto desde la lesión durante esa semana × 20 % × nivel. Nunca aplica tiempo anterior a lesionarse ni adelanta la curación a antes del cierre. Sin médico sigue funcionando la recuperación normal.

**Retirar es irreversible para el dueño**: libera plaza, elimina inscripciones futuras y pasa a la reserva. Retirados y neutrales generados siguen exactamente el mismo régimen: envejecen a cien días por año, conservan sus seis atributos y no entrenan ni sufren declive por edad. Pueden volver a eventos de Arena, lesionarse y morir; un fallecido no vuelve a competir. A los **cuarenta** se borra la ficha de reserva/fallecido. Las clasificaciones conservan el nombre y resultado histórico sin reconstruir una ficha permanente.

Los premios de Arena quedan **sin asignar**; no los cobra el antiguo dueño ni se desplazan a otro puesto. No pagan mantenimiento al antiguo ludus. Sin gladiadores activos se conserva la cuenta y se puede comprar en el mercado, con la recuperación económica descrita en sección 10.

## 9. Mercado y espionaje

Cada semana se generan **diez** gladiadores. Horario normal: lunes 18:00 a jueves 18:00, tres días reales; nueva tanda la semana siguiente. El administrador puede abrir una tanda extraordinaria si no hay otra abierta.

Datos públicos de mercado: nombre, raza, sexo, edad, altura, peso, constitución y retrato; los otros cinco atributos permanecen ocultos. Puja inicial por raza, no por calidad oculta. Se muestra la oferta líder y el nombre del máximo pujador, sin avisos al anterior.

- Primera oferta al menos el precio de salida. Después, mínimo techo(puja anterior × 1,05), sin céntimos.
- Puja líder reserva simultáneamente dinero y plaza; al ser superada se liberan ambos. El disponible descuenta reservas, incluso para obras y personal. No se puede sobrepasar el alojamiento al ganar varias ofertas.
- Puja válida en los últimos quince minutos añade quince minutos al cierre vigente. Puede volver a ampliarse.
- Al cierre se cobra y transfiere una sola vez. Si no hay comprador se borra el gladiador, conservando la fila de subasta sin su ficha.
- Por **100 denarios**, cada usuario puede descubrir una vez un atributo aleatorio de ese gladiador, excluyendo la constitución ya pública. Resultado solo para él en Espionaje, hasta que termine la subasta; luego se borra.
- No existe todavía mercado de venta entre usuarios.

**Espionaje semanal:** una acción secreta gratuita por usuario y semana de Madrid, sin acumular. Elige un gladiador de otro ludus y descubre un atributo aleatorio entre los seis. Solo el usuario ve su informe en Espionaje; desaparece y se borra el lunes a las 00:00. No informa al rival ni conserva una biblioteca histórica de estadísticas. No consume el descubrimiento pagado del mercado.

## 10. Economía inicial implementada

Moneda virtual: denarios enteros. Cifras delegadas de arranque, editables por admin para futuras operaciones; no reescriben historial.

| Concepto | Denarios |
| --- | ---: |
| Dotación inicial, una sola vez al autorizar | 6.000 |
| Patrocinio semanal, cuenta activa y acceso en quince días | 200 |
| Participación efectiva, por gladiador y evento completo | 60 |
| Podio adicional 1.º / 2.º / 3.º | 300 / 180 / 100 |
| Alimentación semanal por gladiador activo | 20 |
| Mantenimiento semanal por nivel de edificio construido | 40 |
| Descubrimiento de mercado | 100 |

| Personal | Contratar niveles 1 / 2 / 3 / 4 / 5 | Salario semanal niveles 1 / 2 / 3 / 4 / 5 |
| --- | --- | --- |
| Entrenador | 500 / 1.500 / 3.500 / 8.000 / 15.000 | 100 / 160 / 240 / 350 / 500 |
| Ayudante | 300 / 700 / 1.500 / 3.000 / 5.000 | 50 / 80 / 120 / 170 / 230 |
| Médico | 400 / 900 / 1.800 / 3.500 / 6.000 | 60 / 100 / 150 / 210 / 280 |

El entrenador inicial nivel 1 no cobra contratación; sí salario. Alojamiento nivel 2: 1.200; sala nivel 2: 1.800; enfermería nivel 1: 1.500. Siguientes niveles: base 1.200 para alojamiento o 1.800 para sala/enfermería, multiplicada por 1,8^(nivel objetivo − 2), redondeando hacia arriba a decenas. Ejemplo: enfermería nivel 2 cuesta 1.800.

Salidas de mercado: humano 1.200; orco 1.500; elfo 1.500; enano 1.400; goblin 800; Grandote 4.500.

Gastos semanales de empleados prorrateados por tiempo contratado, conservando lo devengado aunque se despida. Alimentación por tiempo en plantilla; edificios por tiempo construidos, con el nivel operativo al cierre. El detalle de niveles anteriores de un edificio no se reconstruye intrassemanalmente en esta primera versión. Patrocinio, mantenimiento y entrenamiento se ejecutan al cierre semanal, premios al resolver evento.

Si no alcanza dinero disponible, se paga lo posible y el resto se registra como deuda. No se gastan reservas de subastas ni se matan o regalan gladiadores por deuda. Mientras haya mantenimiento impagado se bloquea nueva inversión; los ingresos futuros lo liquidan primero.

**Recuperación delegada:** anticipo único de 2.000, sin intereses, si no tiene gladiadores y saldo inferior a 800. Se devuelve con el 20 % de ingresos después de mantenimiento; solo una vez en toda la vida del ludus. Evita quedar sin forma de volver al mercado. La interfaz no debería ofrecerlo de nuevo tras haberlo devuelto.

Ejemplo de semana completa: tres gladiadores y dos edificios nivel 1, entrenador 1: gasto 240; patrocinio 200; cuatro eventos de los tres aportan 720. Balance +680 sin podios. Es una base de balance, no una simulación económica de largo plazo.

## 11. Pestañas

| Pestaña | Contenido |
| --- | --- |
| Inicio | Resumen, plantilla, tesorería, siguiente evento y resultados recientes. |
| Mi ludus | Nombre, emblema, instalaciones y obra activa. |
| Gladiadores | Tabla privada y ficha de atributos. |
| Entrenamiento | Elección individual, fracciones y participación semanal. |
| Personal | Contratos, nivel, salario, contratación y despido. |
| Calendario | Fechas, cierre, selección y cinco tácticas por gladiador. |
| Resultados | Podio, clasificación, lesionados, fallecidos y crónicas por evento. |
| Mercado | Diez ofertas, pujas y descubrimiento pagado. |
| Espionaje | Acción semanal e informes privados vigentes. |
| Economía | Saldo, reservas, deudas, recuperación y libro contable. |
| Administración | Solo administradores: cuentas, organización, correcciones y tarifas. |

Además: acceso/registro, cambio de contraseña, directorio y visita pública de ludus, reglas y créditos. Tablas móviles desplazan dentro de su panel, sin desbordar toda la página.

## 12. Técnica, datos y reutilización

**Implementado:** PHP ≥8.1 de 64 bits, PDO, HTML de servidor, CSS y JavaScript sin framework ni compilación. SQLite por defecto; opción MySQL/MariaDB con tablas InnoDB. La propuesta antigua de PostgreSQL queda sustituida para facilitar instalar sobre NAFLM.

Veinte tablas `lm_`, con claves foráneas y consultas preparadas. Los seis atributos son columnas de una misma ficha, sin duplicado de habilidades. Transacciones serializan pujas y cierres; claves únicas hacen idempotentes dotaciones, adjudicaciones, premios y semanas. Nombres históricos de inscripciones permiten borrar personajes sin perder el resultado. [Esquema detallado](docs/Base-de-datos-propuesta.md).

Se mantienen originales `index.naflm.php` e `install.naflm.php`; los puntos de entrada nuevos no cargan el arranque `mysql_*` obsoleto. El adaptador de cuentas lee `coaches` solo al solicitar importación en MySQL. No asigna equipos deportivos a ludus ni expone contraseñas heredadas. Las imágenes y condiciones de licencia de NAFLM/OBBLM se conservan, con atribución.

Sesiones nuevas HttpOnly/SameSite; formularios con CSRF; roles y propiedad comprobados en servidor; escape HTML; subidas de imágenes decodificadas; informes sin caché y sin secretos en JavaScript. Configuración, bases y herramientas en carpetas bloqueadas para HTTP. `var` queda excluida de control de versiones, salvo archivos de protección.

Las visitas procesan tareas vencidas con una espera de treinta segundos entre ejecuciones. Para horarios exactos sin visitas se requiere programar `php ludus/cli.php tick` cada minuto. Cada ejecución recupera hasta cuarenta eventos y doce semanas atrasadas; puede repetirse sin duplicar operaciones. El cálculo de una recuperación masiva ordena primero eventos y luego cierres; para operación continua debe mantenerse el cron activo.

## 13. Entrega, validación y siguientes ajustes

La partida principal local conserva **un administrador y sus tres gladiadores iniciales**. Escenarios QA en otras bases dentro de `var`, sin alterar esa partida. Las capturas representan la partida de demostración y resultados calculados, no datos ficticios escritos en las vistas.

El lanzador `.cmd` ejecuta PHP directamente: no requiere habilitar scripts PowerShell. La variante `.ps1` se conserva para uso avanzado cuando esté permitida.

Se ha probado instalación, SQL, motor y navegación, con evidencia en [Verificacion.md](docs/Verificacion.md). [Capturas](docs/capturas/02-inicio.png). La web se abre con **Iniciar-Ludus.cmd**; las instrucciones y copias están en [Instalacion.md](docs/Instalacion.md). No se ha publicado en internet.

Pendiente para una etapa posterior: balance con partidas largas y más usuarios; pruebas de carga y despliegue del alojamiento definitivo; mercado entre usuarios si se solicita; otros idiomas, equipamiento o habilidades especiales solo si se definen como cambio explícito. No son funciones ocultas ni requisitos necesarios para jugar esta versión.

## 14. Historial de esta entrega

### Publicación acordada el 13/11/2026

El usuario solicita publicar y aporta su cuenta **alwaysdata Free**, con dominio `hobbybcn3d.alwaysdata.net`. Se comprueba que ese dominio ya sirve NAF League Manager. La primera publicación de Ludus se prepara en **https://hobbybcn3d.alwaysdata.net/ludus/**, con un sitio PHP 8.4 independiente y directorio `/ludus-maximus/`, conservando el sitio actual.

Se preparan ZIP por lista permitida de archivos; uno limpio y otro con copia consistente de la partida SQLite, usuarios, hashes y emblemas. Se excluyen herramientas, QA, settings.php antiguo y admin-access.json. Inventario SHA-256 y comprobación de SQLite. `Subir-Alwaysdata.cmd` solicita la contraseña SSH en la consola local; `deploy/alwaysdata.py` instala solo si no existe el destino y no sobrescribe NAFLM.

Configuración prevista: HTTPS, caché HTTP desactivada y tarea cada minuto con `PHP_VERSION=8.4`. La partida migrada conserva las cuentas y permisos. Procedimiento y estado en [Publicacion-Alwaysdata.md](docs/Publicacion-Alwaysdata.md).

**Pendiente de acceso:** aún no se han transferido archivos ni modificado la cuenta remota. La publicación se confirmará cuando responda el juego en su URL, se comprueben las carpetas privadas y siga funcionando NAFLM.

El usuario confirma disponer de SSH/SFTP y conocer su contraseña. El paquete ha pasado 32 comprobaciones de exportación, arranque bajo `/ludus/`, permisos y extracción; los datos y accesos se conservan. La autenticación se realizará en la consola del usuario al abrir `Subir-Alwaysdata.cmd`, sin compartir contraseñas en el chat. La transferencia real y el alta del sitio siguen pendientes hasta comprobar su resultado.

### Cambio de método: ZIP pequeño para GitHub

El usuario pide máxima compresión y un único archivo pequeño, con todo lo necesario para instalar y ejecutar en alwaysdata sin FileZilla. Se prepara **Ludus-Maximus-GitHub.zip**, con ZIP DEFLATE nivel 9 y objetivo inferior a un megabyte. El código y sus comentarios se conservan íntegros; se incluyen los retratos de todas las razas y las diecinueve variantes de Grandotes, el instalador, los recursos de interfaz y la documentación necesaria.

El paquete GitHub es de **instalación nueva** y no incluye bases, usuarios, contraseñas, settings.php, herramientas, capturas, pruebas ni históricos. No se borran del proyecto original. La base y la cuenta administradora se crearán en alwaysdata con el instalador. GitHub almacena el archivo; el servicio PHP continúa en alwaysdata, no en GitHub Pages.

El lanzador **Subir-GitHub-Alwaysdata.cmd** funciona desde la carpeta extraída con OpenSSH y tar de Windows; no necesita FileZilla ni PHP/Python locales. Genera la transferencia desde una lista exacta de archivos y solicita la clave SSH en la consola. El modo `install-clean` del instalador remoto comprueba las huellas, mantiene NAFLM y rechaza sustituir un Ludus existente. La guía fuente es [Paquete-GitHub.md](docs/Paquete-GitHub.md), incluida como README del ZIP.

| Versión | Cambio |
| --- | --- |
| 0.1–0.30 | Definición progresiva; copias históricas en docs. |
| 0.31 | Motor d20 y acuerdos anteriores; copia completa conservada. |
| 1.0.0 | Autorizada y creada la web funcional. Ogros pasa a Grandotes, 19 retratos grandes; instalador SQLite/MySQL; cuenta admin; once pestañas; combate, mercado, entrenamiento, economía y reserva; documentación, comentarios y capturas. Se concretan economía, severidades, declive, límites de edificios y recuperación delegadas. |
